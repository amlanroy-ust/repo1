module.exports = {
	//"database" : "mongodb://localhost:27017/database-vmt",
	"port" : process.env.PORT || 3000,
	"secretKey" : "hyrgqwjdfbw4534efqrwer2q38945765",
	dev_mode : true,
    __site_url: 'http://localhost:3000/',
    __root_dir: __dirname
	//"imagepath": "http://localhost:3000/uploads/",
	//"apiUrl": "http://localhost:3000",
}
