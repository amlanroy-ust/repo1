require('rootpath')();
var express = require('express');
var app = express();
var cors = require('cors');
var bodyParser = require('body-parser');
var expressJwt = require('express-jwt');
var methodOverride = require('method-override');
//var errorHandler = require('error-handler');
var config = require('./config');
//var mongoose = require("mongoose");
var fs = require('fs');
var path = require('path');
var http = require('http').Server(app);

var morgan = require('morgan');
var routes = require('./routes');
var api = require('./routes/api');

//mongoose.Promise = require('bluebird');

// mongoose.connect(config.database, {useMongoClient: true}, function (err) {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log("Connected to the database");
//     }
// });

app.use(function(req, res, next) { //allow cross origin requests
        res.setHeader("Access-Control-Allow-Methods", "POST, PUT, OPTIONS, DELETE, GET");
        res.header("Access-Control-Allow-Origin", config.__site_url);
        res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
        res.header("Access-Control-Allow-Credentials", true);
        next();
    });

app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

/**
 * Configuration
 */

// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.set('view engine', 'jade');
app.use(morgan('dev'));
//app.use(bodyParser());
app.use(methodOverride());
app.use(express.static(path.join(__dirname, 'public')));

var env = process.env.NODE_ENV || 'development';

// development only
// if (env === 'development') {
//   app.use(express.errorHandler());
// }

// production only
//if (env === 'production') {
  // TODO
//}

//app.use('/uploads', express.static(__dirname + '/uploads'));
//console.log(__dirname + '/uploads');

//use JWT auth to secure the api, the token can be passed in the authorization header or querystring

// app.use(expressJwt({
//     secret: config.secretKey,
//     getToken: function (req) {
//         if (req.headers.authorization && req.headers.authorization.split(' ')[0] === 'Bearer') {
//             return req.headers.authorization.split(' ')[1];
//         } else if (req.query && req.query.token) {
//             return req.query.token;
//         }
//         return null;
//     }
// }).unless({ path: ['/users/authenticate', '/users/register', '/users/upload', '/users/employeeData'] }));

/**
 * Routes
 */

// serve index and view partials
app.get('/', routes.index);
app.get('/partials/:name', routes.partials);

// JSON API
app.get('/api/name', api.name);

// redirect all others to the index (HTML5 history)
app.get('*', routes.index);

//app.use('/users', require('./routes/userRoutes'));

//var apiRoutes = require('./routes/apiRoutes.js')(app, express);

//app.use('/api', apiRoutes);

// start server
// var port = process.env.NODE_ENV === 'production' ? 80 : 4000;
// var server = app.listen(port, function () {
//     console.log('Server listening on port ' + port);
// });

http.listen(config.port, function (err) {
    if (err) {
        console.log(err)
    } else {
        console.log('Server listening on port ' + config.port);
    }
});