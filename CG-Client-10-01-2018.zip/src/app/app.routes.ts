import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SurveyComponent } from './survey/survey.component';
import { ProviderComponent } from './provider/provider.component';
//import { UserComponent } from './users/user.component';
import { AuthGuard } from './_guards/index';

export const rootRouterConfig: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'client-profile', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'survey-report', component: SurveyComponent, canActivate: [AuthGuard] },
  { path: 'provider-report', component: ProviderComponent, canActivate: [AuthGuard]},
  { path: 'user', loadChildren: 'app/users/user.module#UserModule' },
  // otherwise redirect to home
  { path: '**', redirectTo: 'login', pathMatch: 'full' }
];

export const routes: ModuleWithProviders = RouterModule.forRoot(rootRouterConfig);