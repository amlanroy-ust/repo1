import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { AlertService, AuthenticationService } from '../_services/index';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

    model: any = {};
    loading = false;
    returnUrl: string;
    show_message = false;
    loginUser: any;
    loginMessage: string;

    constructor(
        private router: Router, 
        private route: ActivatedRoute,
        private authenticationService: AuthenticationService,
        private alertService: AlertService
    ) { 
        this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
        if(this.loginUser !== null)
        {
            this.returnUrl = '/client-profile';
            this.router.navigate([this.returnUrl]);
        }
    }

    ngOnInit() {
        // reset login status
        // get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/client-profile';
    }

    login() {
        this.loading = true;
        this.loading = true;
        this.authenticationService.login(this.model.username, this.model.password)
        .subscribe(
            data => {
                this.router.navigate([this.returnUrl]);
            },
            error => {
                error = JSON.parse(error);
                this.loginMessage = error.errorMessage;
                this.show_message = true;
                setTimeout(()=>{
                    this.show_message = false;
                },3000);
            });
    }

}