﻿import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { AlertService, AuthenticationService, UserService, MessageService } from '../_services/index';
import { Subscription } from 'rxjs/Subscription';
import { Ng2DeviceService } from 'ng2-device-detector';
declare var tableToExcel: any;
import * as jQuery from 'jquery';
declare var $: any;

@Component({
    templateUrl: 'survey.component.html',
    styleUrls: ['./survey.component.css']
})

export class SurveyComponent implements OnInit {
    loginUser: any;
    showPage: boolean;
    userDet: any;
    userInfo: {};
    returnUrl: string;
    clientSurveyList = [];
    clientNameArray = [];
    clientjsonArray = [];
    selectedValue = null;
    peopleFilter: any;
    showData: Boolean;
    locationTypeList = [];
    searchClient: string;
    locationType = null;
    showLoading: Boolean;
    MilestoneList = [];
    milestone = null;
    milestoneArray = [];
    SurveyList = [];
    survey = null;
    surveyArray = [];
    screenHeight: number;
    styleHeight: any;
    deviceInfo = null;
    
    // CallFunction1(event, table:string, name:string) {

    //     var dt = new Date();
    //     var day = dt.getDate();
    //     var month = dt.getMonth() + 1;
    //     var year = dt.getFullYear();
    //     var hour = dt.getHours();
    //     var mins = dt.getMinutes();
    //     var seconds = dt.getSeconds();
    //     var postfix = month + "." + day + "." + year + "_" + hour + "." + mins + "." + seconds;
    //     name = name+'_' + postfix;
    //     // if(this.selectedValue === 'all')
    //     //     $('#message').show();
    //     ////tableToExcel(event, table, name);
    //     var result = tableToExcel(event, table, name);
    //     // console.log('export to excel: ', result);
    //     // if(result === true && this.selectedValue === 'all'){
    //     //     window.addEventListener('focus', this.HideDownloadMessage, false);
    //     // }
    // }

    exportToExcel(event, table, name:string, fileType:string) {
        
        var dt = new Date();
        var day = dt.getDate();
        var month = dt.getMonth() + 1;
        var year = dt.getFullYear();
        var hour = dt.getHours();
        var mins = dt.getMinutes();
        var seconds = dt.getSeconds();
        var postfix = month + "." + day + "." + year + "_" + hour + "." + mins + "." + seconds;
        name = name+'_' + postfix;

        if(fileType === 'xls')
            tableToExcel(event, table, name);
        else $(table).tableExport({ type: 'csv', escape: false, fileName: name });
    }

    // ShowDownloadMessage()
    // {
    //     //$('#message-text').text('your report is creating, please wait...');
    //     $('#message').show();
    //     //this.showPage = false;
    //     console.log('ShowDownloadMessage');
    //     window.addEventListener('focus', this.HideDownloadMessage, false);
    // }

    HideDownloadMessage(){
        //console.log('HideDownloadMessage');
        window.removeEventListener('focus', this.HideDownloadMessage, false);    
        $('#message').hide();
    }

    constructor(
        private router: Router, 
        private route: ActivatedRoute,
        private userService: UserService,
        private authenticationService: AuthenticationService,
        private alertService: AlertService,
        private MessageService: MessageService,
        private deviceService: Ng2DeviceService
        ) {
            this.peopleFilter = {searchBy: ''};
            this.MessageService.sendMessage('CLIENT SURVEY REPORTS');
    }

    ngOnInit() {
        this.browserDetectFunction();
        this.screenHeight = screen.height - 468;
        this.styleHeight = {
            "max-height" : this.screenHeight+"px"
        };
        this.showPage = false;
        this.showData = false;
        this.showLoading = false;
        this.getClientSurveyDetailsList();
        this.getMilestoneList();
        this.getSurveyList();
        this.getLocationTypeList();
    }

    browserDetectFunction() {
      this.deviceInfo = this.deviceService.getDeviceInfo();
      //console.log('deviceInfo', this.deviceInfo.browser);
    }

    onSearchChange(value) {
        //console.log('search value', value);
        this.showData = true;
        this.selectedValue = null;
        this.locationType = null;
        this.survey = null;
        this.milestone = null;

        this.clientSurveyList = this.clientjsonArray;
        if(!value)
        {
            this.clientSurveyList = [];
            this.showData = false;
        }
        this.peopleFilter = {searchBy: value};
    }

    getClientSurveyDetailsList() {
        this.userService.getClientSurveyDetailsList()
        .subscribe(
            data => { 
                this.clientSurveyList = data;
                this.clientNameArray = data;
                //console.log('this.clientSurveyList', this.clientSurveyList);
                this.clientjsonArray = data;
                this.showPage = true;
            },
            error => {
                this.alertService.error(error);
            });
    }

    selectClientFunc($event) {
        //console.log('this.selectedValue: ', this.selectedValue);
        this.searchClient = '';
        this.locationType = null;
        this.survey = null;
        this.milestone = null;

        this.peopleFilter = {searchBy: ''};
        this.clientSurveyList = this.clientjsonArray;

        if(this.selectedValue === 'all'){
            //console.log('this.selectedValue', this.selectedValue);
            this.showLoading = true;
            this.showData = true;
            setTimeout(()=>{
                this.showLoading = false;
            },3000)

        }
        else if(this.selectedValue !== null)
        {
            //console.log('this.selectedValue: ', this.selectedValue);
            this.clientSurveyList = [];
            this.clientSurveyList.push(this.selectedValue);
            this.showData = true;
        }
        else if(this.selectedValue === null)
        {
            this.clientSurveyList = [];
            this.showData = false;
        }
        
    }

    getLocationTypeList() {
        this.userService.getLocationTypeList()
        .subscribe(
            data => { 
                this.locationTypeList = data;
            },
            error => {
                this.alertService.error(error);
            });
    }
    
    selectLocationTypeFunc() {
        //console.log('this.locationType: ', this.locationType);
        if(this.locationType === null)
        {
            this.clientSurveyList = [];
            this.showData = false;
        }
        else{
            this.clientSurveyList = this.clientjsonArray;
            this.selectedValue = null;
            this.searchClient = '';
            this.survey = null;
            this.milestone = null;
            this.peopleFilter = {searchBy: this.locationType.NAME};
            
            this.showLoading = true;
            this.showData = true;
            setTimeout(()=>{
                this.showLoading = false;
            },2000)
        }
    }

    getMilestoneList() {
        this.userService.getMilestoneList()
        .subscribe(
            data => { 
                //console.log('survey data: ', data);
                this.MilestoneList = data;
            },
            error => {
                this.alertService.error(error);
            });
    }

    selectMilestoneFunc() {
        if(this.milestone === null)
        {
            this.clientSurveyList = [];
            this.showData = false;
        }
        else{
            //console.log('this.clientjsonArray: ', this.clientjsonArray);
            this.peopleFilter = {searchBy: ''};
            this.clientSurveyList = [];
            this.searchClient = '';
            this.locationType = null;
            this.selectedValue = null;
            this.survey = null;
            
            for(let clnt of this.clientjsonArray){
                this.milestoneArray = [];
                for(let surv of clnt.surveyData){
                    if(parseInt(surv.MILESTONE_ID) === this.milestone.MILESTONE_ID)
                    {
                        this.milestoneArray.push(surv);
                    }
                }
                this.clientSurveyList.push({'CLIENT_ID': clnt.CLIENT_ID, 'NAME': clnt.NAME, 'STATUS': clnt.STATUS, 'GENDER': clnt.GENDER, 'BIRTH_DATE_FROM': clnt.BIRTH_DATE_FROM, 'BONE_DEN_AGE_FROM': clnt.BONE_DEN_AGE_FROM, 'COUNTRY': clnt.COUNTRY, 'MARITAL_STATUS': clnt.MARITAL_STATUS, 'surveyData': this.milestoneArray});
            }

            this.showLoading = true;
            this.showData = true;
            setTimeout(()=>{
                this.showLoading = false;
            },2000)
        }
    }

    getSurveyList() {
        this.userService.getSurveyList()
        .subscribe(
            data => { 
                this.SurveyList = data;

            },
            error => {
                this.alertService.error(error);
            });
    }

    selectSurveyFunc() {
        if(this.survey === null)
        {
            this.clientSurveyList = [];
            this.showData = false;
        }
        else{
            this.peopleFilter = {searchBy: ''};
            this.clientSurveyList = [];
            this.searchClient = '';
            this.locationType = null;
            this.selectedValue = null;
            this.milestone = null;
            
            for(let clnt of this.clientjsonArray){
                this.surveyArray = [];
                for(let surv of clnt.surveyData){
                    if(parseInt(surv.SURVEY_ID) === this.survey.SURVEY_ID)
                    {
                        this.surveyArray.push(surv);
                    }
                }
                this.clientSurveyList.push({'CLIENT_ID': clnt.CLIENT_ID, 'NAME': clnt.NAME, 'STATUS': clnt.STATUS, 'GENDER': clnt.GENDER, 'BIRTH_DATE_FROM': clnt.BIRTH_DATE_FROM, 'BONE_DEN_AGE_FROM': clnt.BONE_DEN_AGE_FROM, 'COUNTRY': clnt.COUNTRY, 'MARITAL_STATUS': clnt.MARITAL_STATUS, 'surveyData': this.surveyArray});
            }

            this.showLoading = true;
            this.showData = true;
            setTimeout(()=>{
                this.showLoading = false;
            },2000)
        }
    }

}