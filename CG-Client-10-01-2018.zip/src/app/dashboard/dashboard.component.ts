﻿import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit, Injectable } from '@angular/core';
import { AlertService, AuthenticationService, UserService, MessageService } from '../_services/index';
import * as _ from 'underscore';
import { Ng2DeviceService } from 'ng2-device-detector';

import { PagerService } from '../_pagination/index';

declare var tableToExcel: any;
import * as jQuery from 'jquery';

import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';

declare let $: any;

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';

@Injectable()

@Component({
    templateUrl: 'dashboard.component.html',
    styleUrls: ['./dashboard.component.css']
})

export class DashboardComponent implements OnInit {
    loginUser: any;
    showPage: boolean;
    userDet: any;
    userInfo: {};
    returnUrl: string;
    clientList = [];
    clientNameArray = [];
    //clientJson: any = {};
    clientjsonArray = [];
    selectedValue = null;
    peopleFilter: any;
    showData: Boolean;
    showLoading: Boolean;
    programStatusList = [];
    locationTypeList = [];
    searchClient: string;
    programStatus = null;
    locationType = null;
    dataTable = [];
    screenHeight: number;
    styleHeight: any;
    deviceInfo = null;
    // pager object
    pager: any = {};
    // paged items
    pagedItems: any[];

    // reportData = [
    //     {
    //     "EmployeeID": "1234567",
    //     "LastName": "Lastname",
    //     "FirstName": "First name",
    //     "Salary": 1000
    //     },
    //     {
    //     "EmployeeID": "11111111",
    //     "LastName": "Lastname 1",
    //     "FirstName": "First name 1",
    //     "Salary": 2000
    //     }
    // ];

    // exportActionCSV(table, name:string){
        
    //     var dt = new Date();
    //     var day = dt.getDate();
    //     var month = dt.getMonth() + 1;
    //     var year = dt.getFullYear();
    //     var hour = dt.getHours();
    //     var mins = dt.getMinutes();
    //     var seconds = dt.getSeconds();
    //     var postfix = month + "." + day + "." + year + "_" + hour + "." + mins + "." + seconds;
    //     name = name+'_' + postfix;

    //     $(table).tableExport({ type: 'csv', escape: false, fileName: name });

    // }

    exportToExcel(event, table, name:string, fileType:string) {
        
        var dt = new Date();
        var day = dt.getDate();
        var month = dt.getMonth() + 1;
        var year = dt.getFullYear();
        var hour = dt.getHours();
        var mins = dt.getMinutes();
        var seconds = dt.getSeconds();
        var postfix = month + "." + day + "." + year + "_" + hour + "." + mins + "." + seconds;
        name = name+'_' + postfix;

        if(fileType === 'xls')
            tableToExcel(event, table, name);
        else $(table).tableExport({ type: 'csv', escape: false, fileName: name });
    }

    constructor(
        private router: Router, 
        private route: ActivatedRoute,
        private userService: UserService,
        private authenticationService: AuthenticationService,
        private alertService: AlertService,
        private MessageService: MessageService,
        private pagerService: PagerService,
        private deviceService: Ng2DeviceService
        ) {
            this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
            //console.log('this.loginUser', this.loginUser);
            this.peopleFilter = {searchBy: ''};
            this.MessageService.sendMessage('CLIENT PROFILE REPORTS');

            //console.log("Total Height: " + screen.height + "px");
    }

    ngOnInit() {
        this.browserDetectFunction();
        
        this.screenHeight = screen.height - 485;
        this.styleHeight = {
            "max-height" : this.screenHeight+"px"
        };
        this.showPage = false;
        this.showData = false;
        this.getAllClientsTrafficCourt(this.loginUser.userName, this.loginUser.login_token);
        this.getProgramStatusList();
        this.getLocationTypeList();
    }

    browserDetectFunction() {
      this.deviceInfo = this.deviceService.getDeviceInfo();
      //console.log('deviceInfo', this.deviceInfo.browser);
    }

    onSearchChange(value) {
        this.showData = true;
        this.showLoading = false;
        this.selectedValue = null;
        this.programStatus = null;
        this.locationType = null;
        this.clientList = this.clientjsonArray;
        if(!value)
        {
            this.clientList = [];
            //this.clientList = this.clientjsonArray;
            this.showData = false;
        }
        this.peopleFilter = {searchBy: value};
    }

    getAllClientsTrafficCourt(userName, login_token) {
        this.userService.getAllClientsTrafficCourt(userName, login_token)
        .subscribe(
            data => {  
                this.clientList = data;
                this.clientNameArray = data;
                //console.log('this.clientList', this.clientList);
                this.clientjsonArray = data;
                this.showPage = true;
                // initialize to page 1
                //this.setPage(1);
            },
            error => {
                this.alertService.error(error);
            });
    }

    setPage(page: number) {
        if (page < 1 || page > this.pager.totalPages) {
            return;
        }
        // get pager object from service
        this.pager = this.pagerService.getPager(this.clientList.length, page);
        // get current page of items
        this.pagedItems = this.clientList.slice(this.pager.startIndex, this.pager.endIndex + 1);
    }

    selectClientFunc($event) {
        //console.log('this.selectedValue: ', this.selectedValue);
        this.searchClient = '';
        this.programStatus = null;
        this.locationType = null;

        this.peopleFilter = {searchBy: ''};
        this.clientList = this.clientjsonArray;
        
        if(this.selectedValue === 'all'){
            this.showLoading = false;
            this.showData = true;
            // initialize to page 1
            //this.setPage(1);
        }
        else if(this.selectedValue !== null)
        {
            //console.log('this.selectedValue: ', this.selectedValue);
            this.clientList = [];
            this.clientList.push(this.selectedValue);
            this.showData = true;
            // initialize to page 1
            //this.setPage(1);
        }
        else if(this.selectedValue === null)
        {
            this.clientList = [];
            this.showData = false;
        }

    }

    getProgramStatusList() {
        this.userService.getProgramStatusList()
        .subscribe(
            data => { 
                //console.log('Program Status: ', data);
                this.programStatusList = data;
            },
            error => {
                this.alertService.error(error);
            });
    }

    getLocationTypeList() {
        this.userService.getLocationTypeList()
        .subscribe(
            data => { 
                this.locationTypeList = data;
            },
            error => {
                this.alertService.error(error);
            });
    }

    selectProgramStatusFunc() {
        //console.log('this.programStatus: ', this.programStatus);
        if(this.programStatus === null)
        {
            this.clientList = [];
            this.showData = false;
        }
        else{
            this.clientList = this.clientjsonArray;
            this.selectedValue = null;
            this.searchClient = '';
            this.locationType = null;
            this.peopleFilter = {searchBy: this.programStatus.STATUS_NAME};
            this.showData = true;
        }
    }
    selectLocationTypeFunc() {
        //console.log('this.locationType: ', this.locationType);
        if(this.locationType === null)
        {
            this.clientList = [];
            this.showData = false;
        }
        else{
            this.clientList = this.clientjsonArray;
            this.selectedValue = null;
            this.searchClient = '';
            this.programStatus = null;
            this.peopleFilter = {searchBy: this.locationType.NAME};
            this.showData = true;
        }
    }

}