﻿import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { AlertService, AuthenticationService, UserService, MessageService } from '../_services/index';
import { Ng2DeviceService } from 'ng2-device-detector';
declare var tableToExcel: any;
import * as jQuery from 'jquery';
declare let $: any;

@Component({
    templateUrl: 'provider.component.html',
    styleUrls: ['./provider.component.css']
})

export class ProviderComponent implements OnInit {
    loginUser: any;
    showPage: boolean;
    userDet: any;
    userInfo: {};
    returnUrl: string;
    providerList = [];
    providerNameArray = [];
    providerJsonArray = [];
    selectedValue = null;
    peopleFilter: any;
    showData: Boolean;
    programStatusList = [];
    locationTypeList = [];
    searchClient: string;
    programStatus = null;
    locationType = null;
    showLoading: Boolean;
    screenHeight: number;
    styleHeight: any;
    deviceInfo = null;

    pageTitle: any;

    // CallFunction1(event, table:string, name:string) {

    //     var dt = new Date();
    //     var day = dt.getDate();
    //     var month = dt.getMonth() + 1;
    //     var year = dt.getFullYear();
    //     var hour = dt.getHours();
    //     var mins = dt.getMinutes();
    //     var seconds = dt.getSeconds();
    //     var postfix = month + "." + day + "." + year + "_" + hour + "." + mins + "." + seconds;
    //     name = name+'_' + postfix;

    //     var result = tableToExcel(event, table, name);
    //     //console.log('export to excel: ', result);
    // }

    exportToExcel(event, table, name:string, fileType:string) {
        
        var dt = new Date();
        var day = dt.getDate();
        var month = dt.getMonth() + 1;
        var year = dt.getFullYear();
        var hour = dt.getHours();
        var mins = dt.getMinutes();
        var seconds = dt.getSeconds();
        var postfix = month + "." + day + "." + year + "_" + hour + "." + mins + "." + seconds;
        name = name+'_' + postfix;

        if(fileType === 'xls')
            tableToExcel(event, table, name);
        else $(table).tableExport({ type: 'csv', escape: false, fileName: name });
    }

    constructor(
        private router: Router, 
        private route: ActivatedRoute,
        private userService: UserService,
        private authenticationService: AuthenticationService,
        private alertService: AlertService,
        private MessageService: MessageService,
        private deviceService: Ng2DeviceService
        ) {
            this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
            this.peopleFilter = {searchBy: ''};
            this.MessageService.sendMessage('CLIENT PROVIDER REPORTS');
    }

    ngOnInit() {
        this.browserDetectFunction();
        this.screenHeight = screen.height - 485;
        this.styleHeight = {
            "max-height" : this.screenHeight+"px"
        };
        this.showPage = false;
        this.showData = false;
        this.showLoading = false;
        this.getProviderQuestionList();

        //this.pageTitle = this.route.snapshot.queryParamMap.get('title');
        //this.pageTitle = this.route.snapshot.paramMap.get('title');
        //console.log('this.pageTitle: ', this.pageTitle);
    }

    browserDetectFunction() {
      this.deviceInfo = this.deviceService.getDeviceInfo();
      //console.log('deviceInfo', this.deviceInfo.browser);
    }

    onSearchChange(value) {
        this.showData = true;
        this.selectedValue = null;
        this.programStatus = null;
        this.locationType = null;
        this.providerList = this.providerJsonArray;
        if(!value)
        {
            this.providerList = [];
            this.showData = false;
        }
        this.peopleFilter = {searchBy: value};
    }

    getProviderQuestionList() {
        this.userService.getProviderQuestionList()
        .subscribe(
            data => { 
                this.providerList = data;
                this.providerNameArray = data;
                this.providerJsonArray = data;
                this.showPage = true;
            },
            error => {
                this.alertService.error(error);
            });
    }

    selectProviderFunc($event) {
        this.searchClient = '';
        this.programStatus = null;
        this.locationType = null;

        this.peopleFilter = {searchBy: ''};
        this.providerList = this.providerJsonArray;

        if(this.selectedValue === 'all'){
            this.showLoading = false;
            this.showData = true;
        }
        else if(this.selectedValue !== null)
        {
            //console.log('this.selectedValue: ', this.selectedValue);

            this.providerList = [];
            this.providerList.push(this.selectedValue);
            this.showData = true;
        }
        else if(this.selectedValue === null)
        {
            this.providerList = [];
            this.showData = false;
        }
        
    }

}