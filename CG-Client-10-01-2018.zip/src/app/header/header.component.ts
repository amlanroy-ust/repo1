import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AlertService, UserService, AuthenticationService, MessageService } from '../_services/index';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {

  loginUser: any = {};
  pageHeading: any;
  returnUrl: string;
  subscription: Subscription;
  messageSubscription: Subscription;
  //pageTitle: any;
  pageTitle: any;
        
  constructor(
      private route: ActivatedRoute,
      private router: Router,
      private userService: UserService,
      private AuthenticationService: AuthenticationService,
      private alertService: AlertService,
      private MessageService: MessageService
      ) {
      //console.log('Header component is working');
      this.subscription = this.AuthenticationService.getMessage().subscribe(loginUser => { this.loginUser = loginUser.text; });

    //   this.subscription = route.queryParams.subscribe(
    //          (queryParam: any) => this.pageTitle = queryParam['title']
    //      );
      
  }

  ngOnInit() {
        this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
        // subscribe to home component messages
        this.messageSubscription = this.MessageService.getMessage().subscribe(message => { this.pageHeading = message.text; });

        // this.pageTitle = this.route.snapshot.queryParamMap.get('title');
        // console.log('this.pageTitle: ', this.pageTitle);

        // this.pageTitle = this.route.params.subscribe(params => {
        //     this.title = +params['title']; // (+) converts string 'id' to a number
        // });

        // this.router.events
        // .subscribe((event) => {
        // // example: NavigationStart, RoutesRecognized, NavigationEnd
        // //console.log(event);
        // this.pageTitle = event;
        // console.log('this.pageTitle: ', this.pageTitle);
        
        // });
        // console.log('this.pageTitle1: ', this.pageTitle);
    }

    logout() {
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/login';
        this.AuthenticationService.logout()
        .subscribe(
            data => {
                this.router.navigate([this.returnUrl]);
            },
            error => {
                this.alertService.error(error);
            });
    }

    ngOnDestroy() {
        // unsubscribe to ensure no memory leaks
        this.subscription.unsubscribe();
    }
}
