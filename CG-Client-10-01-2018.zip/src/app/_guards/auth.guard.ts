﻿import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Http, Headers, Response } from '@angular/http';
import { AuthenticationService } from '../_services/index';
import 'rxjs/add/operator/map';

@Injectable()
export class AuthGuard implements CanActivate {
    loginUser: any;
    constructor(private router: Router, private http: Http, private authenticationService: AuthenticationService) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        if (localStorage.getItem('currentUser')) {
            this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
            //this.userService.validateToken(this.loginUser.userName, this.loginUser.login_token)
            
            return this.http.get('/api/validateToken/'+this.loginUser.userName+'/'+this.loginUser.login_token)
            .map((response: Response) => {
                // login successful if there's a jwt token in the response
                let data = response.json();
                if (data) {
                    //console.log('data details: ', data);
                    if(data.CHECKCOUNT === 1)
                    {
                        return true;
                    }
                    else {
                            if(this.loginUser !== null)
                            {
                                this.authenticationService.setMessage();
                                this.router.navigate(['/login'], { queryParams: { returnUrl: state.url }});
                            }
                            this.router.navigate(['/login'], { queryParams: { returnUrl: state.url }});
                            return false;

                            // this.router.navigate(['/login'], { queryParams: { returnUrl: state.url }});
                            // return false;
                    }
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                }
                //return true;
            });
            
            // logged in so return true
            //return true; 
        }
        // not logged in so redirect to login page with the return url
        this.router.navigate(['/login'], { queryParams: { returnUrl: state.url }});
        return false;
    }

}