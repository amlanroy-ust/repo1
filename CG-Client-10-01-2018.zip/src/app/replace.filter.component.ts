import { Pipe, PipeTransform } from '@angular/core';
@Pipe({name: 'replaceLineBreaks'})
export class ReplaceLineBreaks implements PipeTransform {
  transform(value: string): string {
    //let newValue = value.replace(/\n/g, '<br/>');
    let newValue = '';
    if(value === 'A')
      newValue = value.replace('A', 'Active');
    else if(value === 'I')
      newValue = value.replace('I', 'In-active');
    else if(value === 'M')
      newValue = value.replace('M', 'Male');
    else if(value === 'F')
      newValue = value.replace('F', 'Female');
    else if(value === 'T')
      newValue = value.replace('T', 'Transgender');
    return `${newValue}`;
  }
}