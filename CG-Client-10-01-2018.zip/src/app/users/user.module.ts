import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { UserComponent }   from './user.component';
import { routing } from './user.routing';

@NgModule({
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    routing
  ],
  declarations: [UserComponent]
})
export class UserModule {}