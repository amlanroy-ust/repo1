﻿import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { AlertService, AuthenticationService, UserService, MessageService } from '../_services/index';
import { Ng2DeviceService } from 'ng2-device-detector';
declare var tableToExcel: any;
import * as jQuery from 'jquery';
declare let $: any;

@Component({
    templateUrl: 'user.component.html',
    styleUrls: ['./user.component.css']
})

export class UserComponent implements OnInit {
    loginUser: any;
    showPage: boolean;
    userDet: any;
    userInfo: {};
    returnUrl: string;
    providerList = [];
    providerNameArray = [];
    providerJsonArray = [];
    selectedValue = null;
    peopleFilter: any;
    showData: boolean;
    programStatusList = [];
    locationTypeList = [];
    searchClient: string;
    programStatus = null;
    locationType = null;
    showLoading: boolean;
    screenHeight: number;
    styleHeight: any;
    deviceInfo = null;
    showModal: boolean;

    constructor(
        private router: Router, 
        private route: ActivatedRoute,
        private userService: UserService,
        private authenticationService: AuthenticationService,
        private alertService: AlertService,
        private MessageService: MessageService,
        private deviceService: Ng2DeviceService
        ) {
            this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
            this.peopleFilter = {searchBy: ''};
            this.MessageService.sendMessage('CLIENT PROVIDER REPORTS');
    }

    ngOnInit() {
        this.browserDetectFunction();
        this.screenHeight = screen.height - 485;
        this.styleHeight = {
            "max-height" : this.screenHeight+"px"
        };
        this.showPage = false;
        this.showData = false;
        this.showLoading = false;
        this.getProviderQuestionList();
        this.showModal = false;
    }

    browserDetectFunction() {
      this.deviceInfo = this.deviceService.getDeviceInfo();
      //console.log('deviceInfo', this.deviceInfo.browser);
    }

    onSearchChange(value) {
        console.log('value: ', value);
        // this.showData = true;
        // this.selectedValue = null;
        // this.programStatus = null;
        // this.locationType = null;
        // this.providerList = this.providerJsonArray;
        // if(!value)
        // {
        //     this.providerList = [];
        //     this.showData = false;
        // }
        // this.peopleFilter = {searchBy: value};
    }

    getProviderQuestionList() {
        this.userService.getProviderQuestionList()
        .subscribe(
            data => { 
                this.providerList = data;
                this.providerNameArray = data;
                this.providerJsonArray = data;
                this.showPage = true;
            },
            error => {
                this.alertService.error(error);
            });
    }

    formModal(active) {
        console.log('active', active);
        this.showModal = active;
    }

}