function tableToExcel(e, table, filename) {

    if(isIE())
      { 
          var uri = 'data:application/vnd.ms-excel;base64,'
          , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
          , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
          , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
            
              if (!table.nodeType) table = document.getElementById(table)
              var ctx = {worksheet: name || filename, table: table.innerHTML}
              var blob = new Blob([format(template, ctx)]);
              var blobURL = window.URL.createObjectURL(blob);
              
              csvData = table.innerHTML;
                if (window.navigator.msSaveBlob) {
                    var blob = new Blob([format(template, ctx)], {
                        type: "text/html"
                    });
                    navigator.msSaveBlob(blob, ''+filename+'.xls');
                    return true;
                }
      }
    else
      { 
        // var uri = 'data:application/vnd.ms-excel;base64,'
        //   , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
        //   , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
        //   , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }

        // if (!table.nodeType) table = document.getElementById(table)
        // var ctx = {worksheet: name || filename, table: table.innerHTML}
        // var link = document.createElement('a');
        // link.href = uri + base64(format(template, ctx));
        // link.download = filename + '.xls';
        // document.body.appendChild(link);
        
        // if(link.click)
        //     link.click();
        // else if(document.createEvent)
        // {
        //     var eventObj = document.createEvent('MouseEvents');
        //     eventObj.initEvent('click',true,true);
        //     link.dispatchEvent(eventObj);
        // }
        // return true;

        var html = document.querySelector("table").outerHTML;
	    export_table_to_csv(html, "table.csv");

    }
      
  }

function isIE()
 {
     var isIE11 = navigator.userAgent.indexOf(".NET CLR") > -1;      
     var isIE11orLess = isIE11 || navigator.appVersion.indexOf("MSIE") != -1;
     return isIE11orLess;
 }

 function download_csv(csv, filename) {
    var csvFile;
    var downloadLink;

    // CSV FILE
    csvFile = new Blob([csv], {type: "text/csv"});

    // Download link
    downloadLink = document.createElement("a");

    // File name
    downloadLink.download = filename;

    // We have to create a link to the file
    downloadLink.href = window.URL.createObjectURL(csvFile);

    // Make sure that the link is not displayed
    downloadLink.style.display = "none";

    // Add the link to your DOM
    document.body.appendChild(downloadLink);

    // Lanzamos
    downloadLink.click();
}

function export_table_to_csv(html, filename) {
	var csv = [];
	var rows = document.querySelectorAll("table tr");
	
    for (var i = 0; i < rows.length; i++) {
		var row = [], cols = rows[i].querySelectorAll("td, th");
		
        for (var j = 0; j < cols.length; j++) 
            row.push(cols[j].innerText);
        
		csv.push(row.join(","));		
	}

    // Download CSV
    download_csv(csv.join("\n"), filename);
}