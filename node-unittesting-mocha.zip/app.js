//Load express module with `require` directive
var express = require('express')
var app = express()
var EventEmitter = require('events');
var fs = require('fs');
var readline = require('readline');


app.use('/public', express.static(__dirname + '/public'));
//console.log(__dirname + '/uploads');

//Define request response in root URL (/)
app.get('/', function (req, res) {
  res.send('Hello World!');
})

app.get('/about', function (req, res) {
  res.send('About Node Js.');
})

app.get('/write-file', function (req, res) {
  
  const file = fs.createWriteStream('./public/test.txt');

  for(let i=0; i<= 5; i++) {
    file.write('Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n');
  }
  file.end();
  res.send('File Written!');
})

app.get('/read-file', function (req, res) {
  // fs.readFile('./public/test.txt', (err, data) => {
  //   if (err) throw err;
  //   res.end(data);
  // });

  const src = fs.createReadStream('./public/test.txt');
  console.log('Reading file...');
  //console.log(res);
  src.pipe(res);
  console.log('End Reading file...');
})

app.get('/test-event-emitter', function (req, res) {

    // simple event-driven state machine
    const sm = new EventEmitter();

    // running state
    let context={
      tasks:    0,    // number of total tasks
      active:   0,    // number of active tasks
      results:  []    // task results
    };

    const next = (result) => { // must be called when each task chain completes

      if(result) { // preserve result of task chain
        context.results.push(result);
      }

      // decrement the number of running tasks
      context.active -= 1; 
 
      // when all tasks complete, trigger done state
      if(!context.active) { 
        sm.emit('done');
      }
    };

    // operational states
    // start state - initializes context
    sm.on('start', (paths) => {
      const len=paths.length;

      console.log(`start: beginning processing of ${len} paths`);

      context.tasks = len;              // total number of tasks
      context.active = len;             // number of active tasks

      sm.emit('forEachPath', paths);    // go to next state
    });

    // start processing of each path
    sm.on('forEachPath', (paths)=>{

      console.log(`forEachPath: starting ${paths.length} process chains`);

      paths.forEach((path) => sm.emit('readPath', path));
    });

    // read contents from path
    sm.on('readPath', (path) => {

      console.log(`  readPath: ${path}`);

      // fs.readFile('./public/'+path,(err,buf) => {
      //   if(err) {
      //     sm.emit('error',err);
      //     return;
      //   }
      //   sm.emit('processContent', buf.toString(), path);
      // });

      var rl = readline.createInterface({
          input : fs.createReadStream('./public/'+path),
          output: process.stdout,
          terminal: false
      })
      rl.on('error', function(err){ 
        /*handle error*/ 
        throw err;
      });
      rl.on('line',function(line){
          console.log('line.length: ', line.length) //or parse line
          sm.emit('processContent', line, path);
      })

    });

    // compute length of path contents
    sm.on('processContent', (str, path) => {
      //JSON.stringify(res)
      console.log(`Contents: ${str}`);
      console.log(`processContent: ${path}`);

      next(str.length);
      //next(str);
    });

    // when processing is complete
    sm.on('done', () => { 
      const total = context.results.reduce((sum,n) => sum + n);
      console.log(`The total of ${context.tasks} files is ${total}`);
      res.send(`The total of ${context.tasks} files is ${total}`);
    });

    // error state
    sm.on('error', (err) => { 
      throw err;
      //console.log(`Error handling: ${err}`); 
    });

    // ======================================================
    // start processing - ok, let's go
    // ======================================================
    sm.emit('start', ['file1.txt','file2.txt','file3.txt','file4.txt']);

})

//Launch listening server on port 8080
app.listen(8080, function () {
  console.log('App listening on port 8080!');
})