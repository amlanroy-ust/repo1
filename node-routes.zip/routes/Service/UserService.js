var User = require('../../models/users');

//var mime = require('mime');
var config = require('../../config');
//var path = require('path');
var secretKey = config.secret;

//var jwt = require('jsonwebtoken');

var async = require("async");

//var fs      = require('fs');
//var random  = require('randomstring');

//require('mongoose-pagination');

var UserService = {
    
    //****************Start to Create a new user from front end*******************//
    createuser: function(user, callback){                     
              
                async.waterfall([
                
                    function (nextcb){
                        var customError = {
                            message: ""
                        };
                        if(typeof(user.email) !== 'undefined' && user.email !== ""){
                        User.count({email: user.email}, function(err, count){
                            if(err)
                                nextcb(err);
                            else {
                                if(count > 0){
                                    customError.message = "Email-ID already registered";
                                }
                                nextcb(null, customError);
                            }
                        });
                        }else{
                        nextcb(null, customError);
                        }
                    },
                    
                    function(cErr, nextcb){
                    var customError = {
                        message: ""
                    };
                    if(cErr.message !== ""){
                        nextcb(null, cErr);
                    } else {
                        if(user.name === ""){                                          
                            //console.log("user.username : "+user.username);                                                                                    
                                   
                                customError.message = "name is required";
                                   
                                nextcb(null, customError);                                              
                           
                        }else{
                            nextcb(null, customError);
                        }
                    }
                },
                
                function(cErr, nextcb){
                    var customError = {
                        message: ""
                    };
                    if(cErr.message !== ""){
                        nextcb(null, cErr);
                    } else {
                        if(typeof(user.email) !== 'undefined' && user.email !== ""){                                      
                            //console.log("user.password : "+user.password);
                            var x = user.email;
                            var atpos = x.indexOf("@");
                            var dotpos = x.lastIndexOf(".");
                            if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {
                                customError.message = "Not a valid e-mail address";
                            }                                                                                             
                                   
                            nextcb(null, customError);                                              
                           
                        }else{
                            nextcb(null, customError);
                        }
                    }
                },
                function(cErr, nextcb){
                    var customError = {
                        message: ""
                    };
                    if(cErr.message !== ""){
                        nextcb(null, cErr);
                    } else {
                        if(user.password === ""){                                          
                            //console.log("user.username : "+user.username);                                                                                    
                                   
                                customError.message = "password is required";
                                   
                                nextcb(null, customError);                                              
                           
                        }else{
                            nextcb(null, customError);
                        }
                    }
                },
         
                function(cErr, nextcb){
                            var customError = {
                                message: ""
                            };
                            var data = {};
                            if(cErr.message !== ""){
                                nextcb(null, cErr);
                            } else {
                                
                                var userData = new User(user);
        
                                //console.log(userData);
                                
                                userData.save(function(err){
                                    if(err){
                                        //console.log(err);
                                       callback({success: false, message: err});
                                    } else {
                                        callback({success: true, message: "user saved successfully"});
                                    }
                                });
                                
                            }
                        }
                
                ], function(err, cError, data){
                        if(err){
                            callback({success: false, message: "some error occurred", err: err});
                        }
                        else if(cError.message !== ""){
                            callback({success: false, message: cError.message});
                        }
                        else {
                            callback(data);
                        }
                    });
                              
            
    }
    //****************End of Create a new user from front end*******************//
  
};

module.exports = UserService;