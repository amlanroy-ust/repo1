var express = require('express');
var router = express.Router();
var mongojs = require('mongojs');
var fs = require('fs');

var User = require('../models/users');

var userDet = {
        id: null,
        email: null,
        name: null,
        authenticated: false
    };

        //=================
        //  Get user-agent information about device, location etc
        //=================
        
        router.get('/user-agent', function(req, res){
            var UAParser = require('ua-parser-js');
            var parser = new UAParser();
            console.log(req.headers);
            var ua = req.headers['user-agent'];     // user-agent header from an HTTP request
            console.log(parser.setUA(ua).getResult());
        });
        
        /*****************Start of front end New User Registration function**********************/

        /********************
             *  User Registration
             *  @method: POST
             *  request data:     
             *      name,
             *      email,
             *      password,
             *      
             *  @url: /addfrontuser
             *      
             ********************/

        router.post('/registration', function (req, res) {
                //console.log(req.files);
                
                var user = req.body;
                //console.log(user);
                //console.log(fileData);
                       
                var userData = new User(user);
        
                //console.log(userData);
                
                //userData.save(function(err){
                //    if(err){
                //        console.log(err);
                //        throw err;
                //       
                //    } else {
                //        console.log('user saved successfully');
                //        res.json({success: true, message: "user saved successfully"});
                //    }
                //});
                
                var userService = require('./Service/UserService');
        
                userService.createuser(userData, function (response) {
                   res.json(response);
                   //res.render('front/index', {success: true, message: "error message here", title: "Home"});
               });
                 
                         
        });
        /*****************End of New User Registration function**********************/

        /*****************Start of front end Login function**********************/
            /**
             * Start User Login
             * 
             * @requestparams
             *      email
             *      password
             *      
             *  $request_url: /api/login
             */
            
            router.post('/frontLogin', function (req, res) {
                User.findOne({email: req.body.email})
                        .select('email password name')
                        .exec(function (err, user) {
                    if (err) {
                        throw err;
                    }
            
                    if (!user) {
                        res.json({success: false, message: "user doesn't exist"});
                    } else if (user) {
                        var validPassword = user.comparePassword(req.body.password);
                        if (!validPassword) {
                            res.json({success: false, message: "Invalid password"});
                        } else {
            
                            //Updating the last login time and is logged in
                            var conditions = {_id: user.id},
                            fields = {last_login: Date.now(), is_logged_in: true},
                            options = {upsert: false};
            
                            User.update(conditions, fields, options, function (err, affected) {
                                if (err) {
                                    throw err;
                                } else {
                                    user.last_login = fields.last_login;
                                }
                            });
                            req.session.user = {};
                            var userDet = {
                                id: user._id,
                                email: user.email,
                                name: user.name,
                                authenticated: true
                            };
                            //console.log('userDet',userDet);
                            req.session.user = userDet;
                            console.log('session',req.session.user);
                            res.json({success: true, message: "successfully logged in"});
                                
                        }
                    }
                });
            });
        /*****************End of Login function**********************/
        
//======================
// Start Middleware to check the front end login session
//=========================

function checkLogin(req, res, next) {
    var userDet = req.session.user;
    //console.log('userDet check in front routes', userDet);
    
    //if (userDet && userDet.authenticated)
    
    if (typeof(userDet) !== 'undefined') {
        console.log('userDet', userDet);
        req.session.user = userDet;
        console.log('session exists', req.session.user);
        return next();
    } else {
        res.redirect('/');
        //res.render('index.html');
        //console.log('session out', userDet);
        //res.send({success: false, message: "No session found"});
    }
}

//======================
// End of Middleware to check the front end login session
//=========================

        // Get All Users
        router.get('/users', function(req, res){
            
            User.find(function(err, users){
                if(err){
                    res.send(err);
                }
                res.json(users);
            });
            
            //res.json({"Result":"successful"});
        });

        // Get Single User
        router.get('/user/:id', checkLogin, function(req, res){
            User.findOne({_id: mongojs.ObjectId(req.params.id)}, function(err, user){
                if(err){
                    res.send(err);
                }
                res.json(user);
            });
        });

        //=================
        // Logout function
        //=================
        router.get('/logout', checkLogin, function (req, res) {
            //res.send(req.session);
            req.session.destroy(function (err) {
                if (err) {
                    res.send(err);
                    console.log('Error', err);
                } else {
                    //res.redirect('/');
                    console.log('successfully logged out');
                    //res.json({success: true, message: "successfully logged out"});
                    res.render('index.html');
                }
            });
        });
        
        // Get personal info
        router.get('/personalInfo', checkLogin, function(req, res){
            var content = fs.readFileSync(__dirname+"/Service/personalInfo.json");
            //console.log("Output Content : \n"+ content);
            var jsonContent = JSON.parse(content);
            res.json(jsonContent);
        });
        
        // Get education info
        router.get('/educationInfo', checkLogin, function(req, res){
            var content = fs.readFileSync(__dirname+"/Service/educationInfo.json");
            var jsonContent = JSON.parse(content);
            res.json(jsonContent);
        });
        
        //Get qualification Info
        router.get('/qualificationInfo', checkLogin, function(req, res){
            var content = fs.readFileSync(__dirname+"/Service/qualificationInfo.json");
            var jsonContent = JSON.parse(content);
            res.json(jsonContent);
        });
        
        //Get work Info
        router.get('/workInfo', checkLogin, function(req, res){
            var content = fs.readFileSync(__dirname+"/Service/workInfo.json");
            var jsonContent = JSON.parse(content);
            res.json(jsonContent);
        });
        
        //Get project Info
        router.get('/projectInfo', checkLogin, function(req, res){
            var content = fs.readFileSync(__dirname+"/Service/projectInfo.json");
            var jsonContent = JSON.parse(content);
            res.json(jsonContent);
        });
        
        //Get certificate Info
        router.get('/certificateInfo', checkLogin, function(req, res){
            var content = fs.readFileSync(__dirname+"/Service/certificateInfo.json");
            var jsonContent = JSON.parse(content);
            res.json(jsonContent);
        });
        
        //Get award Info
        router.get('/awardInfo', checkLogin, function(req, res){
            var content = fs.readFileSync(__dirname+"/Service/awardInfo.json");
            var jsonContent = JSON.parse(content);
            res.json(jsonContent);
        });
        
module.exports = router;