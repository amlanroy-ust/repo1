var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var config = require('./config');
var cookieParser = require('cookie-parser');
var session = require('express-session');

var index = require('./routes/index');
var users = require('./routes/users');

var port = 4140;
//Connecting with database
mongoose.connect(config.database, function(err){
    if(err){
        console.log(err)
    } else{
        console.log('Connected to database ' + config.database);
    }
});
var app = express();

//View Engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.engine('html', require('ejs').renderFile);

// Set Static Folder
app.use(express.static(path.join(__dirname, 'client')));

// Body Parser MW
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

var timeOut = 2 * 3600 * 1000;
//var timeOut = 60 * 10000;
app.use(cookieParser());
app.use(session({ secret: '21432432432fsdf32432', cookie: { maxAge: timeOut }}))

app.use('/', index);
app.use('/api', users);

app.listen(port, function(){
    console.log('Server started on port '+port);
});