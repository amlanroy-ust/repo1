module.exports = {
    port: process.env.PORT || 4140,
    database : 'mongodb://127.0.0.1:27017/profcreate',   //localhost
    
    secret : 'hyrgqwjdfbw4534efqrwer2q38945892',
    dev_mode : true,
    __root_dir: __dirname,
    __site_url: 'http://localhost:4140/'

};