import {Pipe, PipeTransform} from '@angular/core'

@Pipe({
    name: 'filter'
})
export class FilterPipe implements PipeTransform {
    transform(items: Array<any>, filter: {[key: string]: any }): Array<any> {
        return items.filter(item => {
                //console.log(item.name); 
                //console.log('filter searchBy: ', filter.searchBy);
                //console.log('parseInt(filter.searchBy): ', parseInt(filter.searchBy));

                //let notMatchingField = Object.keys(filter).find(key => item[key] !== filter[key]);
                //console.log(str.indexOf(filter.name)); 
                //let str = item.name;
                if (item.NAME !== null && filter.searchBy !== null && item.NAME != undefined && item.NAME.toLowerCase().indexOf(filter.searchBy.toLowerCase()) >= 0)
                {
                  //console.log('1'); 
                  return true;
                }
                else if (item.FIRST_NAME !== null && filter.searchBy !== null && item.FIRST_NAME != undefined && item.FIRST_NAME.toLowerCase().indexOf(filter.searchBy.toLowerCase()) >= 0)
                {
                  //console.log('2'); 
                  return true;
                }
                else if (item.LAST_NAME !== null && filter.searchBy !== null && item.LAST_NAME != undefined && item.LAST_NAME.toLowerCase().indexOf(filter.searchBy.toLowerCase()) >= 0)
                {
                  //console.log('3'); 
                  return true;
                }
                else if (item.CLIENT_ID != undefined && parseInt(item.CLIENT_ID) === parseInt(filter.searchBy))
                {
                  //console.log('4');
                  return true;
                }
                else if (item.CLIENT_ID != undefined && parseInt(item.CLIENT_ID) === filter.searchBy)
                {
                  //console.log('5');
                  return true;
                }
                else if (item.LOCATION_TYPE !== null && filter.searchBy !== null && item.LOCATION_TYPE != undefined && item.LOCATION_TYPE.toLowerCase().indexOf(filter.searchBy.toLowerCase()) >= 0)
                {  
                  //console.log('6');
                  return true;
                }
                else if (item.PROGRAM_STATUS !== null && filter.searchBy !== null && item.PROGRAM_STATUS != undefined && filter.searchBy !== '' && item.PROGRAM_STATUS.toLowerCase() === filter.searchBy.toLowerCase())
                {
                  //console.log('7');
                  return true;
                }
                // else if (filter.searchBy !== null && item.surveyData != undefined && filter.searchBy !== '')
                // {
                //   console.log('7');
                //   return item.surveyData.filter(surv => {
                //       if (surv.SURVEY_NAME !== null && filter.searchBy !== null && surv.SURVEY_NAME != undefined && surv.SURVEY_NAME.toLowerCase().indexOf(filter.searchBy.toLowerCase()) >= 0)
                //       {
                //         console.log('7, 1'); 
                //         return true;
                //       }
                //   });
                //   //return true;
                // }
                else 
                {
                  //console.log('8');
                  //return false;
                }
                //return !notMatchingField; // true if matches all fields
            });
    }
}