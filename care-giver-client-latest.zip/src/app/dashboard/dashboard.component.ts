﻿import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit, Injectable } from '@angular/core';
import { AlertService, AuthenticationService, UserService, MessageService } from '../_services/index';
declare var tableToExcel: any;
// import $ from 'jquery';

import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';

@Injectable()

@Component({
    templateUrl: 'dashboard.component.html',
    styleUrls: ['./dashboard.component.css']
})

export class DashboardComponent implements OnInit {
    loginUser: any;
    showPage: boolean;
    userDet: any;
    userInfo: {};
    returnUrl: string;
    clientList = [];
    clientNameArray = [];
    //clientJson: any = {};
    clientjsonArray = [];
    selectedValue = null;
    peopleFilter: any;
    showData: Boolean;
    showLoading: Boolean;
    programStatusList = [];
    locationTypeList = [];
    searchClient: string;
    programStatus = null;
    locationType = null;
    dataTable = [];

    CallFunction1(event, table:string, name:string) {
        
        var dt = new Date();
        var day = dt.getDate();
        var month = dt.getMonth() + 1;
        var year = dt.getFullYear();
        var hour = dt.getHours();
        var mins = dt.getMinutes();
        var seconds = dt.getSeconds();
        var postfix = month + "." + day + "." + year + "_" + hour + "." + mins + "." + seconds;
        name = name+'_' + postfix;

        tableToExcel.func1(event, table, name);
    }

    constructor(
        private router: Router, 
        private route: ActivatedRoute,
        private userService: UserService,
        private authenticationService: AuthenticationService,
        private alertService: AlertService,
        private MessageService: MessageService
        ) {
            this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
            //console.log('this.loginUser', this.loginUser);
            this.peopleFilter = {searchBy: ''};
            this.MessageService.sendMessage('CLIENT PROFILE REPORTS');
    }

    ngOnInit() {
        this.showPage = false;
        this.showData = false;
        this.getAllClientsTrafficCourt(this.loginUser.userName, this.loginUser.login_token);
        this.getProgramStatusList();
        this.getLocationTypeList();
    }

    onSearchChange(value) {
        this.showData = true;
        this.showLoading = false;
        this.selectedValue = null;
        this.programStatus = null;
        this.locationType = null;
        this.clientList = this.clientjsonArray;
        if(!value)
        {
            this.clientList = [];
            //this.clientList = this.clientjsonArray;
            this.showData = false;
        }
        this.peopleFilter = {searchBy: value};
    }

    getAllClientsTrafficCourt(userName, login_token) {
        this.userService.getAllClientsTrafficCourt(userName, login_token)
        .subscribe(
            data => {  
                this.clientList = data;
                this.clientNameArray = data;
                //console.log('this.clientList', this.clientList);
                this.clientjsonArray = data;
                this.showPage = true;
            },
            error => {
                this.alertService.error(error);
            });
    }

    selectClientFunc($event) {
        //console.log('this.selectedValue: ', this.selectedValue);
        this.searchClient = '';
        this.programStatus = null;
        this.locationType = null;

        this.peopleFilter = {searchBy: ''};
        this.clientList = this.clientjsonArray;
        
        if(this.selectedValue === 'all'){
            this.showLoading = false;
            this.showData = true;
        }
        else if(this.selectedValue !== null)
        {
            this.clientList = [];
            this.clientList.push(this.selectedValue);
            this.showData = true;
        }
        else if(this.selectedValue === null)
        {
            this.clientList = [];
            this.showData = false;
        }
    }

    getProgramStatusList() {
        this.userService.getProgramStatusList()
        .subscribe(
            data => { 
                //console.log('Program Status: ', data);
                this.programStatusList = data;
            },
            error => {
                this.alertService.error(error);
            });
    }

    getLocationTypeList() {
        this.userService.getLocationTypeList()
        .subscribe(
            data => { 
                this.locationTypeList = data;
            },
            error => {
                this.alertService.error(error);
            });
    }

    selectProgramStatusFunc() {
        //console.log('this.programStatus: ', this.programStatus);
        if(this.programStatus === null)
        {
            this.clientList = [];
            this.showData = false;
        }
        else{
            this.clientList = this.clientjsonArray;
            this.selectedValue = null;
            this.searchClient = '';
            this.locationType = null;
            this.peopleFilter = {searchBy: this.programStatus.STATUS_NAME};
            this.showData = true;
        }
    }
    selectLocationTypeFunc() {
        //console.log('this.locationType: ', this.locationType);
        if(this.locationType === null)
        {
            this.clientList = [];
            this.showData = false;
        }
        else{
            this.clientList = this.clientjsonArray;
            this.selectedValue = null;
            this.searchClient = '';
            this.programStatus = null;
            this.peopleFilter = {searchBy: this.locationType.NAME};
            this.showData = true;
        }
    }

}