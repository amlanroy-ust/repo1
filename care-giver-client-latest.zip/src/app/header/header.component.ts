import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AlertService, UserService, AuthenticationService, MessageService } from '../_services/index';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {

  loginUser: any = {};
  pageHeading: any;
  returnUrl: string;
  subscription: Subscription;
  messageSubscription: Subscription;
        
  constructor(
      private route: ActivatedRoute,
      private router: Router,
      private userService: UserService,
      private AuthenticationService: AuthenticationService,
      private alertService: AlertService,
      private MessageService: MessageService
      ) {
      //console.log('Header component is working');
      this.subscription = this.AuthenticationService.getMessage().subscribe(loginUser => { this.loginUser = loginUser.text; });
  }

  ngOnInit() {
        this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
        // subscribe to home component messages
        this.messageSubscription = this.MessageService.getMessage().subscribe(message => { this.pageHeading = message.text; });
    }

    logout() {
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/login';
        this.AuthenticationService.logout()
        .subscribe(
            data => {
                this.router.navigate([this.returnUrl]);
            },
            error => {
                this.alertService.error(error);
            });
    }

    ngOnDestroy() {
        // unsubscribe to ensure no memory leaks
        this.subscription.unsubscribe();
    }
}
