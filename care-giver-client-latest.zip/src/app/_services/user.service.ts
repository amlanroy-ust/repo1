﻿import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';

//import { User } from '../_models/index';

@Injectable()
export class UserService {
    constructor(private http: Http) { }

    loginService(userDet) {
        //console.log('loginService');
        return this.http.post('/api/loginService', userDet).map((response: Response) => response.json());
    }

    validateToken(userName, token) {
        return this.http.get('/api/validateToken/'+userName+'/'+token).map((response: Response) => response.json());
    }

    getClientList() {
        // console.log('userName ', userName);
        // console.log('token ', token);
        return this.http.get('/api/getClientList').map((response: Response) => response.json());
    }

    getAllClientsTrafficCourt(userName, token) {
        // console.log('userName ', userName);
        // console.log('token ', token);
        return this.http.get('/api/getAllClientsTrafficCourt/'+userName+'/'+token).map((response: Response) => response.json());
    }

    getClientTrafficDetails(clientID) {
        return this.http.get('/api/getClientTrafficDetails/'+clientID).map((response: Response) => response.json());
    }

    getClientCourtDetails(clientID) {
        return this.http.get('/api/getClientCourtDetails/'+clientID).map((response: Response) => response.json());
    }

    getProgramStatusList() {
        return this.http.get('/api/getProgramStatusList').map((response: Response) => response.json());
    }

    getLocationTypeList() {
        return this.http.get('/api/getLocationTypeList').map((response: Response) => response.json());
    }

    getClientSurveyDetailsList() {
        return this.http.get('/api/getClientSurveyDetailsList').map((response: Response) => response.json());
    }

    getMilestoneList() {
        return this.http.get('/api/getMilestoneList').map((response: Response) => response.json());
    }

    getSurveyList() {
        return this.http.get('/api/getSurveyList').map((response: Response) => response.json());
    }

    getProviderQuestionList() {
        return this.http.get('/api/getProviderQuestionList').map((response: Response) => response.json());
    }
}