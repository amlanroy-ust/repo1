﻿import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map';

@Injectable()
export class AuthenticationService {
    loginUser: any;
    private subject = new Subject<any>();

    constructor(private http: Http) { }

    login(username: string, password: string) {
        return this.http.post('/api/login', { username: username, password: password })
            .map((response: Response) => {
                // login successful if there's a jwt token in the response
                let user = response.json();
                if (user && user.token) {
                    //console.log('user details: ', user);
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    localStorage.setItem('currentUser', JSON.stringify(user));
                    this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
                    this.subject.next({ text: this.loginUser });
                }
                return user;
            });
    }

    sendMessage(message: string) {
        this.subject.next({ pageHeading: message });
    }
    
    getMessage(): Observable<any> {
        return this.subject.asObservable();
    }

    logout() {
        // remove user from local storage to log user out
        this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
        //console.log('logout...', this.loginUser);
        if(this.loginUser !== null)
        {
            //console.log('entered...', this.loginUser);
            return this.http.post('/api/logout', { userName: this.loginUser.userName })
                .map((response: Response) => {
                    // login successful if there's a jwt token in the response
                    //console.log('response.json(): ', response.json());
                    localStorage.removeItem('currentUser');
                    this.loginUser = {};
                    this.subject.next({ text: this.loginUser });
                });
        }
    }
}