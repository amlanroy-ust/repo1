import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AlertService, UserService, AuthenticationService } from '../_services/index';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {
  showPage: Boolean;
  loginUser: any = {};
  returnUrl: string;
  subscription: Subscription;
        
  constructor(
      private route: ActivatedRoute,
      private router: Router,
      private userService: UserService,
      private AuthenticationService: AuthenticationService,
      private alertService: AlertService
      ) {
      //console.log('Menu component is working');
      this.subscription = this.AuthenticationService.getMessage().subscribe(loginUser => { this.loginUser = loginUser.text; });
  }

  ngOnInit() {
        this.showPage = false;
        setTimeout(()=>{
            this.showPage = true;
        },7000)
        this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
    }

    logout() {
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/login';
        this.AuthenticationService.logout()
        .subscribe(
            data => {
                this.router.navigate([this.returnUrl]);
            },
            error => {
                this.alertService.error(error);
            });
    }
}
