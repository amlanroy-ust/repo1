/* SystemJS module definition */
declare var module: NodeModule;
//declare var tableToExcel:any;
declare var jQuery:any;
declare var $:any;
interface NodeModule {
  id: string;
}
