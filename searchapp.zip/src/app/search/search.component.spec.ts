import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SearchComponent } from './search.component';
import { SearchService } from '../shared/index';
import { HttpModule } from '@angular/http';

describe('SearchComponent', () => {
  
  let expected = "";

  beforeEach(async(() => {
    
    expected = "Hello world!";

    TestBed.configureTestingModule({
      declarations: [
        SearchComponent
      ],
      imports: [ RouterTestingModule, FormsModule, ReactiveFormsModule, HttpModule ],
      providers: [ SearchService ]
    }).compileComponents();
  }));

  afterEach(async(() => {
    expected = "";
  }));

  it('should create the Search app', async(() => {
    const fixture = TestBed.createComponent(SearchComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));

  it('says hello', async(() => {
    const fixture = TestBed.createComponent(SearchComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.helloWorldFunc()).toEqual(expected);
  }));

  // it(`should have as title 'app'`, async(() => {
  //   const fixture = TestBed.createComponent(SearchComponent);
  //   const app = fixture.debugElement.componentInstance;
  //   expect(app.title).toEqual('Welcome to app!!');
  // }));

  // it('should render title in a h1 tag', async(() => {
  //   const fixture = TestBed.createComponent(SearchComponent);
  //   fixture.detectChanges();
  //   const compiled = fixture.debugElement.nativeElement;
  //   expect(compiled.querySelector('h1').textContent).toContain('Welcome to app!!');
  // }));
});
