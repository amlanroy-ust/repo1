import { Routes, RouterModule } from '@angular/router';
import { SearchComponent } from './search/search.component';
import { EditComponent } from './edit/edit.component';
import { FriendComponent } from './friend/friend.component';

const appRoutes: Routes = [
  { path: 'search', component: SearchComponent },
  { path: 'friend', component: FriendComponent },
  { path: 'edit/:id', component: EditComponent },
  { path: '', redirectTo: '/search', pathMatch: 'full' },
  { path: 'contact', loadChildren: 'app/contact/contact.module#ContactModule' },
  { path: 'privacy', loadChildren: 'app/privacy/privacy.module#PrivacyModule' }
];
export const appRoutingProviders: any[] = [];
export const routing = RouterModule.forRoot(appRoutes);