﻿require('rootpath')();
var express = require('express');
var app = express();
var cors = require('cors');
var bodyParser = require('body-parser');
var expressJwt = require('express-jwt');
var config = require('./config');
var mongoose = require("mongoose");
//var multer = require('multer');
//var formidable = require('formidable');
var fs = require('fs');
var path = require('path');
var http = require('http').Server(app);

var passport = require('passport');
var ActiveDirectoryStrategy = require('passport-activedirectory');
var ActiveDirectory = require('activedirectory');

var ad = new ActiveDirectory({
  url: 'ldap://ust-global.com',
  baseDN: 'DC=my,DC=domain,DC=com',
  username: 'u58190@ust-global.com',
  password: 'aaa123'
})

passport.use(new ActiveDirectoryStrategy({
  integrated: false,
  ldap: ad
}, function (profile, ad, done) {
  ad.isUserMemberOf(profile._json.dn, 'AccessGroup', function (err, isMember) {
    if (err) return done(err)
    return done(null, profile)
  })
}))

mongoose.Promise = require('bluebird');

mongoose.connect(config.database, {useMongoClient: true}, function (err) {
    if (err) {
        console.log(err);
    } else {
        console.log("Connected to the database");
    }
});

app.use(function(req, res, next) { //allow cross origin requests
        res.setHeader("Access-Control-Allow-Methods", "POST, PUT, OPTIONS, DELETE, GET");
        res.header("Access-Control-Allow-Origin", config.__site_url);
        res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
        res.header("Access-Control-Allow-Credentials", true);
        next();
    });

app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use('/uploads', express.static(__dirname + '/uploads'));
//console.log(__dirname + '/uploads');

//use JWT auth to secure the api, the token can be passed in the authorization header or querystring

// app.use(expressJwt({
//     secret: config.secretKey,
//     getToken: function (req) {
//         if (req.headers.authorization && req.headers.authorization.split(' ')[0] === 'Bearer') {
//             return req.headers.authorization.split(' ')[1];
//         } else if (req.query && req.query.token) {
//             return req.query.token;
//         }
//         return null;
//     }
// }).unless({ path: ['/users/authenticate', '/users/register', '/users/upload', '/users/employeeData'] }));


// routes 
app.use('/users', require('./routes/userRoutes'));

var apiRoutes = require('./routes/apiRoutes.js')(app, express);

app.use('/api', apiRoutes);

// start server
// var port = process.env.NODE_ENV === 'production' ? 80 : 4000;
// var server = app.listen(port, function () {
//     console.log('Server listening on port ' + port);
// });

http.listen(config.port, function (err) {
    if (err) {
        console.log(err)
    } else {
        console.log('Server listening on port ' + config.port);
    }
});