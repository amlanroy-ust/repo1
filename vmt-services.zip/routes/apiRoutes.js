﻿module.exports = function (app, express) {
    var api = express.Router();
    //var validator = require('validator');
    var jwt = require('jsonwebtoken');
    //var config = require('../../config');
    //var User = require('../../models/users');
    //var bcCountries = require('bc-countries');
    var countriescities = require('countries-cities');
    //var mime = require('mime');
    //var fs      = require('fs');
    //var random  = require('randomstring');
    //var nodemailer = require('nodemailer');

    //api.get('/country-codes', function (req, res) {
    //    res.json(bcCountries.getAllCountries());
    //});

    //=================
    //  Get Country List
    //=================

    api.get('/countries', function (req, res) {
        res.json(countriescities.getCountries());
    });

    //=================

    //  Get City List

    //=================

    // api.get('/cities/:country_name', function (req, res) {

    //     var country_name = req.params.country_name;

    //     res.json(countriescities.getCities(country_name));

    // });
       
    //////////////////////////
    // get Details
    //////////////////////////

    api.get('/me', function(req, res){
        console.log('My details...');
        //var UserService = require('../Service/UserService');

        //console.log(req.decoded);

        // UserService.me(req.decoded, function(response){

        //     res.send(response);

        // });

    });

    return api;
}