﻿var config = require('config.json');
var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
db.bind('visitors');

var service = {};

service.create = create;

module.exports = service;

function create(userParam) {
    var deferred = Q.defer();

    // validation
    db.visitors.findOne(
        { email: userParam.email },
        function (err, user) {
            if (err) deferred.reject(err.name + ': ' + err.message);

            if (user) {
                // username already exists
                deferred.reject('Visitor "' + userParam.email + '" is already exists');
            } else {
                createVisitor();
            }
        });

    function createVisitor() {
        // set user object to userParam without the cleartext password
        //var user = _.omit(userParam, 'password');

        var user = userParam;

        // add hashed password to user object
        //user.hash = bcrypt.hashSync(userParam.password, 10);

        db.visitors.insert(
            user,
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);

                deferred.resolve();
            });
    }

    return deferred.promise;
}