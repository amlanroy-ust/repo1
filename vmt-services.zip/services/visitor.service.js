﻿var Visitors = require('../models/visitors');
var Visits = require('../models/visits');
var visitsettings = require('../models/visitsettings');
var _ = require('lodash');
var config = require('../config');
var Q = require('q');
var shortid = require('shortid');
var randomstring = require("randomstring");
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
//To sent mail
var nodemailer = require('nodemailer');

//var mongo = require('mongoskin');
//var db = mongo.db(config.connectionString, { native_parser: true });
//db.bind('visitors');

var service = {};

service.authenticate = authenticate;
service.create = create;
service.getAllVisit = getAllVisit;
service.getVisitById = getVisitById;
service.settings = settings;
service.getSettings = getSettings;
service.getReport = getReport;

module.exports = service;

function authenticate(username, password) {
    var deferred = Q.defer();

    Visitors.findOne({ email: username }, function (err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        if (user && bcrypt.compareSync(password, user.password)) {
            // authentication successful

            //console.log('Visitor details in service', user);

            deferred.resolve({
                _id: user._id,
                email: user.email,
                firstName: user.firstName,
                lastName: user.lastName,
                empType: 'visitor',
                idProof: user.idProof,
                idProofNumber: user.idProofNumber,
                address: user.address,
                visitorType: user.visitorType,
                company: user.company,
                contact: user.contact,
                token: jwt.sign({ sub: user._id }, config.secretKey)
            });
        } else {
            // authentication failed
            //console.log('Visitor authentication failed');
            deferred.resolve({
                status: 400,
                message: 'Visitor authentication failed'
            });
        }
    });

    return deferred.promise;
}

function settings(settingsParam) {
    var deferred = Q.defer();

    visitsettings.find(
        function (err, data) {
            if (err) 
            {
                console.log('err', err);
                deferred.reject(err.name + ': ' + err.message);
            }

            if (data.length === 0) {
                // username already exists
                //console.log('settingsParam ', settingsParam);

                var visit_settings = new visitsettings({
                    refmCustomer: settingsParam.refmCustomer,
                    refmPersonal: settingsParam.refmPersonal,
                    refmVisitor: settingsParam.refmVisitor,
                    refmVendor: settingsParam.refmVendor,
                    ismsCustomer: settingsParam.ismsCustomer,
                    ismsPersonal: settingsParam.ismsPersonal,
                    ismsVisitor: settingsParam.ismsVisitor,
                    ismsVendor: settingsParam.ismsVendor
                });

                //console.log('visitor', visitor);
               
                visit_settings.save(function (err, insertData) {
                    if (err) deferred.reject(err.name + ': ' + err.message);
                    
                    //console.log('insertData', insertData);

                    deferred.resolve(insertData);

                });

                //deferred.resolve({status: 200, message: 'No data found, Add function is there'});
            } else {
                //console.log('Data found: ', data[0]);
                var setJsonData = {"refmCustomer": settingsParam.refmCustomer, "refmPersonal": settingsParam.refmPersonal, "refmVisitor": settingsParam.refmVisitor, "refmVendor": settingsParam.refmVendor, "ismsCustomer": settingsParam.ismsCustomer, "ismsPersonal": settingsParam.ismsPersonal, "ismsVisitor": settingsParam.ismsVisitor, "ismsVendor": settingsParam.ismsVendor,};

                var set = {
                    refmCustomer: settingsParam.refmCustomer,
                    refmPersonal: settingsParam.refmPersonal,
                    refmVisitor: settingsParam.refmVisitor,
                    refmVendor: settingsParam.refmVendor,
                    ismsCustomer: settingsParam.ismsCustomer,
                    ismsPersonal: settingsParam.ismsPersonal,
                    ismsVisitor: settingsParam.ismsVisitor,
                    ismsVendor: settingsParam.ismsVendor,
                    allSetting: setJsonData
                };

                //console.log('set in service: ', set);

                visitsettings.update(
                { _id: data[0]._id },
                { $set: set },
                function (err, doc) {
                    if (err) deferred.reject(err.name + ': ' + err.message);
                    
                    console.log('Update data: ', doc);
                    deferred.resolve();
                });

                //deferred.resolve({status: 200, message: 'Data found, Update function is there'});
            }

        });

        return deferred.promise;
}

function create(userParam) {

    var deferred = Q.defer();
    
    //console.log('userParam...', userParam);

    // validation
    Visitors.findOne(
        { email: userParam.email },
        function (err, user) {
            if (err) 
            {
                console.log('err', err);
                deferred.reject(err.name + ': ' + err.message);
            }
            if (user) {
                // username already exists
                console.log('user exists');
                deferred.reject({status: 400, message: 'Visitor "' + userParam.email + '" is already exists. Please select visitor using search screen and add request. '});
                //deferred.resolve({status: 400, message : 'Visitor "' + userParam.email + '" is already exists'});
            } else {

                //console.log('success');
                //deferred.resolve();

                Visits.count()
                .exec(function(err, noOfVisit){
                    if(err){
                        console.log('err', err);
                        deferred.reject(err.name + ': ' + err.message);
                    }
                    else{                        
                        console.log('noOfVisit', noOfVisit);
                        createVisitor(noOfVisit+1);
                    }

                });

                // createVisitor();
            }
        });

    function createVisitor(noOfVisit) {
        // set user object to userParam without the cleartext password
        //var user = _.omit(userParam, 'password');
        //console.log('shortid.generate()', shortid.generate());
        var userPassword = shortid.generate();
        var password = bcrypt.hashSync(userPassword, 10);
        // var visitPin = randomstring.generate({
        //                     length: 4,
        //                     charset: 'numeric'
        //                 });
        // var visitPin = noOfVisit + visitPin;

        var visitPin = noOfVisit;     

        var visitor = new Visitors({
            firstName: userParam.firstName,
            lastName: userParam.lastName,
            contact: userParam.contact,
            company: userParam.company,
            email: userParam.email,
            password: password,
            visitorType: userParam.visitorType,
            address: userParam.address,
            idProof: userParam.idProof,
            idProofNumber: userParam.idProofNumber,
            idProofComments: userParam.idProofComments
        });

        // add hashed password to user object
        //user.hash = bcrypt.hashSync(userParam.password, 10);

        visitor.save(function (err, visitor) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                
                //console.log('visitor', visitor);
                //deferred.resolve();

                visitsettings.findOne()
                .select('ismsVendor ismsVisitor ismsPersonal ismsCustomer refmVendor refmVisitor refmPersonal refmCustomer')
                .exec(function(err, settingsData){
                    if(err){
                        console.log('err in service', err);
                        callback({success: false, err: err});
                    }
                    else{                        
                        console.log('settingsData in service', settingsData);
                        //callback({success: true, "settingsData": settingsData});
                        var refmRequired = false;
                        var ismsRequired = false;
                        //var refmApproved = false;
                        //var ismsApproved = false;
                        var meetPersonApproved = true;

                        if(userParam.visitorType == 'Personal'){
                            if(settingsData.refmPersonal === true){
                                refmRequired = true;
                            }
                            if(settingsData.ismsPersonal === true){
                                ismsRequired = true;
                            }
                        }
                        else if(userParam.visitorType == 'Customer'){
                            if(settingsData.refmCustomer === true){
                                refmRequired = true;
                            }
                            if(settingsData.ismsCustomer === true){
                                ismsRequired = true;
                            }
                        }
                        else if(userParam.visitorType == 'Visitor'){
                            if(settingsData.refmVisitor === true){
                                refmRequired = true;
                            }
                            if(settingsData.ismsVisitor === true){
                                ismsRequired = true;
                            }
                        }
                        else if(userParam.visitorType == 'Vendor'){
                            if(settingsData.refmVendor === true){
                                refmRequired = true;
                            }
                            if(settingsData.ismsVendor === true){
                                ismsRequired = true;
                            }
                        }



                        var visit = new Visits({
                            visitPin: visitPin,
                            _visitor: visitor._id,
                            createdBy: userParam.createdBy,
                            createdByType: userParam.createdByType,
                            visitorName: userParam.firstName+" "+userParam.lastName,
                            visitorEmail: userParam.email,
                            visitorCompany: userParam.company,
                            visitFromDate: userParam.visitFromDate,
                            visitToDate: userParam.visitToDate,
                            facility: userParam.facility,
                            purpose: userParam.purpose,
                            meetPerson: userParam.meetPerson,
                            needUstLan: userParam.needUstLan,
                            needWifi: userParam.needWifi,
                            haveAsset: userParam.haveAsset,
                            assetDetails: userParam.assetDetails,
                            comments: userParam.comments,
                            visitorType: userParam.visitorType,
                            meetPersonApproved: meetPersonApproved,
                            refmRequired: refmRequired,
                            ismsRequired: ismsRequired
                        });

                        visit.save(function (err, visit) {
                            if (err) deferred.reject(err.name + ': ' + err.message);
                            //console.log('visit', visit);
                            if(refmRequired === true)
                            {
                                //console.log('visit', visit);
                                var htmlBody = "Hi REFM,<br> " + userParam.firstName + " " + userParam.lastName + " want to visit " + userParam.meetPerson + ". The visitor details is given below: <br><br> <table><tr><td>Visitor Name</td><td>Visitor Pin</td><td>From Date</td><td>To Date</td></tr><tr><td>" + userParam.firstName + " " + userParam.lastName + "</td><td>" + visitPin + "</td><td>" + userParam.visitFromDate + "</td><td>" + userParam.visitToDate + "</td></tr></table>";

                                // create reusable transporter object using the default SMTP transport
                                let transporter = nodemailer.createTransport({
                                    host: '10.10.202.207',
                                    port: 25
                                });

                                // setup email data with unicode symbols
                                let mailOptions = {
                                    from: '"VisitorManagementTool" <VisitorManagementTool@ust-global.com>', // sender address
                                    to: 'Remya.Deepu@USTDEV.COM', // list of receivers
                                    subject: 'Visit Request: Visitor Entry Details',
                                    html: htmlBody // html body
                                };

                                transporter.sendMail(mailOptions, function(error, info){
                                    if (error) {
                                        console.log('error', error);
                                    } else {
                                        console.log('Message sent: ', info.response);
                                    }
                                });

                            }
                            deferred.resolve(visit);

                        });

                    }
                });

            });
    }

    return deferred.promise;
    
}

// function getAllVisit() {
//     var deferred = Q.defer();

//     Visits.find(function (err, visits) {
//         if (err) deferred.reject(err.name + ': ' + err.message);
//         deferred.resolve(visits);
//     });

//     return deferred.promise;
// }

function getAllVisit(callback) {
    
    sort_field = '_id';
    var order = '-1'; //descending;

    Visits.find()
        .select('_id _visitor visitPin visitFromDate visitToDate meetPerson purpose facility visitorType')
        .populate({
                'path': '_visitor',
                'select': 'firstName lastName email company contact'
            })
        .lean()
        .sort([[sort_field,order]])
        .exec(function(err, visit){

            if(err){
                callback({success: false, err: err});
            }

            else{                        
                //console.log('visit in service', visit);
                //visit = _.omit(visit, '__v');
                callback({success: true, "visitList": visit});
            }

        });
}



// function getVisitById(_id) {
//     var deferred = Q.defer();

//     Visitors.findById(_id, function (err, visit) {
//         if (err) deferred.reject(err.name + ': ' + err.message);

//         if (visit) {
//             // return visit (without hashed password)
//             //deferred.resolve(_.omit(user, 'hash'));
//             deferred.resolve(visit);
//         } else {
//             // user not found
//             deferred.resolve();
//         }
//     });

//     return deferred.promise;
// }

function getVisitById(_id, callback) {
    
    Visits.findById(_id)
        .select('_id _visitor visitFromDate visitToDate meetPerson purpose facility visitorType')
        .populate({
                'path': '_visitor',
                'select': 'firstName lastName'
            })
        .lean()
        //.sort([[sort_field,order]])
        .exec(function(err, visit){

            if(err){
                callback({success: false, err: err});
            }

            else{                        
                //console.log('visit in service', visit);
                //visit = _.omit(visit, '__v');
                callback({success: true, "visitDetails": visit});
            }

        });
}

function getSettings(callback) {
    
    visitsettings.findOne()
        .select('_id ismsVendor ismsVisitor ismsPersonal ismsCustomer refmVendor refmVisitor refmPersonal refmCustomer')
        //.lean()
        //.sort([[sort_field,order]])
        .exec(function(err, settingsData){

            if(err){
                console.log('err in service', err);
                callback({success: false, err: err});
            }

            else{                        
               // console.log('settingsData in service', settingsData);
                //visit = _.omit(visit, '__v');
                callback({success: true, "settingsData": settingsData});
            }

        });
}

function getReport(searchParam, callback) {
    //console.log('searchParam in service', searchParam);
    
    //var condition = {visitFromDate: searchParam.visitFromDate, visitToDate: searchParam.visitToDate};

    sort_field = 'visitFromDate';
    var order = '1'; //ascending;
    var condition = {};
    var searchName = new RegExp(searchParam.Name, 'i');

    console.log('searchName ', searchName);

    if(searchParam.visitFromDate !== '')
        var condition = {visitFromDate: {$gte:searchParam.visitFromDate, $lte:searchParam.visitToDate}};
    else if(searchParam.Email !== '')
        var condition = {visitorEmail: new RegExp(searchParam.Email, 'i')};
    else if(searchParam.Company !== '')
        var condition = {visitorCompany: new RegExp(searchParam.Company, 'i')};
    else if(searchParam.Name !== '')
        var condition = {visitorName: searchName};
    
    //var condition = {_visitor.email: {$gte:searchParam.visitFromDate, $lte:searchParam.visitToDate}};

    Visits.find(condition)
        .select('_id _visitor visitPin visitFromDate visitToDate meetPerson purpose facility visitorType')
        .populate({
                'path': '_visitor',
                'select': 'firstName lastName email company contact'
                //'match': { email: 'amlan@gmail.com'}
            })
        .lean()
        .sort([[sort_field,order]])
        .exec(function(err, visit){

            if(err){
                callback({success: false, err: err});
            }

            else{                        
                //console.log('visit in service', visit);
                //visit = _.omit(visit, '__v');
                callback({success: true, "visitList": visit});
            }

        });
}