﻿var Groups = require('../models/groups');
var _ = require('lodash');
var config = require('../config');
var Q = require('q');
var shortid = require('shortid');
var randomstring = require("randomstring");
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
//To sent mail
var nodemailer = require('nodemailer');
var service = {};

service.create = create;
service.groupList = groupList;

module.exports = service;

function create(groupParam) {

    var deferred = Q.defer();
    
    console.log('groupParam...', groupParam);

    // validation
    Groups.findOne(
        { groupName: groupParam.groupName },
        function (err, group) {
            if (err) 
            {
                console.log('err', err);
                deferred.reject(err.name + ': ' + err.message);
            }
            if (group) {
                // username already exists
                console.log('groupName exists');
                deferred.reject({status: 400, message: 'Group "' + groupParam.groupName + '" is already exists. Please choose another group name. '});
                //deferred.resolve({status: 400, message : 'Visitor "' + userParam.groupName + '" is already exists'});
            } else {
                    //console.log('success');
                    //deferred.resolve();
                    createGroup();
            }
        });

    function createGroup() {
        var group = new Groups({
            groupName: groupParam.groupName
        });

        group.save(function (err, insertedGroup) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                console.log('insertedGroup', insertedGroup);
                //deferred.resolve();
                deferred.resolve(insertedGroup);

            });
    }

    return deferred.promise;
    
}

function groupList(callback){
    sort_field = '_id';
    var order = '-1'; //descending;

    Groups.find()
        .select('_id groupName')
        .sort([[sort_field,order]])
        .exec(function(err, grouplist){
            if(err){
                callback({success: false, err: err});
            }
            else{                        
                //console.log('visit in service', visit);
                //visit = _.omit(visit, '__v');
                callback({success: true, "groupList": grouplist});
            }
        });
}