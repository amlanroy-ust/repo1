var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var VisitSchema = ({
	visitPin: {type: Number, required: true, index: {unique : true}},
	_visitor: {type: Schema.Types.ObjectId, ref: 'Visitor'},
	createdBy: {type: String, default: null},
	visitorName: {type: String, default: null}, 
	visitorEmail: {type: String, default: null},
	visitorCompany: {type: String, default: null}, 
	createdByType: {type: String, default: null},
	visitFromDate: {type: String, default: null},
	visitToDate: {type: String, default: null},
	visitorType: {type: String, default: null},
	facility: {type: String, default: null},
	purpose: {type: String, default: null},
	meetPerson: {type: String, default: null},
	needUstLan: {type: Boolean, default: false},
	needWifi: {type: Boolean, default: false},
	haveAsset: {type: Boolean, default: false},
	assetDetails: {type: String, default: null},
	comments: {type: String, default: null},
	idProof: {type: String, default: null},
	idProofNumber: {type: String, default: null},
	idProofComments: {type: String, default: null},
	refmRequired: {type: Boolean, default: false},
	ismsRequired: {type: Boolean, default: false},
	refmApproved: {type: Boolean, default: false},
	ismsApproved: {type: Boolean, default: false},
	meetPersonApproved: {type: Boolean, default: false},
	approvalStatus: {type: Boolean, default: false},
	created: {type: Date, default: Date.now}
});

module.exports = mongoose.model("Visit", VisitSchema);