var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var VisitsettingSchema = ({
	refmCustomer: {type: Boolean, default: false},
	refmPersonal: {type: Boolean, default: false},
	refmVisitor: {type: Boolean, default: false},
	refmVendor: {type: Boolean, default: false},
	ismsCustomer: {type: Boolean, default: false},
	ismsPersonal: {type: Boolean, default: false},
	ismsVisitor: {type: Boolean, default: false},
	ismsVendor: {type: Boolean, default: false},
	allSetting: {type: Schema.Types.Mixed, default: null}
});

module.exports = mongoose.model("Visitsetting", VisitsettingSchema);