var mongoose = require("mongoose");
//var bcrypt = require("bcrypt-nodejs")

var Schema = mongoose.Schema;

var VisitorSchema = new Schema({
	firstName : {type: String, required: true},
	lastName: {type: String, default: null},
	email: {type: String, required: true, index: {unique : true}},
	contact: {type: String, default: null},
	company: {type: String, default: null},
	visitorType: {type: String, default: null},
    address: {type: String, default: null},
	idProof: {type: String, default: null},
	idProofNumber: {type: String, default: null},
    idProofComments: {type: String, default: null},
	created: {type: Date, default: Date.now} 
});

// UserSchema.pre('save', function(next){

// 	var user = this;
	
// 	if(!user.isModified('password')) return next();

// 	bcrypt.hash(user.password, null, null, function(err, hash){

// 		if(err) return next(err);

// 		user.password = hash;
// 		next();

// 	});

// });

// UserSchema.methods.comparePassword = function(password){

// 	var user = this;

// 	return bcrypt.compareSync(password, user.password);

// }

module.exports = mongoose.model("Visitor", VisitorSchema);