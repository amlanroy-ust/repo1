var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var OrderSchema = new Schema({
	cust_id : {type: String, required: true},
	amount: {type: Number, default: null},
	status: {type: String, default: null}
});

module.exports = mongoose.model("Order", OrderSchema);