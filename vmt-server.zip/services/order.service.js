﻿var Orders = require('../models/orders');
var config = require('../config');
var Q = require('q');

var service = {};
service.getOrderList = getOrderList;
service.getOrderListTest = getOrderListTest;
module.exports = service;

function getOrderList() {
    console.log('getOrderList service function');
    var deferred = Q.defer();

    var o = {};
    o.map = function () { emit(this.cust_id, this.amount) };
    o.reduce = function (key, values) { return Array.sum(values); };
    o.query = {status: "A"},
    
    Orders.mapReduce(o,function (err, results, stats) {
        console.log('map reduce took %d ms', stats.processtime)
        if (err) deferred.reject(err);
        deferred.resolve(results);
    })
    return deferred.promise;
}

function getOrderListTest() {
    console.log('getOrderList service function');
    var deferred = Q.defer();

    var o = {};
    o.map = function () { emit(this.cust_id, this.amount) };
    o.reduce = function (key, values) { return Array.sum(values); };
    o.query = {status: "A"},
    o.out = 'order_totals';
    o.verbose = true;

    Orders.mapReduce(o,function (err, model, stats) {
        console.log('map reduce took %d ms', stats.processtime)
        model.find(
            function (err, results) {
            if (err) deferred.reject(err);
            deferred.resolve(results);
        });
    })
    return deferred.promise;
}