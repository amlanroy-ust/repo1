﻿var config = require('config.js');
var express = require('express');
var router = express.Router();
var userService = require('services/user.service');
var visitorService = require('services/visitor.service');
var groupService = require('services/group.service');
var formidable = require('formidable');
var fs = require('fs');
var path = require('path');

var request = require('request');
var https = require('https');

//To sent mail
var nodemailer = require('nodemailer');

var passport = require('passport');
var ActiveDirectoryStrategy = require('passport-activedirectory');
var ActiveDirectory = require('activedirectory');

// routes
router.post('/authenticate', authenticate);
router.post('/register', register);
router.get('/user-list', getAll);
router.get('/current/:_id', getCurrent);
router.put('/:_id', update);
router.delete('/:_id', _delete);
router.get('/test', testFunction);
router.post('/upload', fileupload);

router.post('/employeeData', employeeData);
router.post('/addVisitor', addVisitor);
router.get('/getAllVisit', getAllVisit);
router.get('/getVisitDetails/:_id', getVisitDetails);

router.post('/sentVisitMail', sentVisitMail);
router.get('/sentMail', sentMail);

router.post('/visitSettings', visitSettings);
router.get('/getVisitSettings', getVisitSettings);
router.post('/getVisitReport', getVisitReport);

router.post('/addGroup', addGroup);
router.get('/getAllGroup', getAllGroup);

//router.post('/ldapLogin', ldapLogin);

module.exports = router;

var username = "hrbot";
var password = "plslogmein@osb";
//var auth = "Basic " + new Buffer(username + ":" + password).toString("base64");
//var url = "https://fmw.uat.ust-global.com/osb/EmployeeProfileIntegration";
//var UID = "u58190";

function employeeData(req,res){

    //console.log('req.body', req.body);

    var UID = req.body.uid;
    //console.log('UID', UID);
    var x = UID;

    if(x.indexOf("@") !== 'undefined')
    {
        var atpos = x.indexOf("@");
        var dotpos = x.lastIndexOf(".");
        if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {
            var myJSONObject = '{"employeeprofile": {"uid": '+UID+'}}';
        }
        else var myJSONObject = '{"employeeprofile": {"email": '+UID+'}}';
    }
    else var myJSONObject = '{"employeeprofile": {"uid": '+UID+'}}';

    var options = {                 
    host: 'https://fmw.uat.ust-global.com',
    path: '/osb/EmployeeProfileIntegration',
    port: 443,
    method: 'POST',             
    url: 'https://fmw.uat.ust-global.com/osb/EmployeeProfileIntegration',
    form: myJSONObject,               
    headers: {               
        'Authorization': "Basic " + new Buffer(username + ":" + password).toString("base64")                  
    },
    agent: false
    };

    request(options, function (err, resp, body) {
        if (err) {
        console.log('Error!! ', err)
        res.status(400).send(err);
        }
        // parse method is optional
        var res_body = JSON.parse(body);
        //console.log('employee res body ', body);
        //return res.send(200, JSON.parse(body));
        if(res_body.GetEmp_RecordDetailsOutputCollection !== "")
        {
            //console.log('Data found with', UID);
            return res.status(200).send(JSON.parse(body));
        }
        else
        {
            //console.log('GET method: ', UID);
            
            var options = {                 
                host: 'https://fmw.uat.ust-global.com',
                path: '/osb/EmployeeDetails',
                port: 443,
                method: 'GET',             
                url: 'https://fmw.uat.ust-global.com/osb/EmployeeDetails?Name='+UID,
                headers: {               
                    'Authorization': "Basic " + new Buffer(username + ":" + password).toString("base64")                  
                },
                agent: false
            };

            request(options, function (err, resp, body) {
                if (err) {
                console.log('Error!! ', err)
                res.status(400).send(err);
                }
                // parse method is optional
                //console.log('employee res body2 ', body);
                return res.status(200).send(JSON.parse(body));
            });

        }
        
    });
};

function authenticate(req, res) {
    console.log('req.body', req.body);
    visitorService.authenticate(req.body.username, req.body.password)
        .then(function (user) {
            if (user) {
                // authentication successful
                //console.log('user det', user);
                res.send(user);
            } else {
                // authentication failed
                //console.log('Username or password is incorrect');
                res.status(400).send('Username or password is incorrect');
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function register(req, res) {
    //console.log('req data...', req.body);
    userService.create(req.body)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            //console.log('err in routes...', err);
            res.status(400).send(err);
        });
}

function getAll(req, res) {
    
    //console.log('req', req);

    userService.getAll()
        .then(function (users) {
            res.send(users);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getCurrent(req, res) {

    //console.log('req.params._id', req.params._id);

    userService.getById(req.params._id)
        .then(function (user) {
            if (user) {
                res.send(user);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function update(req, res) {
    userService.update(req.params._id, req.body)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function _delete(req, res) {
    userService.delete(req.params._id)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function testFunction(req, res) {
    console.log('Hi Amlan this is your user routes');
    res.json({'FirstName': 'Amlan', 'LastName': 'Roy'});
}

/** API path that will upload the files */
function fileupload(req, res) {
    
    //console.log('file', file);
    var form = new formidable.IncomingForm();
    form.multiples = false;
    form.uploadDir = path.join(__dirname, '../uploads');
    form.on('file', function(field, file) {
        //console.log('file', file);
        //var file_name = file.name;
        fs.rename(file.path, path.join(form.uploadDir, file.name));
        //console.log('file.name', file.name);
        var file_path = config.imagepath + file.name;
        console.log('file_path', file_path);
        res.send(file.name);
    });
    // form.on('error', function(err) {
    //     console.log('An error has occured: \n' + err);
    // });
    // form.on('end', function() {
    //     console.log('success file upload');
    //     //console.log('file', file.name);
    //     //res.end('res');
    //     res.sendStatus(200);
    //     //res.send(user);
    // });
    form.parse(req);
}

function visitSettings(req, res){
    //console.log('visitSettings...', req.body);
    //res.json({'req.body': req.body});
    visitorService.settings(req.body)
    .then(function () {
        res.sendStatus(200);
    })
    .catch(function (err) {
        console.log('err in routes...', err);
        res.status(400).send(err);
    });
}

function addVisitor(req, res) {
    //console.log('addVisitor...', req.body);
    visitorService.create(req.body)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            console.log('err in routes...', err);
            res.status(400).send(err);
        });
}

function sentVisitMail(req, res) {
    console.log('req data...', req.body);
    res.json({'info.messageId': "12121"});
}

function sentMail(req, res) {
    
    console.log('req data...', req.body);

    var htmlBody = "Hello Visitor,<br> Your visitor PIN for visiting UST Global is as mentioned below.<br> Your QRCode for the visit will be";

    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
        host: '10.10.202.207',
        port: 25
        // secure: true, // secure:true for port 465, secure:false for port 587
        // auth: {
        //     user: 'amlan@gmail.com',
        //     pass: '1234567890'
        // }
    });

    // setup email data with unicode symbols
    let mailOptions = {
        // from: 'amlan.roy@ust-global.com', // sender address
        // to: 'Remya.Deepu@USTDEV.COM', // list of receivers by comma seperator.
        // subject: 'Sending Email using Node.js',
        // text: 'That was easy!'

        from: '"VisitorManagementTool" <VisitorManagementTool@ust-global.com>', // sender address
        //to: 'bar@blurdybloop.com, baz@blurdybloop.com', // list of receivers
        to: 'Remya.Deepu@USTDEV.COM', // list of receivers
        //subject: 'Hello ✔', // Subject line
        subject: 'Visit Request Approved: Visitor Entry Details',
        //text: 'Hello world ?', // plaintext body
        html: htmlBody // html body
    };

    transporter.sendMail(mailOptions, function(error, info){
        if (error) {
            console.log('error', error);
            res.json({'error': error});
        } else {
            //console.log('Message sent: ', info.response);
            console.log('Message %s sent: %s', info.messageId, info.response);
            res.json({'Email sent': info.response, 'info.messageId': info.messageId});
        }
    });
    
}

function getAllVisit(req, res) {
    //console.log('req', req);
    // visitorService.getAllVisit()
    //     .then(function (visitors) {
    //         res.send(visitors);
    //     })
    //     .catch(function (err) {
    //         res.status(400).send(err);
    //     });

    visitorService.getAllVisit( function(response){
            res.send(response);
    });
}

// function getVisitDetails(req, res) {
//     //console.log('req', req);
//     visitorService.getVisitById(req.params._id)
//         .then(function (visitDetails) {
//             if (visitDetails) {
//                 res.send(visitDetails);
//             } else {
//                 res.sendStatus(404);
//             }
//         })
//         .catch(function (err) {
//             res.status(400).send(err);
//         });
// }

function getVisitDetails(req, res) {
    //console.log('req', req);
    var visitid = req.params._id;
    visitorService.getVisitById(visitid, function(response){
            res.send(response);
    });
}

function getVisitSettings(req, res) {
    visitorService.getSettings( function(response){
            console.log('response ', response);
            res.send(response);
    });
}

function getVisitReport(req, res){
    //console.log('req.body: ', req.body);
    //res.json({'req.body': req.body});
    var searchBy = req.body;
    visitorService.getReport(searchBy, function(response){
            res.send(response);
    });
}

function addGroup(req, res) {
    //console.log('addGroup...', req.body);
    groupService.create(req.body)
        .then(function (data) {
            res.sendStatus(200);
            //console.log('res.data: ', data);
            //res.status(200).send(data);
        })
        .catch(function (err) {
            console.log('err in routes...', err);
            res.status(400).send(err);
        });
}

function getAllGroup(req, res) {
    groupService.groupList( function(response){
        res.send(response);
    });
}