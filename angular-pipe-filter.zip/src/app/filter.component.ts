import {Pipe, PipeTransform} from '@angular/core'

@Pipe({
    name: 'filter'
})
export class FilterPipe implements PipeTransform {
    transform(items: Array<any>, filter: {[key: string]: any }): Array<any> {
        return items.filter(item => {
                //console.log(item.name); 
                console.log(filter);
                let notMatchingField = Object.keys(filter)
                                             .find(key => item[key] !== filter[key]);
                //console.log(str.indexOf(filter.name)); 
                //let str = item.name;
                if (item.name.toLowerCase().indexOf(filter.searchBy.toLowerCase()) >= 0)
                  return true;
                else if (parseInt(item.age) === parseInt(filter.searchBy))
                  return true;
                //return !notMatchingField; // true if matches all fields
            });
    }
}