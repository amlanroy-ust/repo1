import { Component } from '@angular/core';

@Component({
  selector: 'home',
  templateUrl: './home.component.html'
})
export class HomeComponent {
  name:string;
  people: Array<any>;
  peopleFilter: any;
  searchValue:string = '';
  
  constructor() {
    this.name = 'Angular2';
    
    this.people = [
      {name: 'John', age: 27, sex: 'male'},
      {name: 'Lara', age: 21, sex: 'female'},
      {name: 'Rick', age: 29, sex: 'male'},
      {name: 'Eva',  age: 27, sex: 'female'},
      {name: 'Mike', age: 27, sex: 'male'}
    ];
    
    //this.peopleFilter = {name: 'John', age: ''};
    this.peopleFilter = {searchBy: ''};

  }
  
  onSearchChange(value) {
    //alert('amlan');
    //console.log('test', value);
    //this.peopleFilter = {name: value};
    this.peopleFilter = {searchBy: value};
    //this.searchValue = null;
  }
}
