import { Component } from '@angular/core';
import {UserService} from './services/user/user.service';
import {PreviewService} from './services/preview/preview.service';

@Component({
  moduleId: module.id,
  selector: 'my-app',
  templateUrl: 'app.component.html',
  providers:[UserService, PreviewService]
})

export class AppComponent {
  
  //menu?: boolean = true;
  
  constructor(){
        //this.menu = true;
    }
  
}
