import { Component } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import {UserService} from '../../services/user/user.service';
import {User} from './shared/User';

@Component({
  moduleId: module.id,
  selector: 'registration',
  //styleUrls: ['assets/pages/css/login-4.min.css'],
  templateUrl: 'registration.component.html'
  //providers: [appRoutingProviders]
})

export class RegistrationComponent {
  
  users: User[];
  name: string;
  email: string;
  password: string;
  returnUrl: string;
  
  error: boolean;
  success: boolean;
  message: string;
  //public n: number = 1;
    
    constructor(private route: ActivatedRoute,private router: Router,private userService:UserService){
        //this.userService.getUsers()
        //    .subscribe(users => {
        //        this.users = users;
        //    });
        
        //console.log('Registration constructor');
        this.error = false;
        this.success = false;
        this.message = '';
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/login';
        
        //setTimeout(() => {
        //  this.n = this.n + 10;
        //}, 1000);
    }
    
  registration(event){
        event.preventDefault();
        var userdata = {
            name: this.name,
            email: this.email,
            password: this.password,
        }
        
        //console.log('this.name '+ this.name);
        //console.log('this.email '+ this.email);
        //console.log('this.password '+ this.password);
        
        if(typeof(this.email) !== 'undefined' && this.email !== ""){                                      
            var x = this.email;
            var atpos = x.indexOf("@");
            var dotpos = x.lastIndexOf(".");
        }
        
        if(typeof(this.name) === 'undefined' || this.name === ""){
          
          this.error = true;
          this.message = 'Name is required';
          
          setTimeout(() => {
            this.error = false;
            this.success = false;
            this.message = '';
          }, 3000);
          
        }
        else if(typeof(this.email) === 'undefined' || this.email === ""){
          
          this.error = true;
          this.message = 'Email-ID is required';
          setTimeout(() => {
            this.error = false;
            this.success = false;
            this.message = '';
          }, 3000);
          
        }
        else if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length){                                      
            
          this.error = true;
          this.message = 'Not a valid e-mail address';
          setTimeout(() => {
            this.error = false;
            this.success = false;
            this.message = '';
          }, 3000);
           
        }
        else if(typeof(this.password) === 'undefined' || this.password === ""){
          //console.log("user.password : "+this.password);
          this.error = true;
          this.message = 'Password is required';
          setTimeout(() => {
            this.error = false;
            this.success = false;
            this.message = '';
          }, 3000);
          
        }
        else{
              //this.success = true;
              //this.message = 'Validation Completed';
              //console.log('Registration successful');
                
              this.userService.registration(userdata)
                .subscribe(
                    data => {
                        // login successful so redirect to return url
                        //console.log('Registration successful '+ data);
                        
                        //console.log('Registration success '+ data.success);
                        //console.log('Registration message '+ data.message);
                        
                        if(data.success === true)
                        {
                          this.success = true;
                          this.message = data.message;
                          setTimeout(() => {
                            this.error = false;
                            this.success = false;
                            this.message = '';
                            this.router.navigate([this.returnUrl]);
                          }, 3000);
                          
                          //this.router.navigate([this.returnUrl]);
                        }
                        else {
                          this.error = true;
                          this.success = false;
                          this.message = data.message;
                          
                          setTimeout(() => {
                            this.error = false;
                            this.success = false;
                            this.message = '';
                          }, 3000);
                        }
                    },
                    error => {
                        // login failed so display error
                        console.log('Registration failed '+ error);
                        this.error = true;
                        this.success = false;
                        this.message = 'Registration failed '+ error;
                        setTimeout(() => {
                          this.error = false;
                          this.success = false;
                          this.message = '';
                        }, 3000);
                        
                    });
        }
    }
         
}
