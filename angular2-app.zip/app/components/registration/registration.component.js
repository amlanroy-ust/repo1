"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var user_service_1 = require("../../services/user/user.service");
var RegistrationComponent = (function () {
    //public n: number = 1;
    function RegistrationComponent(route, router, userService) {
        //this.userService.getUsers()
        //    .subscribe(users => {
        //        this.users = users;
        //    });
        this.route = route;
        this.router = router;
        this.userService = userService;
        //console.log('Registration constructor');
        this.error = false;
        this.success = false;
        this.message = '';
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/login';
        //setTimeout(() => {
        //  this.n = this.n + 10;
        //}, 1000);
    }
    RegistrationComponent.prototype.registration = function (event) {
        var _this = this;
        event.preventDefault();
        var userdata = {
            name: this.name,
            email: this.email,
            password: this.password,
        };
        //console.log('this.name '+ this.name);
        //console.log('this.email '+ this.email);
        //console.log('this.password '+ this.password);
        if (typeof (this.email) !== 'undefined' && this.email !== "") {
            var x = this.email;
            var atpos = x.indexOf("@");
            var dotpos = x.lastIndexOf(".");
        }
        if (typeof (this.name) === 'undefined' || this.name === "") {
            this.error = true;
            this.message = 'Name is required';
            setTimeout(function () {
                _this.error = false;
                _this.success = false;
                _this.message = '';
            }, 3000);
        }
        else if (typeof (this.email) === 'undefined' || this.email === "") {
            this.error = true;
            this.message = 'Email-ID is required';
            setTimeout(function () {
                _this.error = false;
                _this.success = false;
                _this.message = '';
            }, 3000);
        }
        else if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) {
            this.error = true;
            this.message = 'Not a valid e-mail address';
            setTimeout(function () {
                _this.error = false;
                _this.success = false;
                _this.message = '';
            }, 3000);
        }
        else if (typeof (this.password) === 'undefined' || this.password === "") {
            //console.log("user.password : "+this.password);
            this.error = true;
            this.message = 'Password is required';
            setTimeout(function () {
                _this.error = false;
                _this.success = false;
                _this.message = '';
            }, 3000);
        }
        else {
            //this.success = true;
            //this.message = 'Validation Completed';
            //console.log('Registration successful');
            this.userService.registration(userdata)
                .subscribe(function (data) {
                // login successful so redirect to return url
                //console.log('Registration successful '+ data);
                //console.log('Registration success '+ data.success);
                //console.log('Registration message '+ data.message);
                if (data.success === true) {
                    _this.success = true;
                    _this.message = data.message;
                    setTimeout(function () {
                        _this.error = false;
                        _this.success = false;
                        _this.message = '';
                        _this.router.navigate([_this.returnUrl]);
                    }, 3000);
                    //this.router.navigate([this.returnUrl]);
                }
                else {
                    _this.error = true;
                    _this.success = false;
                    _this.message = data.message;
                    setTimeout(function () {
                        _this.error = false;
                        _this.success = false;
                        _this.message = '';
                    }, 3000);
                }
            }, function (error) {
                // login failed so display error
                console.log('Registration failed ' + error);
                _this.error = true;
                _this.success = false;
                _this.message = 'Registration failed ' + error;
                setTimeout(function () {
                    _this.error = false;
                    _this.success = false;
                    _this.message = '';
                }, 3000);
            });
        }
    };
    return RegistrationComponent;
}());
RegistrationComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'registration',
        //styleUrls: ['assets/pages/css/login-4.min.css'],
        templateUrl: 'registration.component.html'
        //providers: [appRoutingProviders]
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute, router_1.Router, user_service_1.UserService])
], RegistrationComponent);
exports.RegistrationComponent = RegistrationComponent;
//# sourceMappingURL=registration.component.js.map