import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { PreviewService } from '../../services/preview/preview.service';

@Component({
  moduleId: module.id,
  selector: 'preview',
  styleUrls: ['preview.component.css'],
  templateUrl: 'preview.component.html'
})

export class PreviewComponent implements OnInit {
      
 
    constructor(private _previewService:PreviewService){
        
    }
    
    ngOnInit() {      

    }
    
  }
