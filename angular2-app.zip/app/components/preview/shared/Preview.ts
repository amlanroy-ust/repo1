export interface ProfileDetails{
    title?: string;
    graduation?: string;
    name?: string;
    surname?: string;
    middlename?: string;
    Interest?: string[];
    Hobbie?:string[];
    maritalstatus?:string;
    gender?: string;
    cityzen?:string;
    cityofbirth?:string;
    dob?:string;
    BusinessAddress?: string[];
    PersonalAddress?: string[];
}

export interface EducationalDetails{
    institution?: string;
    degree?:string;
    grade?:string;
    startdate?: string;
    enddate?:string;
    subject?:string;
    focus?:string[];
    educationdesc?: string;
}

export interface QualificationDetails{
    yearofbirth?: string;
    graduation?:string;
    workexperience?:string;
    description?: string;
    specialisation?:string[];
    industryfocus?:string[];
    LanguageKnown?:string[];
    ProjectRoles?: string[];
    MethodicalCompetence?:string[];
    ItSolutions?:string[];
    SolutionFunctionalities?:string[];
    OfficeSolution?: string[];
    Certificates?:string[];
}

export interface WorkDetails{
    companyname?: string;
    jobtitle?:string;
    industry?:string;
    city?: string;
    companytype?:string;
    careerlevel?:string;
    employee?:string;
    employmenttype?: string;
    profjobstartdate?:string;
    profjobenddate?:string;
    website?:string;
    currentposition?: string;
    positiondesc?:string;
    tags: string[];
}

export interface ProjectDetails{
    qualification_name?: string;
    projcompanyname?:string;
    industrysector?:string;
    country?: string;
    city?:string;
    contactvia?:string;
    projecttitle?:string;
    projectrole?: string;
    projstartdate?:string;
    projenddate?:string;
    projectdesc?:string;
    qualification: string[];
}

export interface CertificateDetails{
    categoryname?: string;
    certificatename?:string;
    certificationdate?:string;
    certificationauthority?: string;
    certienddate?:string;
    certiwithoutexpdate:boolean;
    certilicensenumber?:string;
    certidesc?: string;
    certificate_image?:string;
}

export interface AwardDetails{
    institution?: string;
    title?:string;
    link?:string;
    awarddate?: string;
    awarddesc?:string;
    award_image?:string;
}