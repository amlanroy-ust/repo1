import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../../services/user/user.service';
import { PreviewService } from '../../../../services/preview/preview.service';

import { ProfileDetails } from '../../shared/Preview';

@Component({
  moduleId: module.id,
  selector: 'personal-info',
  templateUrl: 'profile.component.html',
  providers:[UserService, PreviewService]
})

export class ProfileComponent implements OnInit {

	infoState   :  boolean;
  firstBreakState   :  boolean;
  secondBreakState  :  boolean;
  thirdBreakState   :  boolean;

  personal_info : ProfileDetails = {};

	constructor(private _previewService : PreviewService) {
	    this.infoState  =   false;
      this.firstBreakState   =   false;
      this.secondBreakState  =   false;
      this.thirdBreakState   =   false;
	}

	ngOnInit() {

		this._previewService.getPersonalInfo()
          .subscribe(previewusers => {
              this.personal_info = previewusers.personal_info;
          });
	}

}
