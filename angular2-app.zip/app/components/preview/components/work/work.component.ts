import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../../services/user/user.service';
import { PreviewService } from '../../../../services/preview/preview.service';

import { WorkDetails } from '../../shared/Preview';

@Component({
  moduleId: module.id,
  selector: 'work-info',
  templateUrl: 'work.component.html',
  styleUrls: ['../../preview.component.css'],
  providers:[ UserService, PreviewService ]
})

export class WorkComponent implements OnInit {

  pageBreakState : boolean;
	work_info  : WorkDetails[];

	constructor(private _previewService : PreviewService) {
    this.pageBreakState  =  false;
	}

	ngOnInit() {
		this._previewService.getWorkInfo()
          .subscribe(previewWork => {
              this.work_info = previewWork.work_experiences;
          });
	}

	//**********Start highlight div on checkbox click **************//
    updateCheckedOptions(step,index,event){
        //this.myObjects[index].value=event.target.checked;
        //console.log('step '+step);
        //console.log('index '+index);
        
        if(step === 'work'){
            var element = document.getElementById("wrkexp_block"+index);
            
            if (element.classList.contains("selected_div")) {
              element.classList.remove("selected_div");
            }
            else element.classList.add("selected_div");
        }
        //console.log('class present '+event.target.classList.contains('checkboxright'));
        
    }
    //**********End highlight div on checkbox click **************//
}
