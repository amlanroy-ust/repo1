import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../../services/user/user.service';
import { PreviewService } from '../../../../services/preview/preview.service';

import { CertificateDetails } from '../../shared/Preview';

@Component({
  moduleId: module.id,
  selector: 'certificate-info',
  templateUrl: 'certificate.component.html',
  styleUrls: ['../../preview.component.css'],
  providers:[ UserService, PreviewService ]
})

export class CertificateComponent implements OnInit {
  
  pageBreakState : boolean;
	certificate_info    : CertificateDetails[];

	constructor(private _previewService : PreviewService) {
    this.pageBreakState  =  false;
	}

	ngOnInit() {
		this._previewService.getCertificateInfo()
          .subscribe(previewCertificate => {
              this.certificate_info = previewCertificate.certificates.certcategories;
          });
	}

	//**********Start highlight div on checkbox click **************//
    updateCheckedOptions(step,index,event,catindex){
        //this.myObjects[index].value=event.target.checked;
        //console.log('step '+step);
        //console.log('index '+index);
        
        if(step === 'certificate'){
            var element = document.getElementById("certificate_block"+catindex+index);
      
            if (element.classList.contains("selected_div")) {
              element.classList.remove("selected_div");
            }
            else element.classList.add("selected_div");
        }
        //console.log('class present '+event.target.classList.contains('checkboxright'));
        
    }
    //**********End highlight div on checkbox click **************//
}
