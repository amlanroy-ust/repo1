"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var user_service_1 = require("../../../../services/user/user.service");
var preview_service_1 = require("../../../../services/preview/preview.service");
var CertificateComponent = (function () {
    function CertificateComponent(_previewService) {
        this._previewService = _previewService;
        this.pageBreakState = false;
    }
    CertificateComponent.prototype.ngOnInit = function () {
        var _this = this;
        this._previewService.getCertificateInfo()
            .subscribe(function (previewCertificate) {
            _this.certificate_info = previewCertificate.certificates.certcategories;
        });
    };
    //**********Start highlight div on checkbox click **************//
    CertificateComponent.prototype.updateCheckedOptions = function (step, index, event, catindex) {
        //this.myObjects[index].value=event.target.checked;
        //console.log('step '+step);
        //console.log('index '+index);
        if (step === 'certificate') {
            var element = document.getElementById("certificate_block" + catindex + index);
            if (element.classList.contains("selected_div")) {
                element.classList.remove("selected_div");
            }
            else
                element.classList.add("selected_div");
        }
        //console.log('class present '+event.target.classList.contains('checkboxright'));
    };
    return CertificateComponent;
}());
CertificateComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'certificate-info',
        templateUrl: 'certificate.component.html',
        styleUrls: ['../../preview.component.css'],
        providers: [user_service_1.UserService, preview_service_1.PreviewService]
    }),
    __metadata("design:paramtypes", [preview_service_1.PreviewService])
], CertificateComponent);
exports.CertificateComponent = CertificateComponent;
//# sourceMappingURL=certificate.component.js.map