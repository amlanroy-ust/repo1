import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../../services/user/user.service';
import { PreviewService } from '../../../../services/preview/preview.service';

import { ProjectDetails } from '../../shared/Preview';

@Component({
  moduleId: module.id,
  selector: 'project-info',
  templateUrl: 'project.component.html',
  styleUrls: ['../../preview.component.css'],
  providers:[ UserService, PreviewService ]
})

export class ProjectComponent implements OnInit {
  
  pageBreakState : boolean;
	project_info  : ProjectDetails[];

	constructor(private _previewService : PreviewService) {
    this.pageBreakState  =  false;
	}

	ngOnInit() {
		this._previewService.getProjectInfo()
          .subscribe(previewProject => {
              this.project_info = previewProject.projects_done;
          });
	}


	//**********Start highlight div on checkbox click **************//
    updateCheckedOptions(step,index,event){
        //this.myObjects[index].value=event.target.checked;
        //console.log('step '+step);
        //console.log('index '+index);
        
        if(step === 'project'){
            var element = document.getElementById("projects_block"+index);
      
            if (element.classList.contains("selected_div")) {
              element.classList.remove("selected_div");
            }
            else element.classList.add("selected_div");
        }
        
        //console.log('class present '+event.target.classList.contains('checkboxright'));
        
    }
    //**********End highlight div on checkbox click **************//
  
}
