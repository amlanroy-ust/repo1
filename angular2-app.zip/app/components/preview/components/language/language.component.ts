import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../../services/user/user.service';
import { PreviewService } from '../../../../services/preview/preview.service';

import { QualificationDetails } from '../../shared/Preview';

@Component({
  moduleId: module.id,
  selector: 'language-info',
  templateUrl: 'language.component.html',
  providers:[ UserService, PreviewService ]
})

export class LanguageComponent implements OnInit {

	languages   :  string;
  skillLevels :  string;
  pageBreakState : boolean;
  qualification_info  : QualificationDetails = {};

  languageDetails = [];

	constructor(private _previewService : PreviewService) {
    this.pageBreakState  =  false;
	}

	ngOnInit() {
		this._previewService.getQualificationInfo()
          .subscribe(previewQualification => {
              this.qualification_info = previewQualification.qualification_info;

              this.languageDetails  =  this.qualification_info.LanguageKnown;
              this.languages   = this.languageDetails.map(o => o.language).join(', ');
              this.skillLevels = this.languageDetails.map(o => o.langlevel).join(', ');
          });
	}
  
}
