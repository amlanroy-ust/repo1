import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../../services/user/user.service';
import { PreviewService } from '../../../../services/preview/preview.service';

import { EducationalDetails } from '../../shared/Preview';

@Component({
  moduleId: module.id,
  selector: 'education-info',
  templateUrl: 'education.component.html',
  styleUrls: ['../../preview.component.css'],
  providers:[ UserService, PreviewService ]
})

export class EducationComponent implements OnInit {

  pageBreakState : boolean;
	educational_info    : EducationalDetails[];
  
	constructor(private _previewService : PreviewService){
    this.pageBreakState  =  false;
  }

  ngOnInit() {
  	this._previewService.getEducationInfo()
        .subscribe(previeweducation => {
            this.educational_info = previeweducation.educational_info;
        });
  }


  //**********Start highlight div on checkbox click **************//
  updateCheckedOptions(step,index,event){
      if(step === 'education'){
          var element = document.getElementById("education_block"+index);
    
          if (element.classList.contains("selected_div")) {
            element.classList.remove("selected_div");
          }
          else element.classList.add("selected_div");
      }
      //console.log('class present '+event.target.classList.contains('checkboxright'));
      
  }
  //**********End highlight div on checkbox click **************// 
  
}
