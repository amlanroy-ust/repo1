import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'component-menu',
  styleUrls: ['../../../css/menu.css'],
  templateUrl: 'menu.component.html'
})

export class MenuComponent {

    //public menuItems: Array<MenuItem>;
    highlightedMenu: string;
    
    constructor() {
      this.highlightedMenu = 'logout';
    }
    
    ngOnInit() {
        
    }
    
    toggleHighlight(menu: string) {
          this.highlightedMenu = menu;
          console.log('toggleHighlight '+ menu);
        }

}
