"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var preview_service_1 = require("../../services/preview/preview.service");
var PreviewComponent = (function () {
    function PreviewComponent(_previewService) {
        this._previewService = _previewService;
        this.languageDetails = [];
        this.personal_info = {};
        this.qualification_info = {};
        this.infoState = 'show';
        this.isActive = false;
        this.listOne = ['Coffee', 'Orange Juice', 'Red Wine', 'Unhealty drink!', 'Water'];
    }
    PreviewComponent.prototype.ngOnInit = function () {
        var _this = this;
        this._previewService.getPersonalInfo()
            .subscribe(function (previewusers) {
            _this.personal_info = previewusers.personal_info;
        });
        this._previewService.getEducationInfo()
            .subscribe(function (previeweducation) {
            //console.log('previeweducation '+previeweducation);
            _this.educational_info = previeweducation.educational_info;
        });
        this._previewService.getQualificationInfo()
            .subscribe(function (previewQualification) {
            _this.qualification_info = previewQualification.qualification_info;
            _this.languageDetails = _this.qualification_info.LanguageKnown;
            _this.languages = _this.languageDetails.map(function (o) { return o.language; }).join(', ');
            _this.skillLevels = _this.languageDetails.map(function (o) { return o.langlevel; }).join(', ');
        });
        this._previewService.getWorkInfo()
            .subscribe(function (previewWork) {
            _this.work_info = previewWork.work_experiences;
        });
        this._previewService.getProjectInfo()
            .subscribe(function (previewProject) {
            _this.project_info = previewProject.projects_done;
        });
        this._previewService.getCertificateInfo()
            .subscribe(function (previewCertificate) {
            _this.certificate_info = previewCertificate.certificates.certcategories;
        });
        this._previewService.getAwardInfo()
            .subscribe(function (previewAward) {
            _this.award_info = previewAward.award_info;
        });
    };
    // start personal details anonym clients checkbox function start
    PreviewComponent.prototype.changeState = function (data, state) {
        if (state === void 0) { state = null; }
        //console.log(this.isActive);
        if (this.isActive == false) {
            this.infoState = 'hide';
        }
        else {
            this.infoState = 'show';
        }
    };
    // End personal details anonym clients checkbox function start
    //**********Start highlight div on checkbox click **************//
    PreviewComponent.prototype.updateCheckedOptions = function (step, index, event, catindex) {
        //this.myObjects[index].value=event.target.checked;
        //console.log('step '+step);
        //console.log('index '+index);
        if (step === 'work') {
            var element = document.getElementById("wrkexp_block" + index);
            if (element.classList.contains("selected_div")) {
                element.classList.remove("selected_div");
            }
            else
                element.classList.add("selected_div");
        }
        else if (step === 'education') {
            var element = document.getElementById("education_block" + index);
            if (element.classList.contains("selected_div")) {
                element.classList.remove("selected_div");
            }
            else
                element.classList.add("selected_div");
        }
        else if (step === 'project') {
            var element = document.getElementById("projects_block" + index);
            if (element.classList.contains("selected_div")) {
                element.classList.remove("selected_div");
            }
            else
                element.classList.add("selected_div");
        }
        else if (step === 'certificate') {
            var element = document.getElementById("certificate_block" + catindex + index);
            if (element.classList.contains("selected_div")) {
                element.classList.remove("selected_div");
            }
            else
                element.classList.add("selected_div");
        }
        else if (step === 'award') {
            var element = document.getElementById("award_block" + index);
            if (element.classList.contains("selected_div")) {
                element.classList.remove("selected_div");
            }
            else
                element.classList.add("selected_div");
        }
        //console.log('class present '+event.target.classList.contains('checkboxright'));
    };
    return PreviewComponent;
}());
PreviewComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'preview',
        styleUrls: ['preview.component.css'],
        templateUrl: 'preview.component.html'
    }),
    __metadata("design:paramtypes", [preview_service_1.PreviewService])
], PreviewComponent);
exports.PreviewComponent = PreviewComponent;
//# sourceMappingURL=preview.component.js.map