"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var user_service_1 = require("../../services/user/user.service");
var LoginComponent = (function () {
    function LoginComponent(route, router, userService) {
        var _this = this;
        this.route = route;
        this.router = router;
        this.userService = userService;
        this.menu = false;
        this.userService.getUsers()
            .subscribe(function (users) {
            _this.users = users;
        });
        this.error = false;
        this.success = false;
        this.message = '';
        this.menu = false;
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/preview';
    }
    LoginComponent.prototype.ngOnInit = function () {
        // reset login status
        //this.authenticationService.logout();
        // get return url from route parameters or default to '/'
        //this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/about';
    };
    LoginComponent.prototype.login = function (event) {
        var _this = this;
        event.preventDefault();
        var userdata = {
            email: this.email,
            password: this.password,
        };
        if (typeof (this.email) !== 'undefined' && this.email !== "") {
            var x = this.email;
            var atpos = x.indexOf("@");
            var dotpos = x.lastIndexOf(".");
        }
        if (typeof (this.email) === 'undefined' || this.email === "") {
            this.error = true;
            this.message = 'Email-ID is required';
            setTimeout(function () {
                _this.error = false;
                _this.success = false;
                _this.message = '';
            }, 3000);
        }
        else if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) {
            this.error = true;
            this.message = 'Not a valid e-mail address';
            setTimeout(function () {
                _this.error = false;
                _this.success = false;
                _this.message = '';
            }, 3000);
        }
        else if (typeof (this.password) === 'undefined' || this.password === "") {
            //console.log("user.password : "+this.password);
            this.error = true;
            this.message = 'Password is required';
            setTimeout(function () {
                _this.error = false;
                _this.success = false;
                _this.message = '';
            }, 3000);
        }
        else {
            this.userService.login(userdata)
                .subscribe(function (data) {
                // login successful so redirect to return url
                //console.log('Login success '+ data.success);
                //console.log('Login message '+ data.message);
                //
                //this.success = data.success;
                //this.message = data.message;
                if (data.success === true) {
                    //this.success = true;
                    //this.message = data.message;
                    //setTimeout(() => {
                    //  this.error = false;
                    //  this.success = false;
                    //  this.message = '';
                    //  this.router.navigate([this.returnUrl]);
                    //}, 3000);
                    _this.router.navigate([_this.returnUrl]);
                }
                else {
                    _this.error = true;
                    _this.success = false;
                    _this.message = data.message;
                    setTimeout(function () {
                        _this.error = false;
                        _this.success = false;
                        _this.message = '';
                    }, 3000);
                }
            }, function (error) {
                // login failed so display error
                console.log('Login failed ' + error);
                _this.error = true;
                _this.success = false;
                _this.message = 'Login failed ' + error;
                setTimeout(function () {
                    _this.error = false;
                    _this.success = false;
                    _this.message = '';
                }, 3000);
            });
        }
    };
    return LoginComponent;
}());
LoginComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'login',
        //styleUrls: ['assets/pages/css/login-4.min.css'],
        templateUrl: 'login.component.html'
        //providers: [appRoutingProviders]
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute, router_1.Router, user_service_1.UserService])
], LoginComponent);
exports.LoginComponent = LoginComponent;
//# sourceMappingURL=login.component.js.map