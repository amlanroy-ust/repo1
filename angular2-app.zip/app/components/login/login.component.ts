import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {UserService} from '../../services/user/user.service';
import {User} from './shared/User';

@Component({
  moduleId: module.id,
  selector: 'login',
  //styleUrls: ['assets/pages/css/login-4.min.css'],
  templateUrl: 'login.component.html'
  //providers: [appRoutingProviders]
})

export class LoginComponent {
  
  users: User[];
  email: string;
  password: string;
  returnUrl: string;
  
  error: boolean;
  success: boolean;
  message: string;
  
  menu?: boolean = false;
    
    constructor(private route: ActivatedRoute,private router: Router,private userService:UserService){
        this.userService.getUsers()
            .subscribe(users => {
                this.users = users;
            });
        
        this.error = false;
        this.success = false;
        this.message = '';
        this.menu = false;
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/preview';
    }
    
  ngOnInit() {
        // reset login status
        //this.authenticationService.logout();
 
        // get return url from route parameters or default to '/'
        //this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/about';
    }
  
  login(event){
        event.preventDefault();
        var userdata = {
            email: this.email,
            password: this.password,
        }
        
        if(typeof(this.email) !== 'undefined' && this.email !== ""){                                      
            var x = this.email;
            var atpos = x.indexOf("@");
            var dotpos = x.lastIndexOf(".");
        }
        
        if(typeof(this.email) === 'undefined' || this.email === ""){
          
          this.error = true;
          this.message = 'Email-ID is required';
          setTimeout(() => {
            this.error = false;
            this.success = false;
            this.message = '';
          }, 3000);
          
        }
        else if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length){                                      
            
          this.error = true;
          this.message = 'Not a valid e-mail address';
          setTimeout(() => {
            this.error = false;
            this.success = false;
            this.message = '';
          }, 3000);
           
        }
        else if(typeof(this.password) === 'undefined' || this.password === ""){
          //console.log("user.password : "+this.password);
          this.error = true;
          this.message = 'Password is required';
          setTimeout(() => {
            this.error = false;
            this.success = false;
            this.message = '';
          }, 3000);
          
        }
        else{
          this.userService.login(userdata)
            .subscribe(
                data => {
                    // login successful so redirect to return url
                    //console.log('Login success '+ data.success);
                    //console.log('Login message '+ data.message);
                    //
                    //this.success = data.success;
                    //this.message = data.message;
                    
                    if(data.success === true)
                    {
                      //this.success = true;
                      //this.message = data.message;
                      //setTimeout(() => {
                      //  this.error = false;
                      //  this.success = false;
                      //  this.message = '';
                      //  this.router.navigate([this.returnUrl]);
                      //}, 3000);
                      this.router.navigate([this.returnUrl]);
                    }
                    else {
                      this.error = true;
                      this.success = false;
                      this.message = data.message;
                      
                      setTimeout(() => {
                        this.error = false;
                        this.success = false;
                        this.message = '';
                      }, 3000);
                    }
                },
                error => {
                    // login failed so display error
                    console.log('Login failed '+ error);
                    this.error = true;
                    this.success = false;
                    this.message = 'Login failed '+ error;
                    setTimeout(() => {
                      this.error = false;
                      this.success = false;
                      this.message = '';
                    }, 3000);
                });
        }
    }
         
}
