"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var login_component_1 = require("./components/login/login.component");
var registration_component_1 = require("./components/registration/registration.component");
var preview_component_1 = require("./components/preview/preview.component");
var simple_sortable_component_1 = require("./components/dnd/simple-sortable.component");
var appRoutes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'login', component: login_component_1.LoginComponent, data: { title: 'Login' } },
    { path: 'registration', component: registration_component_1.RegistrationComponent, data: { title: 'Registration' } },
    { path: 'preview', component: preview_component_1.PreviewComponent, data: { title: 'Preview' } },
    { path: 'dnd', component: simple_sortable_component_1.SimpleSortableComponent, data: { title: 'dragNdrop' } }
];
exports.appRoutingProviders = [];
exports.routing = router_1.RouterModule.forRoot(appRoutes, { useHash: true });
//# sourceMappingURL=app.routing.js.map