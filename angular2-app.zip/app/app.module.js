"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var http_1 = require("@angular/http");
var forms_1 = require("@angular/forms");
var app_component_1 = require("./app.component");
var login_component_1 = require("./components/login/login.component");
var registration_component_1 = require("./components/registration/registration.component");
var preview_component_1 = require("./components/preview/preview.component");
var menu_component_1 = require("./components/common/menu.component");
var profile_component_1 = require("./components/preview/components/profile/profile.component");
var education_component_1 = require("./components/preview/components/education/education.component");
var language_component_1 = require("./components/preview/components/language/language.component");
var work_component_1 = require("./components/preview/components/work/work.component");
var project_component_1 = require("./components/preview/components/project/project.component");
var certificate_component_1 = require("./components/preview/components/certificate/certificate.component");
var award_component_1 = require("./components/preview/components/award/award.component");
var ng2_dnd_1 = require("ng2-dnd");
var simple_sortable_component_1 = require("./components/dnd/simple-sortable.component");
var app_routing_1 = require("./app.routing");
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, http_1.HttpModule, forms_1.FormsModule, app_routing_1.routing, ng2_dnd_1.DndModule.forRoot()],
        declarations: [app_component_1.AppComponent, login_component_1.LoginComponent, menu_component_1.MenuComponent, registration_component_1.RegistrationComponent, preview_component_1.PreviewComponent, simple_sortable_component_1.SimpleSortableComponent, profile_component_1.ProfileComponent, education_component_1.EducationComponent, language_component_1.LanguageComponent, work_component_1.WorkComponent, project_component_1.ProjectComponent, certificate_component_1.CertificateComponent, award_component_1.AwardComponent],
        providers: [app_routing_1.appRoutingProviders],
        bootstrap: [app_component_1.AppComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map