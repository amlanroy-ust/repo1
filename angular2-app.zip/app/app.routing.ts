import {Routes, RouterModule} from "@angular/router";
import {LoginComponent} from "./components/login/login.component";
import {RegistrationComponent} from "./components/registration/registration.component";
import {PreviewComponent} from "./components/preview/preview.component";
import {ModuleWithProviders} from "@angular/core";
import {SimpleSortableComponent} from './components/dnd/simple-sortable.component';

const appRoutes: Routes = [
    {path: '', redirectTo: 'login', pathMatch: 'full'},
    {path: 'login', component: LoginComponent, data: {title: 'Login'}},
    {path: 'registration', component: RegistrationComponent, data: {title: 'Registration'}},
    {path: 'preview', component: PreviewComponent, data: {title: 'Preview'}},
    {path: 'dnd',     component: SimpleSortableComponent, data: {title: 'dragNdrop'}}
];

export const appRoutingProviders: any[] = [];
export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes, { useHash: true });
