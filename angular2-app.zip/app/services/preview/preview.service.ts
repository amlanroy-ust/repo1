import {Injectable} from '@angular/core';
import {Http, Headers} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class PreviewService{
    constructor(private http:Http){
        console.log('Preview Service Initialized...');
    }
    
    // Get personal info
    getPersonalInfo(){
        return this.http.get('/api/personalInfo')
            .map(res => res.json());
    }
    
    // Get education info
    getEducationInfo(){
        return this.http.get('/api/educationInfo')
            .map(res => res.json());
    }
    
    //Get qualification Info
    getQualificationInfo(){
        return this.http.get('/api/qualificationInfo')
            .map(res => res.json());
    }
    
    //Get work Info
    getWorkInfo(){
        return this.http.get('/api/workInfo')
            .map(res => res.json());
    }
    
    //Get project Info
    getProjectInfo(){
        return this.http.get('/api/projectInfo')
            .map(res => res.json());
    }
    
    //Get certificate Info
    getCertificateInfo(){
        return this.http.get('/api/certificateInfo')
            .map(res => res.json());
    }
    
    //Get award Info
    getAwardInfo(){
        return this.http.get('/api/awardInfo')
            .map(res => res.json());
    }
}