import {Injectable} from '@angular/core';
import {Http, Headers} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class UserService{
    constructor(private http:Http){
        console.log('User Service Initialized...');
    }
    getUsers(){
        return this.http.get('/api/users')
            .map(res => res.json());
    }
    login(userdata){
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post('/api/frontLogin', JSON.stringify(userdata), {headers: headers})
            .map(res => res.json());
    }
    registration(userdata){
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post('/api/registration', JSON.stringify(userdata), {headers: headers})
            .map(res => res.json());
    }
    logout(){
        console.log('Logout Service Initialized...');
        return this.http.get('/api/logout')
            .map(res => res.json());
    }
}