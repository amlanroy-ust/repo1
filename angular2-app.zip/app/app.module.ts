import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpModule} from '@angular/http';
import {FormsModule} from '@angular/forms';
import {AppComponent} from './app.component';
import {LoginComponent} from './components/login/login.component';
import {RegistrationComponent} from './components/registration/registration.component';
import {PreviewComponent} from './components/preview/preview.component';
import {MenuComponent} from './components/common/menu.component';

import { ProfileComponent } from './components/preview/components/profile/profile.component';
import { EducationComponent } from './components/preview/components/education/education.component';
import { LanguageComponent } from './components/preview/components/language/language.component';
import { WorkComponent } from './components/preview/components/work/work.component';
import { ProjectComponent } from './components/preview/components/project/project.component';
import { CertificateComponent } from './components/preview/components/certificate/certificate.component';
import { AwardComponent } from './components/preview/components/award/award.component';

import { DndModule } from 'ng2-dnd';
import { SimpleSortableComponent } from './components/dnd/simple-sortable.component';

import {routing, appRoutingProviders} from './app.routing';

@NgModule({
  imports:      [ BrowserModule, HttpModule, FormsModule, routing, DndModule.forRoot() ],
  declarations: [AppComponent, LoginComponent, MenuComponent, RegistrationComponent, PreviewComponent, SimpleSortableComponent,ProfileComponent, EducationComponent, LanguageComponent, WorkComponent, ProjectComponent, CertificateComponent, AwardComponent],
  providers: [appRoutingProviders],
  bootstrap: [AppComponent]
})
export class AppModule { }
