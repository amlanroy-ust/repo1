import * as _ from "lodash";
import {Pipe, PipeTransform} from "@angular/core";

@Pipe({
    name: "dataFilter"
})
export class DataFilterPipe implements PipeTransform {

    transform(array: any[], query: string): any {
        if (query) {
            query = query.toUpperCase();

            array = _.filter(array, row=>row._visitor.firstName.toUpperCase().indexOf(query) > -1);
            // if (!array || !array.length)
            // array = _.filter(array, row=>row._visitor.company.toUpperCase().indexOf(query) > -1);
            return array;
            // if (array || array.length > 0)
            //   return array;
            // else{
            //   array = _.filter(array, row=>row._visitor.company.toUpperCase().indexOf(query) > -1);
            //   if (array || array.length > 0)
            //   return array;
            // }
        }

        return array;
        
    }

    // public transform(value, keys: string, term: string) {

    //     if (!term) return value;
    //     return (value || []).filter((item) => keys.split(',').some(key => item.hasOwnProperty(key) && new RegExp(term, 'gi').test(item[key])));

    // }
}

@Pipe({
  name: 'searchPipe'
})
export class searchPipe implements PipeTransform {
  transform(values: any[], filter: string): any {
    
    //console.log('values', values);
    //console.log('filter', filter);

    //if (!values || !values.length) return [];
    //if (!filter) return values;
    
    //filter = filter.toUpperCase();
    //console.log('filter', filter);
    
    if (filter && Array.isArray(values)) {
      //const keys = Object.keys(values[0]);
      //console.log('keys', keys);
      //return values.filter(v => v && keys.some(k => v[k].toUpperCase().indexOf(filter) >= 0));
      //return _.filter(values, row=>row._visitor.company.indexOf(filter) > -1);
    }
  }
}