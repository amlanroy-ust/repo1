import { Component, OnInit, Injectable } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { appConfig } from '../app.config';
import { User } from '../_models/index';
import { UserService } from '../_services/index';
import { AdalService } from './../services/adal.service';
import { AuthenticationGuard } from '../services/authenticated.guard';
import { Subscription } from 'rxjs/Subscription';

import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';

@Injectable()

@Component({
  selector: 'app-admin',
  moduleId: module.id,
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  //currentUser: User;
  loginUser: any = {};
  //visitors: any = {};
  returnUrl: string;
  visitDtls: any;
  
  visitors:any[];
  errorMsg:string;
  visitList = [];
  subscription: Subscription;
      
  public data;
  public filterQuery = "";
  public rowsOnPage = 10;
  public sortBy = "name";
  public sortOrder = "asc";

  jsonData: any = {};
  visitArray = [];
  show_result = false;

  public dataTable: any = [
    {"Name":"Gaurav","Address":"Chennai","Contact":"9632587410"},
    {"Name":"Rakesh","Address":"Goa","Contact":"7895123640"},
    {"Name":"Peter","Address":"Goa","Contact":"123"},
    {"Name":"Hans","Address":"Trivandrum","Contact":"456"},
    {"Name":"Tim","Address":"Mumbai","Contact":"789"},
    {"Name":"Maik","Address":"Delhi","Contact":"111"},
    {"Name":"Robert","Address":"Kolkata","Contact":"222"}
  ];

  reportInput: any = {};
  options: any = {};
  toDay: string;
  month: number;
  start_month: string;
  end_month: string;
  private date = new Date();
  ReportBy: any = {};
  ReportByvalues = [{name: 'Date'}, {name: 'Email'}, {name: 'Company'}, {name: 'Name'}];

  public selectedDate(value: any) {
      //console.log('value: ', value);
      this.start_month = ("0" + (value.start._d.getMonth() + 1)).slice(-2);
      this.end_month = ("0" + (value.end._d.getMonth() + 1)).slice(-2);

      this.reportInput.visitFromDate = value.start._d.getFullYear() + '-' + this.start_month + '-' + ("0" + value.start._d.getDate()).slice(-2);

      this.reportInput.visitToDate = value.end._d.getFullYear() + '-'+this.end_month + '-' + ("0" + value.end._d.getDate()).slice(-2); 
  }

  constructor(private userService: UserService, private route: ActivatedRoute, private router: Router, private adalService: AdalService, private AuthenticationGuard: AuthenticationGuard) {
        //console.log('Admin component is working', this.adalService.userInfo);  
        if (this.adalService.userInfo) {

            this.subscription = this.AuthenticationGuard.getMessage().subscribe(loginUser => { this.loginUser = loginUser.text; });
            
            // this.loginUser = { "empType": "emp", "firstName": this.adalService.userInfo.userName, "userInfo": this.adalService.userInfo };
        }  
        else this.loginUser = JSON.parse(localStorage.getItem('currentUser'));

        if(this.loginUser === null)
        {
          this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/login';
          this.router.navigate([this.returnUrl]);
        }
        else if(this.loginUser.empType === "admin")
        {
          this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/admin';
          this.router.navigate([this.returnUrl]);
        }
        else if(this.loginUser.empType === "emp")
        {
          this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/home';
          this.router.navigate([this.returnUrl]);
        }
        else if(this.loginUser.empType === "visitor")
        {
          this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/visitor-home';
          this.router.navigate([this.returnUrl]);
        }

        this.month = this.date.getMonth() + 1;

        this.toDay = this.date.getFullYear()+'-'+this.month+'-'+this.date.getDate();
        this.options = {
            locale: { format: 'YYYY-MM-DD' }
            // "dateLimit": {
            //     "days": 30
            // },
            // "startDate": this.toDay,
            // "endDate": this.toDay,
            // "minDate": this.toDay
        };

        this.ReportBy = this.ReportByvalues[0];
        this.reportInput.Name = "";
        this.reportInput.Email = "";
        this.reportInput.Company = "";

    }

  ngOnInit() {
        //console.log('this.loginUser in Admin ', this.loginUser);
        //if(this.loginUser !== null)
        this.loadAllVisits();

        // this.start_month = ("0" + (this.date.getMonth() + 1)).slice(-2);
        // this.end_month = ("0" + (this.date.getMonth() + 1)).slice(-2);

        // this.reportInput.visitFromDate = this.date.getFullYear() + '-' + this.start_month + '-' + ("0" + this.date.getDate()).slice(-2);

        // this.reportInput.visitToDate = this.date.getFullYear() + '-'+this.end_month + '-' + ("0" + this.date.getDate()).slice(-2);

  }

  private loadAllVisits() {
        this.userService.getAllVisit().subscribe(visits => { 
            this.visitList = visits.visitList; 
            //console.log('this.visitList', this.visitList);
                        
            //We iterate the array in the code
            for(let data of this.visitList) {
                this.jsonData = {'Visit Pin': data.visitPin, "First Name":data._visitor.firstName, 'Last Name': data._visitor.lastName, "Visit From Date":data.visitFromDate, 'Visit To Date': data.visitToDate, "Email":data._visitor.email, 'Contact': data._visitor.contact, "Company":data._visitor.company, 'Facility': data.facility, "Meet Person":data.meetPerson};
                this.visitArray.push(this.jsonData);
            }
            // setTimeout(()=>{
            //         this.show_result = true;
            //     },5000);

        });

        this.reportInput.visitFromDate = "";
        this.reportInput.visitToDate = "";
        this.reportInput.Company = "";
        this.reportInput.Name = "";
        this.reportInput.Email = "";
    }

    visitDetails(data: any){
        //console.log('data', data);
        this.visitDtls = {'firstName': data._visitor.firstName, 'lastName': data._visitor.lastName, 'contact': data._visitor.contact, 'visitFromDate': data.visitFromDate, 'visitToDate': data.visitToDate, 'visitPin': data.visitPin, 'facility': data.facility, 'meetPerson': data.meetPerson};
    }

    reportGenerate(){   
      //console.log('this.reportInput', this.reportInput);
      //var visitFromDate = this.reportInput.fromDate;
      //var visitToDate = this.reportInput.toDate;

      this.userService.getVisitReport(this.reportInput).subscribe(visits => { 
            //console.log('Report: ', visits);
            this.visitList = visits.visitList;
            this.visitArray = [];
            //We iterate the array in the code
            for(let data of this.visitList) {
                this.jsonData = {'Visit Pin': data.visitPin, "First Name":data._visitor.firstName, 'Last Name': data._visitor.lastName, "Visit From Date":data.visitFromDate, 'Visit To Date': data.visitToDate, "Email":data._visitor.email, 'Contact': data._visitor.contact, "Company":data._visitor.company, 'Facility': data.facility, "Meet Person":data.meetPerson};
                this.visitArray.push(this.jsonData);
            }
            //console.log('this.visitArray', this.visitArray);
      });

    }

    public exportAsExcelFile(excelFileName: string): void {
      //console.log('excelFileName', excelFileName);
      var json: any;
      json = this.visitArray;
      const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
      const workbook: XLSX.WorkBook = { Sheets: { 'Visit-Report': worksheet }, SheetNames: ['Visit-Report'] };
      const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'buffer' });
      this.visitArray = [];
      this.saveAsExcelFile(excelBuffer, excelFileName);
    }

    private saveAsExcelFile(buffer: any, fileName: string): void {
      const data: Blob = new Blob([buffer], {
        type: EXCEL_TYPE
      });
      FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
    }

    reportGenerateBy(reportBy: any){
      //console.log('reportBy ', reportBy);
      if(reportBy.name === 'Date')
      {
        this.reportInput.Email = "";
        this.reportInput.Company = "";
        this.reportInput.Name = "";
      }
      if(reportBy.name === 'Email')
      {
        this.reportInput.visitFromDate = "";
        this.reportInput.visitToDate = "";
        this.reportInput.Company = "";
        this.reportInput.Name = "";
      }
      if(reportBy.name === 'Company')
      {
        this.reportInput.visitFromDate = "";
        this.reportInput.visitToDate = "";
        this.reportInput.Email = "";
        this.reportInput.Name = "";
      }
      if(reportBy.name === 'Name')
      {
        this.reportInput.visitFromDate = "";
        this.reportInput.visitToDate = "";
        this.reportInput.Email = "";
        this.reportInput.Company = "";
      }
    }

}
