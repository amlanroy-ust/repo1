import * as _ from "lodash";
import {Pipe, PipeTransform} from "@angular/core";

@Pipe({
    name: "dataFilter"
})
export class DataFilterPipe implements PipeTransform {

    transform(array: any[], query: string): any {
        if (query) {
            
            return _.filter(array, row=>row._visitor.firstName.indexOf(query) > -1);
            //return _.filter(array, row=>row._visitor.company.indexOf(query) > -1);
            
        }
        // if(array.length == 0)
        //     return _.filter(array, row=>row._visitor.company.indexOf(query) > -1);
        // }

        return array;
        
    }

    // public transform(value, keys: string, term: string) {

    //     if (!term) return value;
    //     return (value || []).filter((item) => keys.split(',').some(key => item.hasOwnProperty(key) && new RegExp(term, 'gi').test(item[key])));

    // }
}