import { ModuleWithProviders } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';

import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
//import {VisitorComponent } from './visitor/visitor.component';
import { RepoBrowserComponent } from './github/repo-browser/repo-browser.component';
import { RepoListComponent } from './github/repo-list/repo-list.component';
import { RepoDetailComponent } from './github/repo-detail/repo-detail.component';
import { LoginComponent } from './login/login.component';
import { OAuthCallbackHandler } from './login-callback/oauth-callback.guard';
import { OAuthCallbackComponent } from './login-callback/oauth-callback.component';
import { AuthenticationGuard } from "./services/authenticated.guard";
import {AdminComponent} from "./admin/admin.component";
import { ManagevisitComponent } from './admin-manage-visit/managevisit.component';
import { GroupComponent } from './admin-group/group.component';

export const rootRouterConfig: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'home', component: HomeComponent, canActivate: [AuthenticationGuard] },
  { path: 'visitor-home', component: HomeComponent },
  //{path:"visitor", component: VisitorComponent},
  { path: 'about', component: AboutComponent },
  { path: 'login', component: LoginComponent },
  {path:"admin", component: AdminComponent},
  {path:"manage-visit", component: ManagevisitComponent},
  {path:"manage-group", component: GroupComponent},
  { path: 'id_token', component: OAuthCallbackComponent, canActivate: [OAuthCallbackHandler] },
  //{ path: '#id_token', component: OAuthCallbackComponent, canActivate: [OAuthCallbackHandler] },
  // otherwise redirect to home
  //{ path: '**', redirectTo: 'login' }
  { path: 'lazy', loadChildren: 'app/lazy/lazy.module#LazyModule' },
  { path: 'privacy', loadChildren: 'app/privacy/privacy.module#PrivacyModule' },
  { path: 'visitor', loadChildren: 'app/visitor/visitor.module#VisitorModule' }
];

export const routes: ModuleWithProviders = RouterModule.forRoot(rootRouterConfig);

// import {ModuleWithProviders} from "@angular/core";
// import {Routes,RouterModule} from "@angular/router";

// //import {AppComponent} from "./app.component";
// import {HomeComponent} from "./home/home.component";
// import {VisitorComponent } from './visitor/visitor.component';
// import {LoginComponent} from "./login/login.component";
// import {AdminComponent} from "./admin/admin.component";

// import { OAuthCallbackHandler } from './login-callback/oauth-callback.guard';
// import { OAuthCallbackComponent } from './login-callback/oauth-callback.component';
// import { AuthenticationGuard } from "./services/authenticated.guard";


// export const router:Routes=[
//     {path:"", redirectTo:"login", pathMatch:"full"},
//     {path:"home", component: HomeComponent},
//     {path:"visitor", component: VisitorComponent},
//     {path:"login",component: LoginComponent},
//     { path: 'id_token', component: OAuthCallbackComponent, canActivate: [OAuthCallbackHandler] },
//     {path:"admin", component: AdminComponent},

//     // otherwise redirect to home
//     { path: '**', redirectTo: 'login' }
    
// ];

// export const routes: ModuleWithProviders = RouterModule.forRoot(router);