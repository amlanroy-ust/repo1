
import { LoginComponent } from './login.component';
import { NgModule } from '@angular/core';

@NgModule({
    imports: [],
    declarations: [LoginComponent]
})
export class LoginModule { }