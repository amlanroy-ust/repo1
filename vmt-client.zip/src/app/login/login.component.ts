import { Router, ActivatedRoute } from '@angular/router';
import { User } from '../_models/index';
import { AdalService } from './../services/adal.service';
import { Component, OnInit } from '@angular/core';
import { AlertService, AuthenticationService } from '../_services/index';

@Component({
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

    model: any = {};
    loading = false;
    returnUrl: string;
    loginUser: User;
    show_message = false;
    loginDiv = false;
    empLoginDiv = false;

    constructor(private router: Router, private adalService: AdalService, private authenticationService: AuthenticationService, private alertService: AlertService, private route: ActivatedRoute) { }

    ngOnInit() {
        //console.log(this.adalService.userInfo);
        //console.log('this.adalService.userInfo', this.adalService.userInfo);
        this.authenticationService.logout();
        // get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/home';
    }

    loginType(type: string){
        //console.log('Login Type: ', type);
        if(type === "visitor") 
        {
            this.loginDiv = true;
            this.empLoginDiv = false;
        }
        else
        {
            this.loginDiv = false;
            //this.empLoginDiv = true;
            this.login();
        }
    }

    hideLogin(){
        this.loginDiv = false;
        this.empLoginDiv = false;
    }

    login() {
        this.adalService.login();
    }

    logout() {
        this.adalService.logout();
    }

    public get isLoggedIn() {
        return this.adalService.isAuthenticated;
    }

    Employeelogin() {
        this.loading = true;
        //console.log('Hi you pressed login button!!!', this.model.username, this.model.password);
        this.authenticationService.login(this.model.username, this.model.password)
            .subscribe(
                data => {
                    //console.log('data', data);
                    if(data.status === 400)
                    {
                        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/login';
                        this.show_message = true;
                        setTimeout(()=>{
                            this.show_message = false;
                        },3000);
                        this.router.navigate([this.returnUrl]);
                    }
                    else{
                        if(data.empType === "emp" || data.empType === "visitor"){
                            this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/visitor-home';
                            console.log('url: ',this.returnUrl);
                            this.router.navigate([this.returnUrl]);
                        }
                        else{
                            this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/admin';
                            this.router.navigate([this.returnUrl]);
                        }
                    }
                    //this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
                    //window.location.reload();
                },
                error => {
                    this.alertService.error(error);
                    this.loading = false;
                });
    }
}