import { NgModule } from '@angular/core';

import { PrivacyComponent }   from './privacy.component';
import { routing } from './privacy.routing';

@NgModule({
  imports: [routing],
  declarations: [PrivacyComponent]
})
export class PrivacyModule {}
