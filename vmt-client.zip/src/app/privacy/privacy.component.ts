import { Component } from '@angular/core';

@Component({
  selector: 'privacy',
  templateUrl: './privacy.component.html'
})
export class PrivacyComponent {
  developer = 'Hi this message is passing from privacy to about...';
  agreed = 0;
  disagreed = 0;
  voters = ['Mr. IQ', 'Ms. Universe', 'Bombasto'];

  onVoted(agreed: boolean) {
    agreed ? this.agreed++ : this.disagreed++;
  }
}