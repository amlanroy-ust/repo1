import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { appConfig } from '../app.config';
import { User } from '../_models/index';
import { UserService } from '../_services/index';
import { AdalService } from './../services/adal.service';
import { AuthenticationGuard } from '../services/authenticated.guard';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'manage-visit',
  moduleId: module.id,
  templateUrl: './managevisit.component.html',
  styleUrls: ['./managevisit.component.css']
})
export class ManagevisitComponent implements OnInit {

  loginUser: any = {};
  returnUrl: string;
  visitDtls: any;

  //visitors:any[];
  errorMsg:string;
  visitList = [];
  subscription: Subscription;
      
  public data;
  public filterQuery = "";
  public rowsOnPage = 10;
  public sortBy = "name";
  public sortOrder = "asc";

  jsonData: any = {};
  visitArray = [];
  show_result = false;
  visitors = ['Customer', 'Personal', 'Visitor', 'Vendor'];
  Customer = true;
  Personal = false;
  Visitor = false;
  Vendor = false;
  visitSettings: any = {};
  show_message = false;
  message: string;

  constructor(private userService: UserService, private route: ActivatedRoute, private router: Router, private adalService: AdalService, private AuthenticationGuard: AuthenticationGuard) {
        //console.log('Admin manage visit component is working', this.adalService.userInfo);  
        if (this.adalService.userInfo) {

            this.subscription = this.AuthenticationGuard.getMessage().subscribe(loginUser => { this.loginUser = loginUser.text; });
            
            // this.loginUser = { "empType": "emp", "firstName": this.adalService.userInfo.userName, "userInfo": this.adalService.userInfo };
        }  
        else this.loginUser = JSON.parse(localStorage.getItem('currentUser'));

        if(this.loginUser === null)
        {
          this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/login';
          this.router.navigate([this.returnUrl]);
        }
        else if(this.loginUser.empType === "admin")
        {
          this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/manage-visit';
          this.router.navigate([this.returnUrl]);
        }
        else if(this.loginUser.empType === "emp")
        {
          this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/home';
          this.router.navigate([this.returnUrl]);
        }
        else if(this.loginUser.empType === "visitor")
        {
          this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/visitor-home';
          this.router.navigate([this.returnUrl]);
        }

        this.visitSettings.refmCustomer = false;
        this.visitSettings.refmPersonal = false;
        this.visitSettings.refmVisitor = false;
        this.visitSettings.refmVendor = false;
        this.visitSettings.ismsCustomer = false;
        this.visitSettings.ismsPersonal = false;
        this.visitSettings.ismsVisitor = false;
        this.visitSettings.ismsVendor = false;

    }

  ngOnInit() {
        //console.log('this.loginUser in Admin ', this.loginUser);
        //if(this.loginUser !== null)
        this.loadAllVisits();
        this.loadAllVisitSettings();
  }

  private loadAllVisits() {
        this.userService.getAllVisit().subscribe(visits => { 
            this.visitList = visits.visitList; 
            //console.log('this.visitList', this.visitList);

            //console.log('this.dataTable', this.dataTable);
            
            //We iterate the array in the code
            // for(let data of this.visitList) {
            //     this.jsonData = {"firstName":data._visitor.firstName,"company":data._visitor.company,"visitFromDate":data.visitFromDate,"email":data._visitor.email,"meetPerson":data.meetPerson};
            //     this.visitArray.push(this.jsonData);
            // }
            // console.log('this.visitArray', this.visitArray);

            // setTimeout(()=>{
            //         this.show_result = true;
            //     },5000);

        });
    }

    private loadAllVisitSettings() {
        this.userService.getVisitSettings().subscribe(settings => { 
            //this.settings = visitSettings.visitList; 
            //console.log('settings ', settings.settingsData);
            if(settings.settingsData !== null){
              this.visitSettings.refmCustomer = settings.settingsData.refmCustomer;
              this.visitSettings.refmPersonal = settings.settingsData.refmPersonal;
              this.visitSettings.refmVisitor = settings.settingsData.refmVisitor;
              this.visitSettings.refmVendor = settings.settingsData.refmVendor;
              this.visitSettings.ismsCustomer = settings.settingsData.ismsCustomer;
              this.visitSettings.ismsPersonal = settings.settingsData.ismsPersonal;
              this.visitSettings.ismsVisitor = settings.settingsData.ismsVisitor;
              this.visitSettings.ismsVendor = settings.settingsData.ismsVendor;
            }

        });
    }

    managePermission(){
      // console.log('Customer', this.visitSettings.refmCustomer);
      // console.log('Personal', this.visitSettings.refmPersonal);
      // console.log('Visitor', this.visitSettings.refmVisitor);
      // console.log('this.visitSettings.refmVendor', this.visitSettings.refmVendor);

      this.userService.visitSettings(this.visitSettings)
        .subscribe(
            data => {
                //alert('Settings updated successfully');
                //console.log('Settings updated successfully', data);
                //this.router.navigate(['/manage-visit']);
                  this.show_message = true;
                  this.message = 'Settings updated successfully';
                  //console.log('message', this.error_message);
                  setTimeout(()=>{
                      this.show_message = false;
                      this.message = '';
                  },5000);
            },
            error => {
                    //this.alertService.error(error);
                    //this.loading = false;
                    //console.log(error);
                    error = JSON.parse(error);
                    console.log('error', error);
                    this.show_message = true;
                    this.message = error.message;
                    //console.log('message', this.error_message);
                    setTimeout(()=>{
                        this.show_message = false;
                        this.message = '';
                    },5000);
            });

    }

    // visitDetails(data: any){
    //     console.log('data', data);
    //     this.visitDtls = {'firstName': data._visitor.firstName, 'contact': data._visitor.contact, 'visitFromDate': data.visitFromDate, 'visitToDate': data.visitToDate, 'visitPin': data.visitPin, 'facility': data.facility, 'meetPerson': data.meetPerson};
    // }

}
