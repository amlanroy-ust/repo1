import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { appConfig } from '../app.config';
import { User } from '../_models/index';
import { UserService } from '../_services/index';
import { AdalService } from './../services/adal.service';

@Component({
  selector: 'app-home',
  moduleId: module.id,
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  //currentUser: User;
  loginUser: any = {};
  users: User[] = [];
  //model: any = {};
  //update = false;
  //view = false;
  //title = 'Home';
  //userDatas = [];
  //filesToUpload: Array<File>;
  //formName: string;
  //show_message = false;
  //apiUrl: string;
  returnUrl: string;
  userdetails: any = {};

  birthday = new Date(1988, 3, 15); // April 15, 1988
  toggle = true; // start with true == shortDate

  get format()   { return this.toggle ? 'shortDate' : 'fullDate'; }
  toggleFormat() { this.toggle = !this.toggle; }

  constructor(private userService: UserService, private route: ActivatedRoute, private router: Router, private adalService: AdalService) {
        console.log('Home component is working');    
        
        //console.log('User info from JWT');
        //console.log(this.adalService.userInfo);

        //this.loginUser = JSON.stringify(localStorage.getItem('currentUser'));

        if (this.adalService.userInfo) {
            this.loginUser = { "empType": "emp", "firstName": this.adalService.userInfo.userName, "userInfo": this.adalService.userInfo };
        }
        else this.loginUser = JSON.parse(localStorage.getItem('currentUser'));

        //console.log('this.loginUser', this.loginUser.empType);


        if(this.loginUser === null)
        {
          this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/login';
          this.router.navigate([this.returnUrl]);
        }
        else{
          this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/home';
          this.router.navigate([this.returnUrl]);
        }

        // else if(this.loginUser.empType === "admin")
        // {
        //   this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/admin';
        //   this.router.navigate([this.returnUrl]);
        // }
        // else if(this.loginUser.empType === "emp")
        // {
        //   this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/home';
        //   this.router.navigate([this.returnUrl]);
        // }
        // else if(this.loginUser.empType === "visitor")
        // {
        //   this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/visitor-home';
        //   this.router.navigate([this.returnUrl]);
        // }

        //this.filesToUpload = [];
        //console.log('appConfig.apiUrl', appConfig.apiUrl);
        //this.apiUrl = appConfig.apiUrl;
        
    }

  ngOnInit() {
        //console.log('this.loginUser', this.loginUser);
        //if(this.loginUser !== null)
        //this.loadAllUsers();
  }

}
