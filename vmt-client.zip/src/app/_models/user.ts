﻿export class User {
    _id: string;
    username: string;
    password: string;
    firstName: string;
    lastName: string;
    dob: Date;
    haveAssets: boolean;
    needUstConnection: boolean;
    needGuestWiFi: boolean;
    profile_image: string;
}