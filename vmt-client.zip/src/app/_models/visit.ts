﻿export class Visit {
    _id: string;
    _visitor: string;
    visitFromDate: Date;
    visitToDate: Date;
}