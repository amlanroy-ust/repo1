﻿export class Visitor {
    _id: string;
    firstName: string;
    lastName: string;
    contact: number;
    company: string;
    email: string;
    visitorType: string;
    address: string;
}