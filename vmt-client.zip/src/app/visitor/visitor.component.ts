import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormControl, FormBuilder } from "@angular/forms";
import { Router, ActivatedRoute } from '@angular/router';
import { appConfig } from '../app.config';
import { User } from '../_models/index';
import { UserService, AuthenticationService } from '../_services/index';
import { AdalService } from './../services/adal.service';
import {style, state, animate, transition, trigger} from '@angular/core';

@Component({
  //selector: 'app-visitor',
  moduleId: module.id,
  templateUrl: './visitor.component.html',
  styleUrls: ['./visitor.component.css'],
  animations: [
    trigger('fadeInOut', [
            transition(':enter', [   // :enter is alias to 'void => *'
            style({opacity:0}),
            animate(500, style({opacity:1})) 
            ]),
            transition(':leave', [   // :leave is alias to '* => void'
            animate(500, style({opacity:0})) 
            ])
        ])
    ]
})
export class VisitorComponent implements OnInit {
  //model: any = {};
  visitorDetails: any = {};
  visitDetails: any = {};
  dateRange: any = {};
  loginUser: any = {};
  users: User[] = [];
  returnUrl: string;
  str_array = Array;
  options: any = {};
  toDay: string;
  month: number;
  start_month: string;
  end_month: string;
  show_message = false;
  error_message: string;
  error_modal = false;
  modal_message: string;
  userDatas = [];
  inputFocus = false;
  searchDatas: any;
  
  visitors = ['Customer', 'Personal', 'Visitor', 'Vendor'];
  companies = ['UST Global', 'IBM', 'Infosys', 'TCS', 'Accenture', 'CTS', 'Capgemini'];
  facilities = ['Campus Building 1', 'Tejaswini', 'UST Global Corporate HQ', 'Bhavani'];
  id_proofs = ['Company ID', 'Other Photo ID'];

  //orders: any = {};
  
  private date = new Date();

  public selectedDate(value: any) {
      //console.log('value: ', value.start);
      this.start_month = ("0" + (value.start._d.getMonth() + 1)).slice(-2);
      this.end_month = ("0" + (value.end._d.getMonth() + 1)).slice(-2);

      this.visitDetails.fromDate = value.start._d.getFullYear() + '-' + this.start_month + '-' + ("0" + value.start._d.getDate()).slice(-2);

      this.visitDetails.toDate = value.end._d.getFullYear() + '-'+this.end_month + '-' + ("0" + value.end._d.getDate()).slice(-2);

      //console.log('this.visitDetails.fromDate', this.visitDetails.fromDate);
      //console.log('this.visitDetails.toDate', this.visitDetails.toDate);
  }

  constructor(private userService: UserService, private route: ActivatedRoute, private router: Router, private authenticationService: AuthenticationService, private adalService: AdalService) {
    
    //console.log('visitor component');

    if (this.adalService.userInfo) {
            this.loginUser = { "empType": "emp", "firstName": this.adalService.userInfo.userName, "userInfo": this.adalService.userInfo, "homeRedirect": "home" };
            this.visitorDetails.createdBy = this.adalService.userInfo.userName;
            this.visitorDetails.createdByType = this.loginUser.empType;
        }
    else 
    {
        this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
        this.visitorDetails.createdBy = this.loginUser.username;
        this.visitorDetails.createdByType = this.loginUser.empType;
    }

    if(this.loginUser === null)
    {
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/login';
        this.router.navigate([this.returnUrl]);
    }
    else if(this.loginUser.empType === "admin")
    {
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/admin';
        this.router.navigate([this.returnUrl]);
    }
    // else if(this.loginUser.empType === "emp")
    // {
    //     this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/home';
    //     this.router.navigate([this.returnUrl]);
    // }
    // else if(this.loginUser.empType === "visitor")
    // {
    //     this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/visitor-home';
    //     this.router.navigate([this.returnUrl]);
    // }

    this.month = this.date.getMonth() + 1;

    this.toDay = this.date.getFullYear()+'-'+this.month+'-'+this.date.getDate();
    this.options = {
        locale: { format: 'YYYY-MM-DD' },
        "dateLimit": {
            "days": 30
        },
        "startDate": this.toDay,
        "endDate": this.toDay,
        "minDate": this.toDay
        //"maxDate": "09/20/2017",
        //alwaysShowCalendars: false,
    };

    //this.orders = [{id: 1, type: 'type1'}, {id: 2, type: 'type2'}, {id: 3, type: 'type3'}];
      
  }

//   callType(value){
//     console.log('value', value);
//   }

  ngOnInit() {
    this.visitorDetails.visitorType = "";
    this.visitorDetails.facility = "";
    this.visitorDetails.idProof = "";
    this.visitorDetails.haveAsset = false;

    //console.log('this.loginUser', this.loginUser);
  }

  findUser() {
      if(this.visitorDetails.meetPerson != undefined){
        this.authenticationService.findUser(this.visitorDetails.meetPerson)
            .subscribe(
                data => {
                    //console.log('data', data);
                    //console.log('data.GetEmp_RecordDetailsOutputCollection', data.GetEmp_RecordDetailsOutputCollection);
                    if(data.status === 400 || data.GetEmp_RecordDetailsOutputCollection === "" || data.GetEmp_RecordDetailsOutputCollection === undefined)
                    {
                        //console.log('data in comp', data.GetEmp_RecordDetailsOutputCollection.GetEmp_RecordDetailsOutput);
                        console.log('Error 400: No data found');
                    }
                    else{
                        //console.log('data in comp', data.GetEmp_RecordDetailsOutputCollection.GetEmp_RecordDetailsOutput);

                        this.searchDatas = data.GetEmp_RecordDetailsOutputCollection.GetEmp_RecordDetailsOutput;
                        //console.log('this.searchDatas', this.searchDatas);

                        if (this.searchDatas instanceof Array) {
                            //console.log('value is Array!');
                            this.userDatas = [];
                            
                            //this.visitorDetails.meetPerson = data.GetEmp_RecordDetailsOutputCollection.GetEmp_RecordDetailsOutput[0].NAME_DISPLAY+"(UST, "+data.GetEmp_RecordDetailsOutputCollection.GetEmp_RecordDetailsOutput[0].EMP_COUNTRY_CODE+") - "+ data.GetEmp_RecordDetailsOutputCollection.GetEmp_RecordDetailsOutput[0].EMPLID;
                            // We iterate the array in the code
                            for(let arr of data.GetEmp_RecordDetailsOutputCollection.GetEmp_RecordDetailsOutput) {
                                var meetPerson = arr.NAME_DISPLAY+"(UST, "+arr.EMP_COUNTRY_CODE+") - "+ arr.EMPLID;
                                this.userDatas.push(meetPerson);
                                //console.log('arr.NAME_DISPLAY', arr.NAME_DISPLAY);
                            }
                            //this.inputFocus = true;

                            //console.log('this.userDatas', this.userDatas);

                        } else {
                            //console.log('Not an array');
                            this.userDatas = [];
                            var meetPerson = data.GetEmp_RecordDetailsOutputCollection.GetEmp_RecordDetailsOutput.NAME_DISPLAY+"(UST, "+data.GetEmp_RecordDetailsOutputCollection.GetEmp_RecordDetailsOutput.EMP_COUNTRY_CODE+") - "+ data.GetEmp_RecordDetailsOutputCollection.GetEmp_RecordDetailsOutput.EMPLID;
                            
                            this.userDatas = [meetPerson];
                            this.searchDatas = [data.GetEmp_RecordDetailsOutputCollection.GetEmp_RecordDetailsOutput];
                        }
                        
                    }
                },
                error => {
                    console.log('error', error);
                });
        }

    }

    openEmployeeModal(){
        //console.log('openEmployeeModal');
        this.findUser();
    }

    setMeetPerson(data: any) {
        //console.log('setMeetPerson', data);
        this.visitorDetails.meetPerson = data.NAME_DISPLAY+"(UST, "+data.EMP_COUNTRY_CODE+") - "+ data.EMPLID;
        this.modal_message = data.NAME_DISPLAY+"("+data.EMPLID+") selected";
        this.error_modal = true;
        setTimeout(()=>{
                        this.error_modal = false;
                        this.modal_message = '';
                    },4000);
    }

  addVisitor(){    

    //console.log('this.visitDetails', this.visitDetails);

    this.visitorDetails.visitFromDate = this.visitDetails.fromDate;
    this.visitorDetails.visitToDate = this.visitDetails.toDate;

    //console.log('this.visitorDetails', this.visitorDetails);

    //console.log('this.userDatas in addVisitor', this.userDatas);

    if(this.userDatas.indexOf(this.visitorDetails.meetPerson) > -1)
    {
        //console.log('match found: ', this.visitorDetails.meetPerson);
        //console.log('this.visitorDetails', this.visitorDetails);
        //console.log('this.adalService.userInfo.userName', this.adalService.userInfo.userName);
        this.companies.push(this.visitorDetails.company);
        

        this.userService.addVisitor(this.visitorDetails)
        .subscribe(
            data => {
                //this.alertService.success('Visitor added successfully', true);
                alert('Visitor added successfully');
                //console.log('loginUser.homeRedirect', this.loginUser.homeRedirect);
                this.router.navigate(['/'+this.loginUser.homeRedirect]);
            },
            error => {
                    //this.alertService.error(error);
                    //this.loading = false;
                    //console.log(error);
                    error = JSON.parse(error);
                    //console.log('error', error);
                    this.show_message = true;
                    this.error_message = error.message;
                    //console.log('message', this.error_message);
                    setTimeout(()=>{
                        this.show_message = false;
                        this.error_message = '';
                    },5000);
            });

    }
    else 
    {
        console.log('Sorry, no match found');
        this.show_message = true;
        this.error_message = "No exact match was found. Search again for more options";
        this.visitorDetails.meetPerson = '';
    }

  }

}

