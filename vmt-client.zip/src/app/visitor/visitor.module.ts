import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NguiAutoCompleteModule } from '@ngui/auto-complete';
import { Daterangepicker } from 'ng2-daterangepicker';
import { AlertService, AuthenticationService, UserService } from '../_services/index';
import { SharedServicesModule } from '../services/shared.services.module';
import {FocusModule} from 'angular2-focus';
import { VisitorComponent }   from './visitor.component';
import { routing } from './visitor.routing';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    routing,
    NguiAutoCompleteModule,
    Daterangepicker,
    FocusModule.forRoot()
  ],
  providers: [
    AlertService,
    AuthenticationService,
    UserService
  ],
  declarations: [VisitorComponent]
})
export class VisitorModule {}
