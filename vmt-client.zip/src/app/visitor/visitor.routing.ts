import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { VisitorComponent } from './visitor.component';

const routes: Routes = [
  { path: '', component: VisitorComponent }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);