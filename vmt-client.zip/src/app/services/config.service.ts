import { Injectable } from '@angular/core';

@Injectable()
export class ConfigService {
    constructor() {
    }
    public get AdalConfig(): any {
        return {
            tenant: 'amlanrpvtltd.onmicrosoft.com',
            clientId: '30b28743-c658-48d6-9b89-93b4d5dc9eef',
            redirectUri: window.location.origin + '/',
            postLogoutRedirectUri: window.location.origin + '/'
        };
    }
}