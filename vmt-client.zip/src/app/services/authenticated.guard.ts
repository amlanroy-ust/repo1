import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, NavigationExtras } from '@angular/router';
import { AdalService } from './../services/adal.service';

import { Response } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map'

@Injectable()
export class AuthenticationGuard implements CanActivate {

    loginUser: any;
    private subject = new Subject<any>();

    constructor(private router: Router, private adalService: AdalService) {

    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {

        let navigationExtras: NavigationExtras = {
            queryParams: { 'redirectUrl': route.url }
        };

        if (!this.adalService.userInfo) {
            this.router.navigate(['login'], navigationExtras);
        }
        else {
            //console.log('authenticated guard ts userInfo: ', this.adalService.userInfo);
            if(this.adalService.userInfo.userName == "system-admin@amlanrpvtltd.onmicrosoft.com")
            {
                //console.log('authenticated guard ts1: ', this.adalService.userInfo.userName);
                var empType = "admin";
                var homeRedirect = "admin";
                this.router.navigate(['admin'], navigationExtras);
            }
            else 
            {    
                //console.log('authenticated guard ts2: ', this.adalService.userInfo.userName);
                var empType = "emp";
                var homeRedirect = "home";
                //this.router.navigate(['home'], navigationExtras);
            }

            this.subject.next({ text: { "empType": empType, "firstName": this.adalService.userInfo.userName, "userInfo": this.adalService.userInfo, "homeRedirect": homeRedirect } });

            //this.router.navigate([homeRedirect], navigationExtras);
        }

        return true;
    }

    getMessage(): Observable<any> {
        return this.subject.asObservable();
    }
}
