import { Component } from '@angular/core';

@Component({
  template: '<p>Privacy Component</p>'
})
export class PrivacyComponent {}