//declare var require: any;

import { ValueService } from './services/value.service';
//import { ValueComponent } from './values/value.controller';
import { NgModule, APP_INITIALIZER } from '@angular/core'
import { RouterModule } from '@angular/router';
import { rootRouterConfig } from './app.routes';
//import { routes } from './app.routes';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { GithubService } from './github/shared/github.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';

import { QRCodeModule } from 'angular2-qrcode';
import { NguiAutoCompleteModule } from '@ngui/auto-complete';
import { Daterangepicker } from 'ng2-daterangepicker';
import {FocusModule} from 'angular2-focus';
import {DataTableModule} from "angular2-datatable";
import {MdButtonModule, MdCheckboxModule} from '@angular/material'; 
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {DataFilterPipe, searchPipe} from './admin/data-filter.pipe';
import { customHttpProvider } from './_helpers/index';
import { AlertService, AuthenticationService, UserService } from './_services/index';

import { NavComponent } from './nav/nav.component';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
//import {VisitorComponent } from './visitor/visitor.component';
import { AdminComponent } from './admin/admin.component';
import { ManagevisitComponent } from './admin-manage-visit/managevisit.component';
import { GroupComponent } from './admin-group/group.component';

import { RepoBrowserComponent } from './github/repo-browser/repo-browser.component';
import { RepoListComponent } from './github/repo-list/repo-list.component';
import { RepoDetailComponent } from './github/repo-detail/repo-detail.component';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { BaseEndpoint } from './app.constants';
import { OAuthCallbackHandler } from './login-callback/oauth-callback.guard';
import { OAuthCallbackComponent } from './login-callback/oauth-callback.component';
import { OAuthHandshakeModule } from './login-callback/oauth-callback.module';
import { SharedServicesModule } from './services/shared.services.module';

@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    AboutComponent,
    RepoBrowserComponent,
    RepoListComponent,
    RepoDetailComponent,
    HomeComponent,
    LoginComponent,
    //VisitorComponent,
    AdminComponent,
    DataFilterPipe,
    searchPipe,
    ManagevisitComponent,
    GroupComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    OAuthHandshakeModule,
    SharedServicesModule,
    RouterModule.forRoot(rootRouterConfig, { useHash: true }),
    //routes,
    QRCodeModule,
    NguiAutoCompleteModule,
    Daterangepicker,
    FocusModule.forRoot(),
    DataTableModule,
    MdButtonModule,
    MdCheckboxModule,
  ],
  providers: [
    customHttpProvider,
    AlertService,
    AuthenticationService,
    UserService,
    GithubService,
    { provide: BaseEndpoint, useValue: 'http://localhost:52233' }, // for asp.net core backend
    ValueService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
platformBrowserDynamic().bootstrapModule(AppModule);
