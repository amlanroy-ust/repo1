import {
    OpaqueToken
}
from '@angular/core';

export const BaseEndpoint = new OpaqueToken('BaseEndpoint');