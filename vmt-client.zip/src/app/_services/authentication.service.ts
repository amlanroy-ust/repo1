﻿import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map'

@Injectable()
export class AuthenticationService {

    loginUser: any;
    private subject = new Subject<any>();

    constructor(private http: Http) { }

    login(username: string, password: string) {

        return this.http.post('/users/authenticate', { username: username, password: password })
            .map((response: Response) => {
                // login successful if there's a jwt token in the response
                let user = response.json();
                if (user && user.token) {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    user.homeRedirect = "visitor-home";
                    localStorage.setItem('currentUser', JSON.stringify(user));
                    this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
                    this.subject.next({ text: this.loginUser });
                }
                //console.log('user auth', user);
                return user;
            });
    }

    getMessage(): Observable<any> {
        return this.subject.asObservable();
    }

    logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
    }

    findUser(uid: string) {
        return this.http.post('/users/employeeData', { uid: uid })
            .map((response: Response) => {
                // successful if there's a jwt token in the response
                let user = response.json();
                //console.log('user auth', user);
                return user;
            });
    }
}