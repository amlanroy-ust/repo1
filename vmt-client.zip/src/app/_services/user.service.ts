﻿import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';

import { User, Visitor } from '../_models/index';

@Injectable()
export class UserService {
    loginUser: any = {};
    private subject = new Subject<any>();

    constructor(private http: Http) { }

    sendMessage(message: string) {
        this.subject.next({ text: message });
    }

    clearMessage() {
        this.subject.next();
    }

    getMessage(): Observable<any> {
        return this.subject.asObservable();
    }

    getAll() {

        //this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
        //console.log('this.loginUser token in service', this.loginUser.token);

        return this.http.get('/users/user-list').map((response: Response) => response.json());
    }

    getById(_id: string) {
        return this.http.get('/users/current/' + _id).map((response: Response) => response.json());
    }

    visitSettings(settings){
        return this.http.post('/users/visitSettings', settings);
    }

    addVisitor(visitor) {
        return this.http.post('/users/addVisitor', visitor);
    }

    update(user: User) {
        return this.http.put('/users/' + user._id, user);
    }

    delete(_id: string) {
        return this.http.delete('/users/' + _id);
    }

    uploadmyfile(file) {
        console.log('file in service', file);
        return this.http.post('/users/fileupload', file);
    }

    getAllVisit() {
        return this.http.get('/users/getAllVisit').map((response: Response) => response.json());
    }

    getVisitSettings() {
        return this.http.get('/users/getVisitSettings').map((response: Response) => response.json());
    }

    getVisitReport(reportInput) {
        //console.log('reportInput in service', reportInput);
        return this.http.post('/users/getVisitReport', reportInput).map((response: Response) => response.json());
    }

    addGroup(groupParam) {
        return this.http.post('/users/addGroup', groupParam);
    }

    groupList() {
        return this.http.get('/users/getAllGroup').map((response: Response) => response.json());
    }

}