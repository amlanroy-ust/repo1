import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { User } from '../_models/index';
import { AlertService, UserService, AuthenticationService } from '../_services/index';
import { Subscription } from 'rxjs/Subscription';
import { AdalService } from './../services/adal.service';
import { AuthenticationGuard } from '../services/authenticated.guard';

@Component({
  selector: 'app-nav',
  moduleId: module.id,
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  loginUser: any = {};
  returnUrl: string;
  subscription: Subscription;
  homeRedirect: string;
      
  constructor(
      private route: ActivatedRoute,
      private router: Router,
      private userService: UserService,
      private AuthenticationService: AuthenticationService,
      private alertService: AlertService,
      private adalService: AdalService,
      private AuthenticationGuard: AuthenticationGuard
      ) {
      //console.log('Menu component is working');
            
      if (this.adalService.userInfo) {
            this.loginUser = { "empType": "emp", "firstName": this.adalService.userInfo.userName, "userInfo": this.adalService.userInfo, "homeRedirect": "home" };
            //this.subscription = this.AuthenticationGuard.getMessage().subscribe(loginUser => { this.loginUser = loginUser.text; });
      }
      else 
      { 
        this.subscription = this.AuthenticationService.getMessage().subscribe(loginUser => { this.loginUser = loginUser.text; });
      }
      //console.log('location.path()', window.location.pathname);
      
      if(Object.keys(this.loginUser).length === 0)
      {
          this.subscription = this.AuthenticationGuard.getMessage().subscribe(loginUser => { this.loginUser = loginUser.text; });
      }
      //console.log('this.loginUser in nav comp: ', this.loginUser);
  }

  ngOnInit() {

        if (this.adalService.userInfo) {
            
            if(this.adalService.userInfo.userName == "system-admin@amlanrpvtltd.onmicrosoft.com")
            {
                var empType = "admin";
                var homeRedirect = "admin";
            }
            else 
            {    
                var empType = "emp";
                var homeRedirect = "home";
            }
            this.loginUser = { "empType": empType, "firstName": this.adalService.userInfo.userName, "userInfo": this.adalService.userInfo, "homeRedirect": homeRedirect };

            //console.log('ngOnInit in nav comp: ', this.adalService.userInfo);
            //console.log('ngOnInit in nav comp: ', this.loginUser);
        }
        else
        {
            this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
            //console.log('this.loginUser in nav comp: ', this.loginUser);
            //this.loginUser.homeRedirect = "visitor-home";
        }
        
        //console.log('this.loginUser in nav comp: ', this.loginUser);
        //console.log('this.homeRedirect in nav comp: ', this.homeRedirect);
    }

    logout() {

        if (this.adalService.userInfo) {
            this.adalService.logout();
        }
        else{
            // remove user from local storage to log user out
            localStorage.removeItem('currentUser');
            this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
            this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/login';
            //console.log('this.returnUrl', this.returnUrl);
            this.router.navigate([this.returnUrl]);
            //window.location.reload();
        }
    }

}
