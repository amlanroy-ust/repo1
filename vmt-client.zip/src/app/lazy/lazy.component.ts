import { Component } from '@angular/core';

@Component({
  template: `
  <p>The hero's birthday is {{ birthday }}</p>
`

})
export class LazyComponent {
  birthday = new Date(1988, 3, 15); // April 15, 1988
}