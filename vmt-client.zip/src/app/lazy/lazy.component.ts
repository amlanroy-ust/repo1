import { Component, OnInit, NgModule } from '@angular/core';
import {BrowserModule} from '@angular/platform-browser'
//import '../assets/export-to-excel.js';
declare var tableToExcel: any;

@Component({
  templateUrl: './lazy.component.html'
})
export class LazyComponent implements OnInit {
  //birthday = new Date(1988, 3, 15); // April 15, 1988

  birthday = new Date(1988, 3, 15); // April 15, 1988
  toggle = true; // start with true == shortDate

  get format()   { return this.toggle ? 'shortDate' : 'fullDate'; }
  toggleFormat() { 
    //alert('alert me!');
    //console.log(this.toggle);
    this.toggle = !this.toggle; 
  }

  CallFunction1(table:string, name:string) {
    tableToExcel.func1(table, name);
  }

  constructor(){
    console.log('Lazy constructor');
  }
  ngOnInit() {
        console.log('this.toggle in ngOnInit', this.toggle);
  }

}
