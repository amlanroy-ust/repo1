import { AdalService } from './services/adal.service';
import { Component,Input,OnInit } from '@angular/core';
import { User } from './_models/index';
import { Subscription } from 'rxjs/Subscription';
import { UserService } from './_services/index';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'angular 4 app';

  message: any;
  subscription: Subscription;

  constructor( private UserService: UserService, private adalService: AdalService ) {

      this.subscription = this.UserService.getMessage().subscribe(message => { this.message = message; });

  }

  ngOnInit(){

      }

}

// import { AdalService } from './services/adal.service';
// import {Component} from '@angular/core';

// @Component({
//   selector: 'app-root',
//   templateUrl: './app.component.html',
// })
// export class AppComponent {
//   constructor(private adalService: AdalService){

//   }
// }
