import { Component, OnInit, Injectable } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormsModule, ReactiveFormsModule, FormControl, FormBuilder } from "@angular/forms";
import { appConfig } from '../app.config';
import { User } from '../_models/index';
import { UserService } from '../_services/index';
import { AdalService } from './../services/adal.service';
import { AuthenticationGuard } from '../services/authenticated.guard';
import { Subscription } from 'rxjs/Subscription';
import {style, state, animate, transition, trigger} from '@angular/core';

@Component({
  selector: 'app-group',
  moduleId: module.id,
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.css']
})
export class GroupComponent implements OnInit {

  loginUser: any = {};
  returnUrl: string;
  errorMsg:string;
  groupList = [];
  subscription: Subscription;
  groupName: string;
  groupDetails: any = {};

  public data;
  public filterQuery = "";
  public rowsOnPage = 10;
  public sortBy = "name";
  public sortOrder = "asc";

  constructor(private userService: UserService, private route: ActivatedRoute, private router: Router, private adalService: AdalService, private AuthenticationGuard: AuthenticationGuard) {
        //console.log('Group component is working', this.adalService.userInfo);  
        if (this.adalService.userInfo) {

            this.subscription = this.AuthenticationGuard.getMessage().subscribe(loginUser => { this.loginUser = loginUser.text; });
            
            // this.loginUser = { "empType": "emp", "firstName": this.adalService.userInfo.userName, "userInfo": this.adalService.userInfo };
        }  
        else this.loginUser = JSON.parse(localStorage.getItem('currentUser'));

        if(this.loginUser === null)
        {
          this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/login';
          this.router.navigate([this.returnUrl]);
        }
        else if(this.loginUser.empType === "admin")
        {
          this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/manage-group';
          this.router.navigate([this.returnUrl]);
        }
        else if(this.loginUser.empType === "emp")
        {
          this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/home';
          this.router.navigate([this.returnUrl]);
        }
        else if(this.loginUser.empType === "visitor")
        {
          this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/visitor-home';
          this.router.navigate([this.returnUrl]);
        }
    }

  ngOnInit() {
        //console.log('this.loginUser in Admin ', this.loginUser);
        this.loadAllGroups();
  }

  loadAllGroups() {
        this.userService.groupList().subscribe(groups => { 
            this.groupList = groups.groupList; 
            console.log('this.groupList', this.groupList);
        });
  }

  addGroup(){
    console.log('this.groupDetails', this.groupDetails);
    this.userService.addGroup(this.groupDetails)
        .subscribe(
            data => {
                //this.alertService.success('Visitor added successfully', true);
                alert('Group added successfully');
                //console.log('loginUser.homeRedirect', this.loginUser.homeRedirect);
                this.router.navigate(['/manage-group']);
                this.loadAllGroups();
            },
            error => {
                    //this.alertService.error(error);
                    //this.loading = false;
                    //console.log(error);
                    error = JSON.parse(error);
                    //console.log('error', error);
                    //this.show_message = true;
                    //this.error_message = error.message;
                    //console.log('message', this.error_message);
                    // setTimeout(()=>{
                    //     this.show_message = false;
                    //     this.error_message = '';
                    // },5000);
            });
  }


}
