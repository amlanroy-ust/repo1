///<reference path="../node_modules/@types/adal/index.d.ts" />
/* SystemJS module definition */
declare var module: NodeModule;
declare var tableToExcel:any;
interface NodeModule {
  id: string;
}
