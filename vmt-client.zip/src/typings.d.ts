///<reference path="../node_modules/@types/adal/index.d.ts" />
/* SystemJS module definition */
declare var module: NodeModule;
interface NodeModule {
  id: string;
}
