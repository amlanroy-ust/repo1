import { VmtPage } from './app.po';

describe('vmt App', () => {
  let page: VmtPage;

  beforeEach(() => {
    page = new VmtPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
