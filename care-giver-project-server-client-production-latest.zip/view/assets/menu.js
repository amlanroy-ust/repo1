(function($) {
	$(function() {
	$('.nav-mob').append($('<div class="nav-mobile"><div class="sub-sec"><i class="fa fa-bars" aria-hidden="true"></i></div></div>'));
	$('.nav-item').has('ul').prepend('<span class="nav-click"><i class="fa fa-chevron-down" aria-hidden="true"></i></span>');
		$('.nav-mobile').click(function(){
		$('.nav-list').toggle();
		});
		$('.nav-list').on('click', '.nav-click', function(){
		$(this).siblings('.nav-submenu').toggle();
		$(this).children('.nav-arrow').toggleClass('nav-rotate');
		});
	});	
})(jQuery);