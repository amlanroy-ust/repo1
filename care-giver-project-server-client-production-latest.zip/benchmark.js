﻿require('server.js');
var siege = require('siege');

siege(__dirname + '/server.js')
  .on(3000)
  .get('/')
  .attack()