module.exports = {
	"port" : process.env.PORT || 3100,
	"secretKey" : "hyrgqwjdfbw4534efqrwer2q38945765",
	dev_mode : true,
    __site_url: 'http://localhost/',
    __root_dir: __dirname
}
