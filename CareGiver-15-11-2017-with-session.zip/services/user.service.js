﻿var Q = require('q');
var db = require('../db');

var service = {};
service.login = login;
service.loginService = loginService;
service.getAllClient = getAllClient;
service.logout = logout;
service.getAllClientTrafficDetails = getAllClientTrafficDetails;
service.getAllClientCourtDetails = getAllClientCourtDetails;
service.getLocationTypeList = getLocationTypeList;
service.getProgramStatusList = getProgramStatusList;
service.tokenValidation = tokenValidation;
service.getMilestoneList = getMilestoneList;
service.getSurveyList = getSurveyList;
service.getClientSurveyDetailsList = getClientSurveyDetailsList;
service.getProviderList = getProviderList;
service.getProviderQuestionList = getProviderQuestionList;

module.exports = service;

var executeQuery = function(sqlquery){
    var deferred = Q.defer();
        db.query(sqlquery, function(err,rows){
            if(!err) {
                deferred.resolve(rows);
            }           
        });
    return deferred.promise;
}

function login(userName, password){
    var query = "CALL USP_VALIDATION_LOGIN('"+userName+"', '"+password+"');";
    return executeQuery(query, function(result) {
        
    });
}

function loginService(userName, password, token) {
    var query = "CALL USP_LOGIN_SERVICE('"+userName+"', '"+password+"', '"+token+"');";
    return executeQuery(query, function(result) {
        
    });
}

function tokenValidation(userName, token) {
    var query = "CALL USP_VALIDATION_TOKEN('"+userName+"', '"+token+"');";
    return executeQuery(query, function(result) {
        
    });
}

function logout(userName){
    var query = "CALL USP_LOGOUT('"+userName+"');";
    return executeQuery(query, function(result) {
        
    });
}

function getAllClient() {
    var query = "CALL USP_CLIENT_PROFILE();";
    return executeQuery(query, function(result) {
    });
}

function getAllClientTrafficDetails(clientList){
    var the_promises = [];

    clientList.forEach(function(client) {
        var deferred = Q.defer();
        var query = "CALL USP_CLIENT_VIEW_TRAFFICKING_HDR_AND_DETAILS("+client.CLIENT_ID+");";
        db.query(query, function(err,rows){
            if(!err) {
                client.trafficData = rows[0];
                deferred.resolve(client);
            }           
        });
        the_promises.push(deferred.promise);
    });

    return Q.all(the_promises);
}

function getAllClientCourtDetails(clientList){
    var the_promises = [];

    clientList.forEach(function(client) {
        var deferred = Q.defer();
        var query = "CALL USP_CLIENT_VIEW_COURT_DETAILS("+client.CLIENT_ID+");";
        db.query(query, function(err,rows){
            if(!err) {
                client.courtData = rows[0];
                deferred.resolve(client);
            }           
        });
        the_promises.push(deferred.promise);
    });

    return Q.all(the_promises);
}

function getLocationTypeList(){
    var query = "CALL USP_CATALOG_LIST('LOCATION_TYPE');";
    return executeQuery(query, function(result) {
        
    });
}

function getProgramStatusList(){
    var query = "CALL USP_STATUS_LIST();";
    return executeQuery(query, function(result) {
        
    });
}

function getClientSurveyDetailsList(clientList){

    var the_promises = [];

    clientList.forEach(function(client) {
        var deferred = Q.defer();
        var query = "CALL USP_WEB_CLIENT_SURVEY_REPORT("+client.CLIENT_ID+", "+client.COMPANY_ID+");";
        db.query(query, function(err,rows){
            if(!err) {
                client.surveyData = rows[0];
                deferred.resolve(client);
            }           
        });
        the_promises.push(deferred.promise);
    });

    return Q.all(the_promises);
}

function getMilestoneList(){
    var query = "CALL UST_WEB_MILESTONE_LIST();";
    return executeQuery(query, function(result) {
       
    });
}

function getSurveyList(){
    var query = "CALL UST_WEB_SURVEY_LIST();";
    return executeQuery(query, function(result) {
        
    });
}

function getProviderList(){
    var query = "CALL USP_WEB_PROVIDER_LIST();";
    return executeQuery(query, function(result) {
        
    });
}

function getProviderQuestionList(providerList){

    var the_promises = [];

    providerList.forEach(function(provider) {
        var deferred = Q.defer();
        var query = "CALL USP_WEB_PROVIDER_VIEW_QUESTION_SCORE("+provider.PROVIDER_ID+", "+provider.COMPANY_ID+");";
        db.query(query, function(err,rows){
            if(!err) {
                provider.questionData = rows[0];
                deferred.resolve(provider);
            }           
        });
        the_promises.push(deferred.promise);
    });

    return Q.all(the_promises);
}
