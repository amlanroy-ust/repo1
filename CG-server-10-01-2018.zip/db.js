var mysql = require('mysql');
var connection = mysql.createConnection({
    host     : '172.27.16.152',
	user     : 'emandev',
	password : 'password123',
	database : 'emancipaction_test'
});

connection.connect(function(err) {
    if (err) throw err;
	else console.log('Connection established'); 
});

module.exports = connection;