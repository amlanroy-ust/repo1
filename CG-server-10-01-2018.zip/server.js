﻿require('rootpath')();
var express = require('express');
var app = express();
var cors = require('cors');
var bodyParser = require('body-parser');
var expressJwt = require('express-jwt');
var config = require('./config');
var fs = require('fs');
var path = require('path');
var http = require('http').Server(app);

app.use(function(req, res, next) { //allow cross origin requests
        res.setHeader("Access-Control-Allow-Methods", "POST, PUT, OPTIONS, DELETE, GET");
        res.header("Access-Control-Allow-Origin", config.__site_url);
        res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
        res.header("Access-Control-Allow-Credentials", true);
        next();
    });

app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.set("view options", {layout: false});
app.use(express.static(__dirname + '/view'));

app.get('/', function(req, res) {
    res.render('index.html');
});

//api routes created
var apiRoutes = require('./routes/apiRoutes.js')(app, express);
app.use('/api', apiRoutes);

http.listen(config.port, function (err) {
    if (err) {
        console.log(err)
    } else {
        console.log('Server listening on port ' + config.port);
    }
});