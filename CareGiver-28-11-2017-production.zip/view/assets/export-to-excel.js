function tableToExcel(e, table, filename) {

    if(isIE())
      { 
          var uri = 'data:application/vnd.ms-excel;base64,'
          , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
          , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
          , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
            
              if (!table.nodeType) table = document.getElementById(table)
              var ctx = {worksheet: filename, table: table.innerHTML}
              var blob = new Blob([format(template, ctx)]);
              var blobURL = window.URL.createObjectURL(blob);
              
              csvData = table.innerHTML;
                if (window.navigator.msSaveBlob) {
                    var blob = new Blob([format(template, ctx)], {
                        type: "text/html"
                    });
                    navigator.msSaveBlob(blob, ''+filename+'.xls');
                    return true;
                }
      }
    else
      { 
        var uri = 'data:application/vnd.ms-excel;base64,'
          , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
          , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
          , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }

        if (!table.nodeType) table = document.getElementById(table)
        var ctx = {worksheet: filename, table: table.innerHTML}
        var link = document.createElement('a');
        link.href = uri + base64(format(template, ctx));
        link.download = filename + '.xls';
        document.body.appendChild(link);
        
        if(link.click)
            link.click();
        else if(document.createEvent)
        {
            var eventObj = document.createEvent('MouseEvents');
            eventObj.initEvent('click',true,true);
            link.dispatchEvent(eventObj);
        }
        return true;
    }
      
  }

function isIE()
 {
     var isIE11 = navigator.userAgent.indexOf(".NET CLR") > -1;      
     var isIE11orLess = isIE11 || navigator.appVersion.indexOf("MSIE") != -1;
     return isIE11orLess;
 }