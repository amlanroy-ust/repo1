﻿module.exports = function (app, express) {
    var api = express.Router();
    var config = require('../config');
    var userService = require('../services/user.service');
    var jwt = require('jsonwebtoken');
    var md5 = require('md5');
    var randomstring = require("randomstring");
    var expressJwt = require('express-jwt');

    //use JWT auth to secure the api, the token can be passed in the authorization header or querystring

    api.use(expressJwt({
        secret: config.secretKey,
        getToken: function (req) {
            if (req.headers.authorization && req.headers.authorization.split(' ')[0] === 'Bearer') {
                return req.headers.authorization.split(' ')[1];
            } else if (req.query && req.query.token) {
                return req.query.token;
            }
            //console.log('Token not found');
            return null;
        }
    }).unless({ path: ['/api/login'] }));

    //////////////////////////
    // Login Api
    //////////////////////////
    api.post('/login', function(req, res){
        var userName = req.body.username;
        var password = md5(req.body.password);
        
        userService.login(userName, password)
        .then(function (results) {
            var login_token = randomstring.generate();
            var jwt_token = jwt.sign({ sub: userName }, config.secretKey);
            //console.log('user login: ', results);
            if(results[0][0].CHECKCOUNT === 1)
            {
                userService.loginService(userName, password, login_token)
                .then(function (results) {
                    if(results[0][0].USER_TYPE === 'CRT' || results[0][0].USER_TYPE === 'IRT')
                    {
                        var userDet = {
                            userName: userName,
                            token: jwt_token,
                            login_token: login_token,
                            userInfo: results[0][0]
                        }
                        res.send(userDet);
                    }
                    else{
                        res.status(400).send({errorMessage: 'You are not authorized to login.'});
                    }
                })
                .catch(function (err) {
                    res.status(400).send(err);
                });
            }
            else {
                res.status(400).send({errorMessage: 'Username/Password is not matching.'});
            }

        })
        .catch(function (err) {
            res.status(400).send(err);
        });
    });

    //////////////////////////
    //Token Validation
    //////////////////////////
    api.get('/validateToken/:userName/:loginToken', function(req, res){
        var token = req.params.loginToken;
        var userName = req.params.userName;
        if(req.params.userName !== undefined && req.params.loginToken !== undefined)
        {
            userService.tokenValidation(userName, token)
            .then(function (results) {
                res.send(results[0][0]);
            })
            .catch(function (err) {
                res.status(400).send(err);
            });
        }
        else res.status(200).send({'CHECKCOUNT': 0});
    }); 

    //////////////////////////
    //Logout
    //////////////////////////
    api.post('/logout', function(req, res){
        if(req.body.userName !== undefined)
        {
            var userName = req.body.userName;
            userService.logout(userName)
            .then(function (results) {
                res.send(results);
            })
            .catch(function (err) {
                res.status(400).send(err);
            });
        }
        else res.status(400).send({'message': 'error in session data'});
    });

    //////////////////////////
    // get Client List 
    //////////////////////////

    api.get('/getClientList', function(req, res){
        userService.getAllClient()
        .then(function (clients) {
            res.send(clients[0]);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
    });

    //////////////////////////
    // get Client List with Traffic Details and Court Details 
    //////////////////////////

    api.get('/getAllClientsTrafficCourt/:userName/:loginToken', function(req, res){
        var loginToken = req.params.loginToken;
        var userName = req.params.userName;
        userService.tokenValidation(userName, loginToken)
        .then(function (results) {
            if(results[0][0].CHECKCOUNT > 0)
                return userService.getAllClient()
            else res.status(400).send({success: false, message: "token required"});
        })
        .then(function (clients) {
            return userService.getAllClientTrafficDetails(clients[0])
        })
        .then(function (clientList) {
            return userService.getAllClientCourtDetails(clientList)
        })
        .then(function (clientListDetails) {
            res.send(clientListDetails);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
    });

    //////////////////////////
    // get a Single Client Details 
    //////////////////////////

    api.get('/getClientDetails/:clientID', function(req, res){
        var CLIENT_ID = req.params.clientID;
        userService.getClientDetails(CLIENT_ID)
        .then(function (users) {
            res.send(users);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
    });

    //////////////////////////
    // get a Single Client Court Details 
    //////////////////////////
    api.get('/getClientCourtDetails/:clientID', function(req, res){
        var CLIENT_ID = req.params.clientID;
        userService.getClientCourtDetails(CLIENT_ID)
        .then(function (users) {
            res.send(users);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
    });

    //////////////////////////
    // get a Single Client Medical History Details 
    //////////////////////////
    api.get('/getClientMedHistory/:clientID', function(req, res){
        var CLIENT_ID = req.params.clientID;
        userService.getClientMedHistory(CLIENT_ID)
        .then(function (users) {
            res.send(users);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
    });

    //////////////////////////
    // get a Single Client Medical History Attach Details 
    //////////////////////////
    api.get('/getClientMedHistoryAttach/:clientID', function(req, res) {
        var CLIENT_ID = req.params.clientID;
        userService.getClientMedHistoryAttach(CLIENT_ID)
        .then(function (users) {
            res.send(users);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
    })

    //////////////////////////
    // get a Single Client traffic Details 
    //////////////////////////
    api.get('/getClientTrafficDetails/:clientID', function(req, res) {
        var CLIENT_ID = req.params.clientID;
        userService.getClientTrafficDetails(CLIENT_ID)
        .then(function (lists) {
            res.send(lists);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
    })

    //////////////////////////
    // get list of  Location Type 
    //////////////////////////
    api.get('/getLocationTypeList', function(req, res) {
        userService.getLocationTypeList()
        .then(function (lists) {
            res.send(lists[0]);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
    })

    //////////////////////////
    // get list of  client program status 
    //////////////////////////
    api.get('/getProgramStatusList', function(req, res) {
        userService.getProgramStatusList()
        .then(function (lists) {
            res.send(lists[0]);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
    })

    //////////////////////////
    // get Client List with Survey Details 
    //////////////////////////

    api.get('/getClientSurveyDetailsList', function(req, res){
        userService.getAllClient()
        .then(function (clients) {
            return userService.getClientSurveyDetailsList(clients[0])
        })
        .then(function (clientSurveyList) {
            res.send(clientSurveyList);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
    });

    //////////////////////////
    // get a Single Client Survey Details 
    //////////////////////////
    api.get('/getClientSurveyDetails/:clientID/:P_COMPANY_ID', function(req, res) {
        var CLIENT_ID = req.params.clientID;
        var P_COMPANY_ID = req.params.P_COMPANY_ID;
        userService.getClientSurveyDetails(CLIENT_ID, P_COMPANY_ID)
        .then(function (lists) {
            res.send(lists[0]);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
    })
 
    //////////////////////////
    // get list of  Milestone List 
    //////////////////////////
    api.get('/getMilestoneList', function(req, res) {
        userService.getMilestoneList()
        .then(function (lists) {
            res.send(lists[0]);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
    })

    //////////////////////////
    // get list of  Survey List 
    //////////////////////////
    api.get('/getSurveyList', function(req, res) {
        userService.getSurveyList()
        .then(function (lists) {
            res.send(lists[0]);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
    })

    //////////////////////////
    // get list of  Providers With Questions
    //////////////////////////
    api.get('/getProviderQuestionList', function(req, res){
        userService.getProviderList()
        .then(function (providers) {
            return userService.getProviderQuestionList(providers[0])
        })
        .then(function (providerQuestionList) {
            res.send(providerQuestionList);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
    });

    return api;
}